<?php
/**
 * Database Schema Import Tool
 * This will import the database schema automatically
 */

echo "<h1>📊 Database Schema Import Tool</h1>";
echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.success { color: #10b981; background: #f0fdf4; padding: 10px; border-radius: 5px; margin: 10px 0; }
.error { color: #ef4444; background: #fef2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
.warning { color: #f59e0b; background: #fffbeb; padding: 10px; border-radius: 5px; margin: 10px 0; }
.info { color: #3b82f6; background: #eff6ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
form { background: white; padding: 20px; border-radius: 10px; margin: 20px 0; }
input[type=text], input[type=password] { width: 300px; padding: 8px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px; }
button { background: #10b981; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
button:hover { background: #059669; }
pre { background: #1f2937; color: #f9fafb; padding: 15px; border-radius: 5px; overflow-x: auto; max-height: 300px; }
</style>";

// Handle form submission
if ($_POST) {
    $dbHost = $_POST['db_host'] ?? '';
    $dbName = $_POST['db_name'] ?? '';
    $dbUser = $_POST['db_user'] ?? '';
    $dbPass = $_POST['db_pass'] ?? '';
    
    if (empty($dbHost) || empty($dbName) || empty($dbUser)) {
        echo "<div class='error'>❌ Please fill in all database fields</div>";
    } else {
        try {
            // Connect to database
            $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4", $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            
            echo "<div class='success'>✅ Database connection successful</div>";
            
            // Read schema file
            $schemaFile = __DIR__ . '/database/schema.sql';
            if (!file_exists($schemaFile)) {
                echo "<div class='error'>❌ Schema file not found: database/schema.sql</div>";
                exit;
            }
            
            $schema = file_get_contents($schemaFile);
            echo "<div class='success'>✅ Schema file loaded</div>";
            
            // Split into individual statements
            $statements = array_filter(array_map('trim', explode(';', $schema)));
            
            echo "<div class='info'>📊 Executing " . count($statements) . " SQL statements...</div>";
            
            $successCount = 0;
            $errorCount = 0;
            
            foreach ($statements as $statement) {
                if (empty($statement) || strpos($statement, '--') === 0) {
                    continue;
                }
                
                try {
                    $pdo->exec($statement);
                    $successCount++;
                    
                    // Show what was executed (first 50 chars)
                    $preview = substr(preg_replace('/\s+/', ' ', $statement), 0, 50) . '...';
                    echo "<div style='color: #10b981; font-size: 12px;'>✓ " . htmlspecialchars($preview) . "</div>";
                    
                } catch (PDOException $e) {
                    $errorCount++;
                    $preview = substr(preg_replace('/\s+/', ' ', $statement), 0, 50) . '...';
                    echo "<div style='color: #ef4444; font-size: 12px;'>✗ " . htmlspecialchars($preview) . " - " . $e->getMessage() . "</div>";
                }
            }
            
            echo "<div class='success'>✅ Schema import completed!</div>";
            echo "<div class='info'>📊 Results: $successCount successful, $errorCount errors</div>";
            
            if ($errorCount == 0) {
                echo "<div class='success'>🎉 Database setup complete! Now run <a href='quick-fix.php'>quick-fix.php</a> to create admin user.</div>";
            } else {
                echo "<div class='warning'>⚠️ Some errors occurred. The database might still work, but check the errors above.</div>";
            }
            
        } catch (PDOException $e) {
            echo "<div class='error'>❌ Database connection failed: " . $e->getMessage() . "</div>";
        }
    }
} else {
    // Show form
    echo "<div class='info'>This tool will import the database schema (create all tables) for Shing Chat.</div>";
    
    echo "<form method='POST'>";
    echo "<h3>Database Configuration</h3>";
    echo "<label>Database Host:</label><br>";
    echo "<input type='text' name='db_host' value='localhost' required><br><br>";
    
    echo "<label>Database Name:</label><br>";
    echo "<input type='text' name='db_name' placeholder='your_database_name' required><br><br>";
    
    echo "<label>Database Username:</label><br>";
    echo "<input type='text' name='db_user' placeholder='your_username' required><br><br>";
    
    echo "<label>Database Password:</label><br>";
    echo "<input type='password' name='db_pass' placeholder='your_password'><br><br>";
    
    echo "<button type='submit'>Import Database Schema</button>";
    echo "</form>";
    
    echo "<div class='warning'>";
    echo "<h3>⚠️ Important Notes:</h3>";
    echo "<ul>";
    echo "<li>Make sure the database exists (create it in phpMyAdmin/cPanel first)</li>";
    echo "<li>This will create all required tables for Shing Chat</li>";
    echo "<li>After this, run <code>quick-fix.php</code> to create the admin user</li>";
    echo "<li>Delete these setup files after completion</li>";
    echo "</ul>";
    echo "</div>";
}
?>