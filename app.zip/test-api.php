<?php
/**
 * API Test Tool - Test if scenarios API is working
 */

echo "<h1>🧪 API Test Tool</h1>";
echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.success { color: #10b981; background: #f0fdf4; padding: 10px; border-radius: 5px; margin: 10px 0; }
.error { color: #ef4444; background: #fef2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
.warning { color: #f59e0b; background: #fffbeb; padding: 10px; border-radius: 5px; margin: 10px 0; }
.info { color: #3b82f6; background: #eff6ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
pre { background: #1f2937; color: #f9fafb; padding: 15px; border-radius: 5px; overflow-x: auto; }
</style>";

echo "<h2>🔌 Testing API Endpoints</h2>";

// Test 1: Database connection
echo "<h3>1. Database Connection Test</h3>";
try {
    require_once 'backend/config.php';
    if (isset($pdo) && $pdo instanceof PDO) {
        echo "<div class='success'>✅ Database connection successful</div>";
    } else {
        echo "<div class='error'>❌ Database connection failed</div>";
        exit;
    }
} catch (Exception $e) {
    echo "<div class='error'>❌ Database error: " . $e->getMessage() . "</div>";
    exit;
}

// Test 2: Check scenarios table
echo "<h3>2. Scenarios Table Test</h3>";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM scenarios WHERE status = 'active'");
    $result = $stmt->fetch();
    $scenarioCount = $result['count'];
    
    if ($scenarioCount > 0) {
        echo "<div class='success'>✅ Found $scenarioCount active scenarios in database</div>";
        
        // Show scenarios
        $stmt = $pdo->query("SELECT id, title, description, status FROM scenarios WHERE status = 'active' LIMIT 5");
        echo "<h4>Sample Scenarios:</h4>";
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Title</th><th>Description</th><th>Status</th></tr>";
        while ($scenario = $stmt->fetch()) {
            echo "<tr>";
            echo "<td>" . $scenario['id'] . "</td>";
            echo "<td>" . htmlspecialchars($scenario['title']) . "</td>";
            echo "<td>" . htmlspecialchars(substr($scenario['description'], 0, 50)) . "...</td>";
            echo "<td>" . $scenario['status'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div class='warning'>⚠️ No active scenarios found in database</div>";
        echo "<div class='info'>You need to create scenarios in the admin panel first</div>";
    }
} catch (PDOException $e) {
    echo "<div class='error'>❌ Scenarios table error: " . $e->getMessage() . "</div>";
}

// Test 3: API endpoint test
echo "<h3>3. API Endpoint Test</h3>";
try {
    // Simulate API call
    $_GET['endpoint'] = 'scenarios';
    
    // Capture output
    ob_start();
    include 'backend/api.php';
    $apiOutput = ob_get_clean();
    
    // Try to decode JSON
    $apiData = json_decode($apiOutput, true);
    
    if ($apiData && isset($apiData['success'])) {
        if ($apiData['success']) {
            echo "<div class='success'>✅ API endpoint working correctly</div>";
            echo "<div class='info'>Returned " . count($apiData['data']) . " scenarios</div>";
            
            if (!empty($apiData['data'])) {
                echo "<h4>API Response Sample:</h4>";
                echo "<pre>" . json_encode($apiData['data'][0], JSON_PRETTY_PRINT) . "</pre>";
            }
        } else {
            echo "<div class='error'>❌ API returned error: " . ($apiData['message'] ?? 'Unknown error') . "</div>";
        }
    } else {
        echo "<div class='error'>❌ API returned invalid JSON</div>";
        echo "<pre>" . htmlspecialchars($apiOutput) . "</pre>";
    }
    
} catch (Exception $e) {
    echo "<div class='error'>❌ API test failed: " . $e->getMessage() . "</div>";
}

// Test 4: Frontend API URL test
echo "<h3>4. Frontend API URL Test</h3>";
$frontendApiUrl = '../backend/api.php?endpoint=scenarios';
$fullUrl = 'http' . (isset($_SERVER['HTTPS']) ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/' . $frontendApiUrl;

echo "<div class='info'>Frontend will call: <code>$frontendApiUrl</code></div>";
echo "<div class='info'>Full URL: <code>$fullUrl</code></div>";

// Test the URL
$context = stream_context_create([
    'http' => [
        'timeout' => 10,
        'method' => 'GET'
    ]
]);

try {
    $response = file_get_contents($fullUrl, false, $context);
    if ($response) {
        $data = json_decode($response, true);
        if ($data && isset($data['success']) && $data['success']) {
            echo "<div class='success'>✅ Frontend API URL working correctly</div>";
        } else {
            echo "<div class='error'>❌ Frontend API URL returned error</div>";
            echo "<pre>" . htmlspecialchars($response) . "</pre>";
        }
    } else {
        echo "<div class='error'>❌ Frontend API URL not accessible</div>";
    }
} catch (Exception $e) {
    echo "<div class='error'>❌ Frontend API URL test failed: " . $e->getMessage() . "</div>";
}

echo "<h2>🎯 Summary</h2>";
echo "<div class='info'>";
echo "<h3>If all tests pass:</h3>";
echo "<ul>";
echo "<li>The API should work correctly</li>";
echo "<li>Try refreshing the chat page</li>";
echo "<li>The warning message should disappear</li>";
echo "</ul>";
echo "</div>";

echo "<div class='warning'>";
echo "<h3>If tests fail:</h3>";
echo "<ul>";
echo "<li>Check database configuration in backend/config.local.php</li>";
echo "<li>Make sure scenarios exist in the admin panel</li>";
echo "<li>Check file permissions</li>";
echo "</ul>";
echo "</div>";

echo "<hr>";
echo "<p><small>🧪 Test completed at " . date('Y-m-d H:i:s') . "</small></p>";
?>