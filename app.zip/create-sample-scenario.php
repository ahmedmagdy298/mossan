<?php
/**
 * Create Sample Scenario Tool
 * This will create a properly formatted scenario in the database
 */

echo "<h1>🎯 Create Sample Scenario</h1>";
echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.success { color: #10b981; background: #f0fdf4; padding: 10px; border-radius: 5px; margin: 10px 0; }
.error { color: #ef4444; background: #fef2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
.warning { color: #f59e0b; background: #fffbeb; padding: 10px; border-radius: 5px; margin: 10px 0; }
.info { color: #3b82f6; background: #eff6ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
pre { background: #1f2937; color: #f9fafb; padding: 15px; border-radius: 5px; overflow-x: auto; }
button { background: #10b981; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
button:hover { background: #059669; }
</style>";

// Test database connection
try {
    require_once 'backend/config.php';
    echo "<div class='success'>✅ Database connected</div>";
} catch (Exception $e) {
    echo "<div class='error'>❌ Database error: " . $e->getMessage() . "</div>";
    exit;
}

if ($_POST && isset($_POST['create_scenario'])) {
    // Create the sample scenario
    $title = "SAAD Scenario - Sample";
    $description = "Advanced counseling scenario with Mr. Saad around shingles risk and vaccination.";
    
    $scenarioData = [
        "steps" => [
            [
                "id" => "greeting",
                "speaker" => "bot",
                "message" => "SAAD Scenario - You are meeting with Mr. Saad, a 65-year-old patient with a history of lung conditions. How would you like to start the consultation?",
                "responses" => [
                    [
                        "text" => "Good morning, Mr. Saad. How are you doing today?",
                        "next" => "a1",
                        "tag" => "Greeting",
                        "score_weight" => "High",
                        "score_level" => "Good",
                        "feedback" => "Excellent opening - establishes rapport and shows genuine concern"
                    ],
                    [
                        "text" => "Long time no see, Mr. Saad. I hope you're in good health!",
                        "next" => "b1",
                        "tag" => "Greeting",
                        "score_weight" => "High",
                        "score_level" => "Good",
                        "feedback" => "Warm greeting that acknowledges the relationship and shows care"
                    ],
                    [
                        "text" => "Says Nothing.",
                        "next" => "c1",
                        "tag" => "Greeting",
                        "score_weight" => "High",
                        "score_level" => "Bad",
                        "feedback" => "Missed opportunity to establish rapport and connection"
                    ]
                ]
            ],
            [
                "id" => "a1",
                "speaker" => "patient",
                "message" => "Honestly? Feeling my age, I don't think I am doing well.",
                "responses" => [
                    [
                        "text" => "Your age and lung history puts you at severe risks like shingles.",
                        "next" => "solution",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good",
                        "feedback" => "Good acknowledgment of risk factors and direct communication"
                    ],
                    [
                        "text" => "Given the history of your lung conditions, you must not be doing your best.",
                        "next" => "solution",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Medium",
                        "feedback" => "Addresses risk but could be more empathetic in delivery"
                    ]
                ]
            ],
            [
                "id" => "b1",
                "speaker" => "patient",
                "message" => "Am I? Not really, doctor. Tell me, why did you ask for this appointment?",
                "responses" => [
                    [
                        "text" => "As aging weakens our immune system, susceptibility to illnesses increases.",
                        "next" => "solution",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good",
                        "feedback" => "Educational approach that explains the underlying mechanism"
                    ]
                ]
            ],
            [
                "id" => "c1",
                "speaker" => "patient",
                "message" => "Mr. Saad looks at you expectantly, waiting for you to explain the purpose of the appointment.",
                "responses" => [
                    [
                        "text" => "I wanted to discuss your risk for shingles and how we can prevent it.",
                        "next" => "solution",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Medium",
                        "feedback" => "Direct approach but could benefit from more rapport building"
                    ]
                ]
            ],
            [
                "id" => "solution",
                "speaker" => "patient",
                "message" => "What can we do about it?",
                "responses" => [
                    [
                        "text" => "There's a highly effective vaccine called Shingrix that can reduce your risk by over 90%. It's recommended for adults over 50.",
                        "next" => "end",
                        "tag" => "Solution",
                        "score_weight" => "High",
                        "score_level" => "Good",
                        "feedback" => "Comprehensive information with specific efficacy data and clear recommendation"
                    ],
                    [
                        "text" => "We have a vaccine that can help prevent shingles.",
                        "next" => "end",
                        "tag" => "Solution",
                        "score_weight" => "High",
                        "score_level" => "Medium",
                        "feedback" => "Basic information but could be more detailed"
                    ]
                ]
            ]
        ]
    ];
    
    $scoringRules = [
        "weights" => [
            "High" => 3,
            "Medium" => 2,
            "Low" => 1
        ],
        "levels" => [
            "Good" => 3,
            "Medium" => 2,
            "Low" => 1,
            "Bad" => 0
        ]
    ];
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO scenarios (title, description, scenario_data, scoring_rules, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'active', NOW(), NOW())
        ");
        
        $result = $stmt->execute([
            $title,
            $description,
            json_encode($scenarioData),
            json_encode($scoringRules)
        ]);
        
        if ($result) {
            $scenarioId = $pdo->lastInsertId();
            echo "<div class='success'>✅ Sample scenario created successfully!</div>";
            echo "<div class='info'><strong>Scenario ID:</strong> $scenarioId</div>";
            echo "<div class='info'><strong>Title:</strong> $title</div>";
            echo "<div class='info'><strong>Steps:</strong> " . count($scenarioData['steps']) . " steps</div>";
            
            echo "<h3>✅ Next Steps:</h3>";
            echo "<ol>";
            echo "<li>Go to the chat interface: <a href='frontend/chat.html'>frontend/chat.html</a></li>";
            echo "<li>You should now see the sample scenario</li>";
            echo "<li>Try starting a training session</li>";
            echo "<li>Create more scenarios in the admin panel</li>";
            echo "</ol>";
            
        } else {
            echo "<div class='error'>❌ Failed to create scenario</div>";
        }
        
    } catch (PDOException $e) {
        echo "<div class='error'>❌ Database error: " . $e->getMessage() . "</div>";
    }
    
} else {
    // Show form
    echo "<div class='info'>This tool will create a properly formatted sample scenario in your database.</div>";
    
    echo "<h3>📋 Sample Scenario Details:</h3>";
    echo "<ul>";
    echo "<li><strong>Title:</strong> SAAD Scenario - Sample</li>";
    echo "<li><strong>Description:</strong> Advanced counseling scenario with Mr. Saad</li>";
    echo "<li><strong>Steps:</strong> 5 conversation steps with multiple response options</li>";
    echo "<li><strong>Tags:</strong> Greeting, Burden-Risk, Solution</li>";
    echo "<li><strong>Scoring:</strong> Proper weight and level assignments</li>";
    echo "</ul>";
    
    echo "<form method='POST'>";
    echo "<button type='submit' name='create_scenario'>Create Sample Scenario</button>";
    echo "</form>";
    
    echo "<div class='warning'>";
    echo "<h3>⚠️ Before Creating:</h3>";
    echo "<ul>";
    echo "<li>Make sure your database is properly configured</li>";
    echo "<li>This will create a new scenario in your database</li>";
    echo "<li>You can edit or delete it later in the admin panel</li>";
    echo "</ul>";
    echo "</div>";
}

echo "<hr>";
echo "<p><small>🎯 Sample scenario creation tool</small></p>";
?>