<?php
/**
 * Quick Fix for Admin Login Issue
 * This will create the database configuration and admin user
 */

echo "<h1>🚀 Quick Fix - Admin Login Setup</h1>";
echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.success { color: #10b981; background: #f0fdf4; padding: 10px; border-radius: 5px; margin: 10px 0; }
.error { color: #ef4444; background: #fef2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
.warning { color: #f59e0b; background: #fffbeb; padding: 10px; border-radius: 5px; margin: 10px 0; }
.info { color: #3b82f6; background: #eff6ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
form { background: white; padding: 20px; border-radius: 10px; margin: 20px 0; }
input[type=text], input[type=password] { width: 300px; padding: 8px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px; }
button { background: #10b981; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
button:hover { background: #059669; }
</style>";

// Handle form submission
if ($_POST) {
    $dbHost = $_POST['db_host'] ?? '';
    $dbName = $_POST['db_name'] ?? '';
    $dbUser = $_POST['db_user'] ?? '';
    $dbPass = $_POST['db_pass'] ?? '';
    
    if (empty($dbHost) || empty($dbName) || empty($dbUser)) {
        echo "<div class='error'>❌ Please fill in all database fields</div>";
    } else {
        // Create config.local.php
        $configContent = "<?php\n";
        $configContent .= "// Local database configuration\n";
        $configContent .= "\$host = '" . addslashes($dbHost) . "';\n";
        $configContent .= "\$dbname = '" . addslashes($dbName) . "';\n";
        $configContent .= "\$username = '" . addslashes($dbUser) . "';\n";
        $configContent .= "\$password = '" . addslashes($dbPass) . "';\n";
        $configContent .= "?>";
        
        $configPath = __DIR__ . '/backend/config.local.php';
        if (file_put_contents($configPath, $configContent)) {
            echo "<div class='success'>✅ Database configuration saved</div>";
            
            // Test database connection
            try {
                $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4", $dbUser, $dbPass, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);
                
                echo "<div class='success'>✅ Database connection successful</div>";
                
                // Check if admin_users table exists
                try {
                    $stmt = $pdo->query("SHOW TABLES LIKE 'admin_users'");
                    if ($stmt->rowCount() == 0) {
                        echo "<div class='error'>❌ Database tables not found. Please import database/schema.sql first</div>";
                    } else {
                        echo "<div class='success'>✅ Database tables found</div>";
                        
                        // Check if admin user exists
                        $stmt = $pdo->query("SELECT COUNT(*) as count FROM admin_users WHERE status = 'active'");
                        $result = $stmt->fetch();
                        
                        if ($result['count'] == 0) {
                            // Create admin user
                            $adminUsername = 'admin';
                            $adminPassword = 'admin123';
                            $hashedPassword = password_hash($adminPassword, PASSWORD_DEFAULT);
                            
                            $stmt = $pdo->prepare("
                                INSERT INTO admin_users (username, password, role, status, created_at, updated_at)
                                VALUES (?, ?, 'admin', 'active', NOW(), NOW())
                            ");
                            
                            if ($stmt->execute([$adminUsername, $hashedPassword])) {
                                echo "<div class='success'>✅ Admin user created successfully!</div>";
                                echo "<div class='info'><strong>Login with:</strong><br>Username: admin<br>Password: admin123</div>";
                                echo "<div class='success'>🎉 Setup complete! <a href='admin/login.php'>Go to Admin Login</a></div>";
                            } else {
                                echo "<div class='error'>❌ Failed to create admin user</div>";
                            }
                        } else {
                            echo "<div class='success'>✅ Admin user already exists</div>";
                            echo "<div class='success'>🎉 Setup complete! <a href='admin/login.php'>Go to Admin Login</a></div>";
                        }
                    }
                } catch (PDOException $e) {
                    echo "<div class='error'>❌ Database table error: " . $e->getMessage() . "</div>";
                }
                
            } catch (PDOException $e) {
                echo "<div class='error'>❌ Database connection failed: " . $e->getMessage() . "</div>";
            }
        } else {
            echo "<div class='error'>❌ Could not save configuration file</div>";
        }
    }
} else {
    // Show form
    echo "<div class='info'>This tool will help you set up the database connection and create the admin user.</div>";
    
    echo "<form method='POST'>";
    echo "<h3>Database Configuration</h3>";
    echo "<label>Database Host:</label><br>";
    echo "<input type='text' name='db_host' value='localhost' required><br><br>";
    
    echo "<label>Database Name:</label><br>";
    echo "<input type='text' name='db_name' placeholder='your_database_name' required><br><br>";
    
    echo "<label>Database Username:</label><br>";
    echo "<input type='text' name='db_user' placeholder='your_username' required><br><br>";
    
    echo "<label>Database Password:</label><br>";
    echo "<input type='password' name='db_pass' placeholder='your_password'><br><br>";
    
    echo "<button type='submit'>Setup Database & Admin User</button>";
    echo "</form>";
    
    echo "<div class='warning'>";
    echo "<h3>⚠️ Important Notes:</h3>";
    echo "<ul>";
    echo "<li>Make sure your database exists and is accessible</li>";
    echo "<li>You must import <code>database/schema.sql</code> into your database first</li>";
    echo "<li>Delete this file after setup for security</li>";
    echo "</ul>";
    echo "</div>";
}
?>