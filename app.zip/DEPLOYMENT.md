# Shing Chat - Deployment Guide

## 🚀 Production Deployment

### Prerequisites
- PHP 7.4+ with PDO MySQL extension
- MySQL 5.7+ or MariaDB 10.2+
- Apache/Nginx web server
- SSL certificate (recommended)

### Step 1: Upload Files
Upload the entire `software` folder to your web server's document root or subdirectory.

### Step 2: Database Setup
1. Create a MySQL database
2. Import the schema: `mysql -u username -p database_name < database/schema.sql`
3. Verify tables are created successfully

### Step 3: Configuration
1. Copy `backend/config.local.php.example` to `backend/config.local.php`
2. Edit `backend/config.local.php` with your database credentials:
```php
<?php
$host = 'localhost';
$dbname = 'your_database_name';
$username = 'your_db_username';
$password = 'your_db_password';
?>
```

### Step 4: File Permissions
Set appropriate permissions:
```bash
chmod 755 software/
chmod 644 software/*.php
chmod 644 software/backend/*.php
chmod 644 software/admin/*.php
chmod 600 software/backend/config.local.php
```

### Step 5: Create Admin User
1. Visit: `https://yourdomain.com/software/admin/login.php`
2. If no admin exists, the system will create a default admin
3. **Important**: Change the default password immediately

### Step 6: Test Installation
1. **Frontend**: Visit `https://yourdomain.com/software/frontend/index.html`
2. **Admin**: Visit `https://yourdomain.com/software/admin/login.php`
3. **API**: Test scenario loading in the chat interface

## 🔧 Server Configuration

### Apache (.htaccess included)
The included `.htaccess` file provides:
- Security headers
- URL rewriting
- File access restrictions

### Nginx Configuration
Add to your server block:
```nginx
location /software/ {
    try_files $uri $uri/ /software/index.php?$query_string;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    
    # Deny access to sensitive files
    location ~ /\.(git|htaccess|env) {
        deny all;
    }
    
    location ~ /backend/config\.local\.php$ {
        deny all;
    }
}
```

## 🛡️ Security Checklist

### Essential Security Steps
- [ ] Change default admin password
- [ ] Set strong database passwords
- [ ] Enable SSL/HTTPS
- [ ] Set proper file permissions
- [ ] Configure firewall rules
- [ ] Enable error logging
- [ ] Disable PHP error display in production

### Environment Variables (Alternative Config)
Instead of `config.local.php`, you can use environment variables:
```bash
export DB_HOST="localhost"
export DB_NAME="your_database"
export DB_USER="your_username"
export DB_PASS="your_password"
export APP_ENV="production"
```

## 📊 Monitoring & Maintenance

### Log Files
Monitor these log locations:
- PHP errors: `/var/log/php_errors.log`
- Apache errors: `/var/log/apache2/error.log`
- Application logs: Check your server's error log

### Database Maintenance
- Regular backups (daily recommended)
- Monitor database size and performance
- Clean old session data periodically

### Performance Optimization
- Enable PHP OPcache
- Configure MySQL query cache
- Use CDN for static assets
- Enable gzip compression

## 🔄 Updates & Backups

### Backup Strategy
1. **Database**: Daily automated backups
2. **Files**: Weekly full backup
3. **Configuration**: Backup before any changes

### Update Process
1. Backup current installation
2. Test updates in staging environment
3. Deploy during maintenance window
4. Verify functionality post-deployment

## 🚨 Troubleshooting

### Common Issues

**Database Connection Failed**
- Check database credentials in `config.local.php`
- Verify database server is running
- Check firewall/network connectivity

**Admin Login Not Working**
- Verify admin user exists in database
- Check session configuration
- Clear browser cache/cookies

**Scenarios Not Loading**
- Check API endpoints are accessible
- Verify database contains scenario data
- Check browser console for JavaScript errors

**Permission Denied Errors**
- Verify file permissions are correct
- Check web server user has access
- Ensure config files are readable

### Debug Mode
For troubleshooting, temporarily enable debug mode:
```php
// In config.local.php
ini_set('display_errors', 1);
error_reporting(E_ALL);
```
**Remember to disable in production!**

## 📞 Support

### System Requirements Check
Visit `/software/backend/api.php?endpoint=health` to check system status.

### Performance Monitoring
Monitor key metrics:
- Response times
- Database query performance
- Error rates
- User session completion rates

---

**Deployment Version**: 1.0.0  
**Last Updated**: $(date)  
**Status**: Production Ready