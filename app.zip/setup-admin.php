<?php
/**
 * Admin Setup and Database Diagnostic Tool
 * This script will help diagnose database issues and create the admin user
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔧 Shing Chat - Admin Setup & Database Diagnostic</h1>";
echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.success { color: #10b981; background: #f0fdf4; padding: 10px; border-radius: 5px; margin: 10px 0; }
.error { color: #ef4444; background: #fef2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
.warning { color: #f59e0b; background: #fffbeb; padding: 10px; border-radius: 5px; margin: 10px 0; }
.info { color: #3b82f6; background: #eff6ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
pre { background: #1f2937; color: #f9fafb; padding: 15px; border-radius: 5px; overflow-x: auto; }
</style>";

// Step 1: Check if config.local.php exists
echo "<h2>📋 Step 1: Configuration Check</h2>";

$configLocalPath = __DIR__ . '/backend/config.local.php';
if (file_exists($configLocalPath)) {
    echo "<div class='success'>✅ config.local.php found</div>";
    include $configLocalPath;
} else {
    echo "<div class='warning'>⚠️ config.local.php not found</div>";
    echo "<div class='info'>Creating config.local.php with default settings...</div>";
    
    // Create default config.local.php
    $defaultConfig = '<?php
// Local database configuration
// EDIT THESE VALUES FOR YOUR DATABASE
$host = "localhost";
$dbname = "your_database_name";  // CHANGE THIS
$username = "your_db_username";  // CHANGE THIS  
$password = "your_db_password";  // CHANGE THIS
?>';
    
    if (file_put_contents($configLocalPath, $defaultConfig)) {
        echo "<div class='success'>✅ Created config.local.php template</div>";
        echo "<div class='error'>❌ IMPORTANT: Edit backend/config.local.php with your actual database credentials!</div>";
        echo "<pre>$defaultConfig</pre>";
        echo "<p><strong>Please edit the file and refresh this page.</strong></p>";
        exit;
    } else {
        echo "<div class='error'>❌ Could not create config.local.php. Check file permissions.</div>";
    }
}

// Step 2: Test database connection
echo "<h2>🔌 Step 2: Database Connection Test</h2>";

try {
    // Try to include the config
    require_once 'backend/config.php';
    
    if (isset($pdo) && $pdo instanceof PDO) {
        echo "<div class='success'>✅ Database connection successful!</div>";
        echo "<div class='info'>Connected to: " . DB_HOST . "/" . DB_NAME . "</div>";
    } else {
        throw new Exception("PDO object not created");
    }
    
} catch (Exception $e) {
    echo "<div class='error'>❌ Database connection failed: " . $e->getMessage() . "</div>";
    echo "<div class='info'>Please check your database credentials in backend/config.local.php</div>";
    
    // Show current config values (without password)
    echo "<h3>Current Configuration:</h3>";
    echo "<pre>";
    echo "Host: " . ($host ?? 'NOT SET') . "\n";
    echo "Database: " . ($dbname ?? 'NOT SET') . "\n";
    echo "Username: " . ($username ?? 'NOT SET') . "\n";
    echo "Password: " . (isset($password) ? '[SET]' : 'NOT SET') . "\n";
    echo "</pre>";
    
    exit;
}

// Step 3: Check if database tables exist
echo "<h2>🗄️ Step 3: Database Tables Check</h2>";

$requiredTables = ['admin_users', 'scenarios', 'chat_sessions'];
$missingTables = [];

foreach ($requiredTables as $table) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "<div class='success'>✅ Table '$table' exists</div>";
        } else {
            echo "<div class='error'>❌ Table '$table' missing</div>";
            $missingTables[] = $table;
        }
    } catch (PDOException $e) {
        echo "<div class='error'>❌ Error checking table '$table': " . $e->getMessage() . "</div>";
        $missingTables[] = $table;
    }
}

if (!empty($missingTables)) {
    echo "<div class='warning'>⚠️ Missing tables detected. You need to import the database schema.</div>";
    echo "<div class='info'>Run this command: <code>mysql -u username -p database_name < database/schema.sql</code></div>";
    echo "<div class='info'>Or use phpMyAdmin to import database/schema.sql</div>";
}

// Step 4: Check admin users
echo "<h2>👤 Step 4: Admin User Check</h2>";

try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM admin_users WHERE status = 'active'");
    $result = $stmt->fetch();
    $adminCount = $result['count'];
    
    if ($adminCount > 0) {
        echo "<div class='success'>✅ Found $adminCount active admin user(s)</div>";
        
        // Show existing admins (without passwords)
        $stmt = $pdo->query("SELECT id, username, role, created_at FROM admin_users WHERE status = 'active'");
        echo "<h3>Existing Admin Users:</h3>";
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Username</th><th>Role</th><th>Created</th></tr>";
        while ($admin = $stmt->fetch()) {
            echo "<tr>";
            echo "<td>" . $admin['id'] . "</td>";
            echo "<td>" . htmlspecialchars($admin['username']) . "</td>";
            echo "<td>" . $admin['role'] . "</td>";
            echo "<td>" . $admin['created_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
    } else {
        echo "<div class='warning'>⚠️ No active admin users found</div>";
        echo "<div class='info'>Creating default admin user...</div>";
        
        // Create default admin user
        $adminUsername = 'admin';
        $adminPassword = 'admin123';
        $hashedPassword = password_hash($adminPassword, PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("
            INSERT INTO admin_users (username, password, role, status, created_at, updated_at)
            VALUES (?, ?, 'admin', 'active', NOW(), NOW())
        ");
        
        if ($stmt->execute([$adminUsername, $hashedPassword])) {
            echo "<div class='success'>✅ Default admin user created successfully!</div>";
            echo "<div class='info'>";
            echo "<strong>Login Credentials:</strong><br>";
            echo "Username: <code>admin</code><br>";
            echo "Password: <code>admin123</code><br>";
            echo "</div>";
            echo "<div class='warning'>⚠️ Please change the password after first login!</div>";
        } else {
            echo "<div class='error'>❌ Failed to create admin user</div>";
        }
    }
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Error checking admin users: " . $e->getMessage() . "</div>";
}

// Step 5: Test login functionality
echo "<h2>🔐 Step 5: Login Test</h2>";

try {
    $testUsername = 'admin';
    $testPassword = 'admin123';
    
    $stmt = $pdo->prepare("SELECT id, username, password, role FROM admin_users WHERE username = ? AND status = 'active'");
    $stmt->execute([$testUsername]);
    $admin = $stmt->fetch();
    
    if ($admin) {
        if (password_verify($testPassword, $admin['password'])) {
            echo "<div class='success'>✅ Login test successful! Admin login should work.</div>";
        } else {
            echo "<div class='error'>❌ Password verification failed. The password might be different.</div>";
        }
    } else {
        echo "<div class='error'>❌ Admin user not found or inactive.</div>";
    }
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Login test failed: " . $e->getMessage() . "</div>";
}

// Step 6: Final recommendations
echo "<h2>🎯 Step 6: Next Steps</h2>";

echo "<div class='info'>";
echo "<h3>If everything looks good:</h3>";
echo "<ol>";
echo "<li>Try logging in at: <a href='admin/login.php'>admin/login.php</a></li>";
echo "<li>Use username: <code>admin</code> and password: <code>admin123</code></li>";
echo "<li>Change the password immediately after login</li>";
echo "<li>Delete this setup file: <code>setup-admin.php</code></li>";
echo "</ol>";
echo "</div>";

echo "<div class='warning'>";
echo "<h3>If you still have issues:</h3>";
echo "<ol>";
echo "<li>Check your database credentials in <code>backend/config.local.php</code></li>";
echo "<li>Make sure the database exists and is accessible</li>";
echo "<li>Import the database schema from <code>database/schema.sql</code></li>";
echo "<li>Check file permissions on the backend folder</li>";
echo "</ol>";
echo "</div>";

echo "<hr>";
echo "<p><small>🔧 Setup completed at " . date('Y-m-d H:i:s') . "</small></p>";
?>