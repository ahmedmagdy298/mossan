<?php
/**
 * Debug Scenarios API Response
 */

echo "<h1>🔍 Debug Scenarios API</h1>";
echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.success { color: #10b981; background: #f0fdf4; padding: 10px; border-radius: 5px; margin: 10px 0; }
.error { color: #ef4444; background: #fef2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
.warning { color: #f59e0b; background: #fffbeb; padding: 10px; border-radius: 5px; margin: 10px 0; }
.info { color: #3b82f6; background: #eff6ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
pre { background: #1f2937; color: #f9fafb; padding: 15px; border-radius: 5px; overflow-x: auto; max-height: 400px; }
</style>";

// Test database connection
try {
    require_once 'backend/config.php';
    echo "<div class='success'>✅ Database connected</div>";
} catch (Exception $e) {
    echo "<div class='error'>❌ Database error: " . $e->getMessage() . "</div>";
    exit;
}

// Check scenarios in database
echo "<h2>📊 Database Scenarios</h2>";
try {
    $stmt = $pdo->query("SELECT id, title, description, scenario_data, scoring_rules, status FROM scenarios WHERE status = 'active' LIMIT 3");
    $scenarios = $stmt->fetchAll();
    
    if (empty($scenarios)) {
        echo "<div class='warning'>⚠️ No active scenarios found in database</div>";
        echo "<div class='info'>You need to create scenarios in the admin panel first</div>";
    } else {
        echo "<div class='success'>✅ Found " . count($scenarios) . " scenarios</div>";
        
        foreach ($scenarios as $i => $scenario) {
            echo "<h3>Scenario " . ($i + 1) . ": " . htmlspecialchars($scenario['title']) . " (ID: " . $scenario['id'] . ")</h3>";
            echo "<p><strong>Description:</strong> " . htmlspecialchars($scenario['description']) . "</p>";
            
            echo "<h4>Raw scenario_data (first 200 chars):</h4>";
            $rawData = $scenario['scenario_data'];
            if (empty($rawData)) {
                echo "<div class='error'>❌ scenario_data is EMPTY</div>";
            } else {
                echo "<pre>" . htmlspecialchars(substr($rawData, 0, 200)) . (strlen($rawData) > 200 ? '...' : '') . "</pre>";
            }
            
            echo "<h4>Parsed scenario_data:</h4>";
            try {
                if (empty($rawData)) {
                    echo "<div class='error'>❌ Cannot parse empty scenario_data</div>";
                } else {
                    $parsed = json_decode($rawData, true);
                    if ($parsed) {
                        echo "<pre>" . json_encode($parsed, JSON_PRETTY_PRINT) . "</pre>";
                        
                        // Check if steps exist
                        if (isset($parsed['steps'])) {
                            if (is_array($parsed['steps']) && count($parsed['steps']) > 0) {
                                echo "<div class='success'>✅ Steps found: " . count($parsed['steps']) . " steps</div>";
                            } else {
                                echo "<div class='error'>❌ Steps array is empty</div>";
                            }
                        } else {
                            echo "<div class='error'>❌ No 'steps' property found in scenario_data</div>";
                            if (is_array($parsed)) {
                                echo "<div class='info'>Available keys: " . implode(', ', array_keys($parsed)) . "</div>";
                            }
                        }
                    } else {
                        echo "<div class='error'>❌ Failed to parse JSON - invalid format</div>";
                        echo "<div class='info'>JSON Error: " . json_last_error_msg() . "</div>";
                    }
                }
            } catch (Exception $e) {
                echo "<div class='error'>❌ JSON parse error: " . $e->getMessage() . "</div>";
            }
            
            echo "<hr>";
        }
    }
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database query error: " . $e->getMessage() . "</div>";
}

// Test API endpoint
echo "<h2>🔌 API Endpoint Test</h2>";
try {
    // Simulate the API call
    $_GET['endpoint'] = 'scenarios';
    
    ob_start();
    include 'backend/api.php';
    $apiOutput = ob_get_clean();
    
    echo "<h3>Raw API Output:</h3>";
    echo "<pre>" . htmlspecialchars($apiOutput) . "</pre>";
    
    // Extract JSON from the output (ignore PHP warnings)
    $jsonStart = strpos($apiOutput, '{"success"');
    if ($jsonStart !== false) {
        $jsonOutput = substr($apiOutput, $jsonStart);
        echo "<h3>Extracted JSON:</h3>";
        echo "<pre>" . htmlspecialchars($jsonOutput) . "</pre>";
        
        $apiData = json_decode($jsonOutput, true);
    } else {
        $apiData = json_decode($apiOutput, true);
    }
    
    if ($apiData) {
        echo "<h3>Parsed API Response:</h3>";
        echo "<pre>" . json_encode($apiData, JSON_PRETTY_PRINT) . "</pre>";
        
        if (isset($apiData['success']) && $apiData['success'] && isset($apiData['data'])) {
            echo "<div class='success'>✅ API working correctly</div>";
            
            if (!empty($apiData['data'])) {
                $firstScenario = $apiData['data'][0];
                echo "<h3>First Scenario Structure:</h3>";
                echo "<pre>" . json_encode($firstScenario, JSON_PRETTY_PRINT) . "</pre>";
                
                // Check scenario_data structure
                if (isset($firstScenario['scenario_data'])) {
                    echo "<h3>Scenario Data Analysis:</h3>";
                    $scenarioData = is_string($firstScenario['scenario_data']) 
                        ? json_decode($firstScenario['scenario_data'], true) 
                        : $firstScenario['scenario_data'];
                    
                    if ($scenarioData) {
                        echo "<div class='info'>Scenario data keys: " . implode(', ', array_keys($scenarioData)) . "</div>";
                        
                        if (isset($scenarioData['steps'])) {
                            echo "<div class='success'>✅ Steps found: " . count($scenarioData['steps']) . " steps</div>";
                        } else {
                            echo "<div class='error'>❌ No 'steps' property in scenario_data</div>";
                        }
                    } else {
                        echo "<div class='error'>❌ Could not parse scenario_data</div>";
                    }
                }
            }
        } else {
            echo "<div class='error'>❌ API returned error or no data</div>";
        }
    } else {
        echo "<div class='error'>❌ Could not parse API response as JSON</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='error'>❌ API test error: " . $e->getMessage() . "</div>";
}

echo "<h2>🎯 Recommendations</h2>";
echo "<div class='info'>";
echo "<h3>If scenarios exist but have no steps:</h3>";
echo "<ul>";
echo "<li>The scenario_data in the database might be empty or malformed</li>";
echo "<li>Create new scenarios using the admin panel's Enhanced Editor</li>";
echo "<li>Make sure scenarios have proper step structure</li>";
echo "</ul>";
echo "</div>";

echo "<div class='warning'>";
echo "<h3>If no scenarios exist:</h3>";
echo "<ul>";
echo "<li>Login to admin panel and create scenarios</li>";
echo "<li>Use the Enhanced Editor (magic wand icon) for easy creation</li>";
echo "<li>Make sure to save the scenarios</li>";
echo "</ul>";
echo "</div>";
?>