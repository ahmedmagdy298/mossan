-- Shing Chat Database Schema - Hosting Compatible Version
-- This version works with shared hosting that doesn't support stored procedures/triggers
-- All advanced features are handled in PHP code instead

-- Admin users table
CREATE TABLE admin_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'moderator') DEFAULT 'admin',
    status ENUM('active', 'inactive') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Scenarios table
CREATE TABLE scenarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    scenario_data JSON NOT NULL,
    scoring_rules JSON NOT NULL,
    status ENUM('active', 'inactive', 'deleted') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- Chat sessions table
CREATE TABLE chat_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    scenario_id INT,
    user_id VARCHAR(100) NULL,
    session_data JSON NOT NULL,
    final_score DECIMAL(5,2) NOT NULL,
    duration INT NOT NULL, -- in seconds
    status ENUM('completed', 'abandoned', 'error') DEFAULT 'completed',
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (scenario_id) REFERENCES scenarios(id) ON DELETE SET NULL,
    INDEX idx_scenario_id (scenario_id),
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at),
    INDEX idx_status (status)
);

-- Session responses table (for detailed analysis)
CREATE TABLE session_responses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    step_id VARCHAR(50) NOT NULL,
    response_text TEXT NOT NULL,
    response_tag VARCHAR(100),
    score_weight ENUM('High', 'Medium', 'Low') NOT NULL,
    score_level ENUM('Good', 'Medium', 'Low', 'Bad') NOT NULL,
    points_earned INT NOT NULL,
    max_points INT NOT NULL,
    response_order INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
    INDEX idx_session_id (session_id),
    INDEX idx_response_tag (response_tag),
    INDEX idx_score_weight (score_weight),
    INDEX idx_score_level (score_level)
);

-- Tag performance tracking
CREATE TABLE tag_performance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tag_name VARCHAR(100) NOT NULL,
    session_id INT NOT NULL,
    total_responses INT NOT NULL,
    good_responses INT NOT NULL,
    medium_responses INT NOT NULL,
    bad_responses INT NOT NULL,
    total_points INT NOT NULL,
    max_points INT NOT NULL,
    performance_percentage DECIMAL(5,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
    INDEX idx_tag_name (tag_name),
    INDEX idx_session_id (session_id),
    INDEX idx_performance (performance_percentage),
    INDEX idx_created_at (created_at)
);

-- Admin activity logs
CREATE TABLE admin_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    admin_id INT NULL,
    action VARCHAR(100) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (admin_id) REFERENCES admin_users(id) ON DELETE SET NULL,
    INDEX idx_admin_id (admin_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
);

-- System settings table
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_setting_key (setting_key)
);

-- User analytics (for anonymous user tracking)
CREATE TABLE user_analytics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id VARCHAR(100) NOT NULL,
    total_sessions INT DEFAULT 0,
    total_score_points INT DEFAULT 0,
    total_max_points INT DEFAULT 0,
    average_score DECIMAL(5,2) DEFAULT 0,
    total_duration INT DEFAULT 0, -- in seconds
    first_session TIMESTAMP NULL,
    last_session TIMESTAMP NULL,
    favorite_scenario_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_user (user_id),
    FOREIGN KEY (favorite_scenario_id) REFERENCES scenarios(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_average_score (average_score),
    INDEX idx_last_session (last_session)
);

-- Note: Default admin user creation removed for security
-- Use the secure admin creation tool in the application instead

-- Insert default system settings
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('app_name', 'Shing Chat', 'Application name'),
('app_version', '1.0.0', 'Application version'),
('max_session_duration', '3600', 'Maximum session duration in seconds'),
('enable_analytics', '1', 'Enable analytics tracking'),
('enable_user_tracking', '1', 'Enable anonymous user tracking'),
('session_timeout', '1800', 'Session timeout in seconds'),
('max_scenarios_per_user', '10', 'Maximum scenarios per user per day'),
('enable_export', '1', 'Enable data export functionality');

-- Insert sample scenario (SAAD Scenario)
INSERT INTO scenarios (title, description, scenario_data, scoring_rules) VALUES (
    'SAAD Scenario',
    'Advanced counseling scenario with Mr. Saad around shingles risk and vaccination.',
    '{
        "steps": [
            {
                "id": "greeting",
                "speaker": "bot",
                "message": "SAAD Scenario",
                "responses": [
                    {
                        "text": "Good morning, Mr. Saad. How are you doing?",
                        "next": "a1",
                        "tag": "Greeting",
                        "score_weight": "High",
                        "score_level": "Good",
                        "feedback": "Excellent opening - establishes rapport and shows genuine concern"
                    },
                    {
                        "text": "Long time no see, Mr. Saad. I hope you are in good health!",
                        "next": "b1",
                        "tag": "Greeting",
                        "score_weight": "High",
                        "score_level": "Good",
                        "feedback": "Warm greeting that acknowledges the relationship and shows care"
                    },
                    {
                        "text": "Says Nothing.",
                        "next": "c1",
                        "tag": "Greeting",
                        "score_weight": "High",
                        "score_level": "Bad",
                        "feedback": "Missed opportunity to establish rapport and connection"
                    }
                ]
            },
            {
                "id": "a1",
                "speaker": "patient",
                "message": "Honestly? Feeling my age, I do not think I am doing well.",
                "responses": [
                    {
                        "text": "Your age and lung history puts you at severe risks like shingles.",
                        "next": "a2",
                        "tag": "Burden-Risk",
                        "score_weight": "High",
                        "score_level": "Good",
                        "feedback": "Good acknowledgment of risk factors and direct communication"
                    },
                    {
                        "text": "Given the history of your lung conditions, you must not be doing your best. You can be at risk of diseases here.",
                        "next": "a2",
                        "tag": "Burden-Risk",
                        "score_weight": "High",
                        "score_level": "Medium",
                        "feedback": "Addresses risk but could be more empathetic in delivery"
                    }
                ]
            }
        ]
    }',
    '{
        "weights": {
            "High": 3,
            "Medium": 2,
            "Low": 1
        },
        "levels": {
            "Good": 3,
            "Medium": 2,
            "Low": 1,
            "Bad": 0
        },
        "tag_mapping": {
            "Greeting": "Initial patient interaction and rapport building",
            "Burden-Risk": "Communicating disease risks and susceptibility",
            "Burden-Symptoms": "Describing disease symptoms and complications",
            "Solution": "Presenting treatment or prevention options",
            "Safety": "Addressing safety concerns and side effects"
        }
    }'
);

-- Create indexes for better performance
CREATE INDEX idx_sessions_score ON chat_sessions(final_score);
CREATE INDEX idx_sessions_duration ON chat_sessions(duration);
CREATE INDEX idx_responses_points ON session_responses(points_earned);
CREATE INDEX idx_tag_performance_date ON tag_performance(created_at);

-- Database setup complete
-- All tables, indexes, and sample data have been created
-- The application is ready to use with any hosting provider