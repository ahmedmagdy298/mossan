<?php
/**
 * Fix Scenarios Tool - Clean up empty scenarios and create proper ones
 */

echo "<h1>🔧 Fix Scenarios Tool</h1>";
echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.success { color: #10b981; background: #f0fdf4; padding: 10px; border-radius: 5px; margin: 10px 0; }
.error { color: #ef4444; background: #fef2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
.warning { color: #f59e0b; background: #fffbeb; padding: 10px; border-radius: 5px; margin: 10px 0; }
.info { color: #3b82f6; background: #eff6ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
button { background: #10b981; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
button:hover { background: #059669; }
.danger { background: #ef4444; }
.danger:hover { background: #dc2626; }
</style>";

// Test database connection
try {
    require_once 'backend/config.php';
    echo "<div class='success'>✅ Database connected</div>";
} catch (Exception $e) {
    echo "<div class='error'>❌ Database error: " . $e->getMessage() . "</div>";
    exit;
}

// Handle actions
if ($_POST) {
    if (isset($_POST['delete_empty'])) {
        // Delete scenarios with empty or invalid scenario_data
        try {
            $stmt = $pdo->prepare("DELETE FROM scenarios WHERE scenario_data IS NULL OR scenario_data = '' OR scenario_data = '{}' OR scenario_data = 'null'");
            $deleted = $stmt->execute();
            $count = $stmt->rowCount();
            
            if ($deleted) {
                echo "<div class='success'>✅ Deleted $count empty scenarios</div>";
            } else {
                echo "<div class='info'>ℹ️ No empty scenarios found to delete</div>";
            }
        } catch (PDOException $e) {
            echo "<div class='error'>❌ Error deleting scenarios: " . $e->getMessage() . "</div>";
        }
    }
    
    if (isset($_POST['create_sample'])) {
        // Create a proper sample scenario
        $title = "SAAD Scenario - Working Sample";
        $description = "Advanced counseling scenario with Mr. Saad around shingles risk and vaccination.";
        
        $scenarioData = [
            "steps" => [
                [
                    "id" => "greeting",
                    "speaker" => "bot",
                    "message" => "SAAD Scenario - You are meeting with Mr. Saad, a 65-year-old patient with a history of lung conditions. How would you like to start the consultation?",
                    "responses" => [
                        [
                            "text" => "Good morning, Mr. Saad. How are you doing today?",
                            "next" => "response1",
                            "tag" => "Greeting",
                            "score_weight" => "High",
                            "score_level" => "Good",
                            "feedback" => "Excellent opening - establishes rapport and shows genuine concern"
                        ],
                        [
                            "text" => "Long time no see, Mr. Saad. I hope you're in good health!",
                            "next" => "response2",
                            "tag" => "Greeting",
                            "score_weight" => "High",
                            "score_level" => "Good",
                            "feedback" => "Warm greeting that acknowledges the relationship and shows care"
                        ],
                        [
                            "text" => "Says Nothing.",
                            "next" => "response3",
                            "tag" => "Greeting",
                            "score_weight" => "High",
                            "score_level" => "Bad",
                            "feedback" => "Missed opportunity to establish rapport and connection"
                        ]
                    ]
                ],
                [
                    "id" => "response1",
                    "speaker" => "patient",
                    "message" => "Honestly? Feeling my age, I don't think I am doing well.",
                    "responses" => [
                        [
                            "text" => "Your age and lung history puts you at severe risks like shingles. There's a vaccine that can help protect you.",
                            "next" => "end",
                            "tag" => "Solution",
                            "score_weight" => "High",
                            "score_level" => "Good",
                            "feedback" => "Good acknowledgment of risk factors and direct solution"
                        ],
                        [
                            "text" => "Let's discuss some preventive measures we can take.",
                            "next" => "end",
                            "tag" => "Solution",
                            "score_weight" => "Medium",
                            "score_level" => "Medium",
                            "feedback" => "General approach but could be more specific"
                        ]
                    ]
                ],
                [
                    "id" => "response2",
                    "speaker" => "patient",
                    "message" => "Am I? Not really, doctor. Tell me, why did you ask for this appointment?",
                    "responses" => [
                        [
                            "text" => "I wanted to discuss your risk for shingles and how we can prevent it with vaccination.",
                            "next" => "end",
                            "tag" => "Solution",
                            "score_weight" => "High",
                            "score_level" => "Good",
                            "feedback" => "Clear explanation of purpose and solution"
                        ]
                    ]
                ],
                [
                    "id" => "response3",
                    "speaker" => "patient",
                    "message" => "Mr. Saad looks at you expectantly, waiting for you to explain the purpose of the appointment.",
                    "responses" => [
                        [
                            "text" => "I wanted to discuss your risk for shingles and how we can prevent it.",
                            "next" => "end",
                            "tag" => "Solution",
                            "score_weight" => "Medium",
                            "score_level" => "Medium",
                            "feedback" => "Direct approach but could benefit from more rapport building"
                        ]
                    ]
                ]
            ]
        ];
        
        $scoringRules = [
            "weights" => [
                "High" => 3,
                "Medium" => 2,
                "Low" => 1
            ],
            "levels" => [
                "Good" => 3,
                "Medium" => 2,
                "Low" => 1,
                "Bad" => 0
            ]
        ];
        
        try {
            $stmt = $pdo->prepare("
                INSERT INTO scenarios (title, description, scenario_data, scoring_rules, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, 'active', NOW(), NOW())
            ");
            
            $result = $stmt->execute([
                $title,
                $description,
                json_encode($scenarioData),
                json_encode($scoringRules)
            ]);
            
            if ($result) {
                $scenarioId = $pdo->lastInsertId();
                echo "<div class='success'>✅ Working sample scenario created successfully!</div>";
                echo "<div class='info'><strong>Scenario ID:</strong> $scenarioId</div>";
                echo "<div class='info'><strong>Steps:</strong> " . count($scenarioData['steps']) . " conversation steps</div>";
            } else {
                echo "<div class='error'>❌ Failed to create scenario</div>";
            }
            
        } catch (PDOException $e) {
            echo "<div class='error'>❌ Database error: " . $e->getMessage() . "</div>";
        }
    }
}

// Show current scenarios
echo "<h2>📊 Current Scenarios</h2>";
try {
    $stmt = $pdo->query("SELECT id, title, description, scenario_data, status FROM scenarios WHERE status = 'active'");
    $scenarios = $stmt->fetchAll();
    
    if (empty($scenarios)) {
        echo "<div class='warning'>⚠️ No active scenarios found</div>";
    } else {
        echo "<table border='1' cellpadding='10' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Title</th><th>Description</th><th>Has Steps</th><th>Status</th></tr>";
        
        $emptyCount = 0;
        $validCount = 0;
        
        foreach ($scenarios as $scenario) {
            $hasSteps = false;
            $stepCount = 0;
            
            if (!empty($scenario['scenario_data'])) {
                try {
                    $data = json_decode($scenario['scenario_data'], true);
                    if ($data && isset($data['steps']) && is_array($data['steps'])) {
                        $hasSteps = true;
                        $stepCount = count($data['steps']);
                        $validCount++;
                    } else {
                        $emptyCount++;
                    }
                } catch (Exception $e) {
                    $emptyCount++;
                }
            } else {
                $emptyCount++;
            }
            
            $rowClass = $hasSteps ? 'success' : 'error';
            echo "<tr style='background: " . ($hasSteps ? '#f0fdf4' : '#fef2f2') . ";'>";
            echo "<td>" . $scenario['id'] . "</td>";
            echo "<td>" . htmlspecialchars($scenario['title']) . "</td>";
            echo "<td>" . htmlspecialchars($scenario['description']) . "</td>";
            echo "<td>" . ($hasSteps ? "✅ $stepCount steps" : "❌ No steps") . "</td>";
            echo "<td>" . $scenario['status'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        echo "<div class='info'>";
        echo "<strong>Summary:</strong> $validCount valid scenarios, $emptyCount empty/invalid scenarios";
        echo "</div>";
    }
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database query error: " . $e->getMessage() . "</div>";
}

echo "<h2>🔧 Actions</h2>";

echo "<form method='POST' style='margin: 20px 0;'>";
echo "<button type='submit' name='delete_empty' class='danger' onclick='return confirm(\"Are you sure you want to delete all empty scenarios?\")'>🗑️ Delete Empty Scenarios</button>";
echo "<button type='submit' name='create_sample'>✨ Create Working Sample Scenario</button>";
echo "</form>";

echo "<h2>🎯 Next Steps</h2>";
echo "<div class='info'>";
echo "<ol>";
echo "<li><strong>Delete empty scenarios</strong> - Remove scenarios without proper step data</li>";
echo "<li><strong>Create sample scenario</strong> - Add a working scenario with proper structure</li>";
echo "<li><strong>Test frontend</strong> - Visit <a href='frontend/chat.html'>frontend/chat.html</a></li>";
echo "<li><strong>Create more scenarios</strong> - Use admin panel to add more scenarios</li>";
echo "</ol>";
echo "</div>";

echo "<div class='warning'>";
echo "<h3>⚠️ Important:</h3>";
echo "<ul>";
echo "<li>Empty scenarios cause the 'Cannot read properties of undefined' error</li>";
echo "<li>All scenarios must have a 'steps' array in their scenario_data</li>";
echo "<li>Use the Enhanced Editor in admin panel for creating new scenarios</li>";
echo "</ul>";
echo "</div>";
?>