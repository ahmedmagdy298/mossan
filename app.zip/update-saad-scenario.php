<?php
/**
 * Update SAAD Scenario with New Data
 * This script updates the existing SAAD scenario with the comprehensive new scenario data
 */

require_once 'backend/config.php';

// New SAAD scenario data with clickable tag links
$newScenarioData = [
    "title" => "Shingrix Counseling – Mr. Saad",
    "description" => "Guide Mr. Saad through understanding his shingles risk and the benefits of Shingrix vaccination.",
    "scenario_data" => [
        "steps" => [
            [
                "id" => "greeting",
                "speaker" => "bot",
                "message" => "SAAD Scenario",
                "responses" => [
                    [
                        "text" => "Good morning, Mr. Saad. How are you doing?",
                        "next" => "a1",
                        "tag" => "Greeting",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Long time no see, Mr. Saad. I hope you're in good health!",
                        "next" => "b1",
                        "tag" => "Greeting",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Says nothing.",
                        "next" => "c1",
                        "tag" => "Greeting",
                        "score_weight" => "High",
                        "score_level" => "Bad"
                    ]
                ]
            ],
            [
                "id" => "a1",
                "speaker" => "patient",
                "message" => "Honestly? Feeling my age, I don't think I am doing well.",
                "responses" => [
                    [
                        "text" => "Your age and lung history puts you at severe risks like shingles.",
                        "next" => "a2",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Given the history of your lung conditions, you must not be doing your best. You can be at risk of diseases here.",
                        "next" => "a2",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Bad"
                    ]
                ]
            ],
            [
                "id" => "a2",
                "speaker" => "patient",
                "message" => "What do you mean?",
                "responses" => [
                    [
                        "text" => "Shingles is a painful rash that results from the childhood chickenpox virus reactivating. Luckily, it's preventable.",
                        "next" => "a3",
                        "tag" => "Burden-Symptoms & Comp",
                        "score_weight" => "High",
                        "score_level" => "Medium"
                    ],
                    [
                        "text" => "Did you know that 1 in 3 adults will develop shingles? You may be more prone due to your lung condition.",
                        "next" => "a3",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Medium"
                    ]
                ]
            ],
            [
                "id" => "a3",
                "speaker" => "patient",
                "message" => "Healthy ageing still sounds like a myth to me.",
                "responses" => [
                    [
                        "text" => "I want to talk about a proactive step we can take towards your ongoing health and well-being.",
                        "next" => "ab",
                        "tag" => "Education-Engagement",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "You are already at a huge risk of developing shingles.",
                        "next" => "ab",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Medium"
                    ]
                ]
            ],
            [
                "id" => "ab",
                "speaker" => "patient",
                "message" => "I'm too old for vaccines. Is it even worth it at this point?",
                "responses" => [
                    [
                        "text" => "Shingrix is effective for those over 70, greatly reducing shingles risk and preventing complications.",
                        "next" => "ab1",
                        "tag" => "Burden-Impact on quality of life",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Shingrix, a 2-dose vaccine, is over 90% effective against shingles for individuals over 50 and those with conditions like chronic lung disease.",
                        "next" => "ab1",
                        "tag" => "Burden-Symptoms & Comp",
                        "score_weight" => "High",
                        "score_level" => "Medium"
                    ]
                ]
            ],
            [
                "id" => "ab1",
                "speaker" => "patient",
                "message" => "So, you're saying there's still value in vaccination even at my age?",
                "responses" => [
                    [
                        "text" => "Shingrix is effective for those over 70, greatly reducing shingles risk and preventing complications.",
                        "next" => "ab2",
                        "tag" => "Burden-Symptoms & Comp",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Shingrix could be your key to staying active and fully functioning without worrying about shingles interrupting your plans.",
                        "next" => "ab2",
                        "tag" => "Burden-Impact on quality of life",
                        "score_weight" => "High",
                        "score_level" => "Medium"
                    ]
                ]
            ],
            [
                "id" => "ab2",
                "speaker" => "patient",
                "message" => "I understand, but I don't think I really need it…",
                "responses" => [
                    [
                        "text" => "Shingrix provides durable protection, potentially sparing you time and effort by preventing shingles outbreaks.",
                        "next" => "ab3",
                        "tag" => "Education-Engagement",
                        "score_weight" => "Medium",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "As immunity wanes with age, the dormant virus can cause shingles. Shingrix enhances your defenses, providing significant protection.",
                        "next" => "ab3",
                        "tag" => "Burden-Symptoms & Comp",
                        "score_weight" => "Medium",
                        "score_level" => "Medium"
                    ]
                ]
            ],
            [
                "id" => "ab3",
                "speaker" => "patient",
                "message" => "Vaccines and chemicals … I never liked vaccines.",
                "responses" => [
                    [
                        "text" => "Shingrix has passed extensive safety tests. Side effects are usually mild and brief, such as injection site soreness. The benefits far outweigh the risks.",
                        "next" => "abcend",
                        "tag" => "Safety",
                        "score_weight" => "Medium",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Shingles can be unpredictable and potentially debilitating. The vaccine is a proactive measure to prevent this pain and disruption.",
                        "next" => "abcend",
                        "tag" => "Safety",
                        "score_weight" => "Medium",
                        "score_level" => "Good"
                    ]
                ]
            ],
            [
                "id" => "b1",
                "speaker" => "patient",
                "message" => "Am I? Not really, doctor. Tell me, why did you ask for this appointment?",
                "responses" => [
                    [
                        "text" => "As aging weakens our immune system, susceptibility to illnesses increases.",
                        "next" => "b2",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Shingles is a painful rash affecting older adults, and the risk is even higher with your lung condition.",
                        "next" => "b2",
                        "tag" => "Burden-Symptoms & Comp",
                        "score_weight" => "High",
                        "score_level" => "Bad"
                    ]
                ]
            ],
            [
                "id" => "b2",
                "speaker" => "patient",
                "message" => "How does that prevent me from living life to the fullest?",
                "responses" => [
                    [
                        "text" => "Our immune systems weaken with age, making us more prone to dormant virus reactivation, such as shingles.",
                        "next" => "a3",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Shingles is painful and can impact your daily life activities.",
                        "next" => "a3",
                        "tag" => "Burden-Impact on quality of life",
                        "score_weight" => "High",
                        "score_level" => "Medium"
                    ]
                ]
            ],
            [
                "id" => "c1",
                "speaker" => "patient",
                "message" => "Can you get to the point, doctor? I am an old man, but that doesn't mean I have all day.",
                "responses" => [
                    [
                        "text" => "Shingles is a painful rash affecting older adults, and the risk is even higher with your lung condition.",
                        "next" => "c2",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Did you know that 1 in 3 adults will develop shingles? You may be more prone due to your lung condition.",
                        "next" => "c2",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Bad"
                    ]
                ]
            ],
            [
                "id" => "c2",
                "speaker" => "patient",
                "message" => "Can you tell me more about it?",
                "responses" => [
                    [
                        "text" => "Shingles can have serious long-term effects. The 2-dose shingles vaccine is highly effective and available to prevent it.",
                        "next" => "c3",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Shingles is a painful rash and its complications.",
                        "next" => "c3",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Bad"
                    ]
                ]
            ],
            [
                "id" => "c3",
                "speaker" => "patient",
                "message" => "And how do you intend to 'protect' me from this?",
                "responses" => [
                    [
                        "text" => "Shingrix offers long-lasting shingles protection to prevent a painful rash that could impact your life for weeks or months.",
                        "next" => "c4",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Shingrix, a 2-dose vaccine, is over 90% effective against shingles for individuals over 50 and those with conditions like chronic lung disease.",
                        "next" => "c4",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Bad"
                    ]
                ]
            ],
            [
                "id" => "c4",
                "speaker" => "patient",
                "message" => "I don't have time for another visit and the whole vaccine process.",
                "responses" => [
                    [
                        "text" => "Shingrix is an investment in your well-being, potentially saving you months of pain.",
                        "next" => "c5",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "You only need two visits. The second dose is spaced 2–6 months after the first.",
                        "next" => "c5",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Bad"
                    ]
                ]
            ],
            [
                "id" => "c5",
                "speaker" => "patient",
                "message" => "I already had chickenpox as a kid, isn't that enough immunity?",
                "responses" => [
                    [
                        "text" => "Having chickenpox means the varicella-zoster virus lingers in your nerves, potentially turning into shingles. Shingrix targets this, lowering your risk.",
                        "next" => "c6",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "As immunity wanes with age, the dormant virus can cause shingles. Shingrix enhances your defenses, providing significant protection.",
                        "next" => "c6",
                        "tag" => "Burden-Risk",
                        "score_weight" => "High",
                        "score_level" => "Medium"
                    ]
                ]
            ],
            [
                "id" => "c6",
                "speaker" => "patient",
                "message" => "I don't get sick often, so why bother with the vaccine?",
                "responses" => [
                    [
                        "text" => "Shingrix has passed extensive safety tests. Side effects are usually mild and brief, such as injection site soreness. The benefits far outweigh the risks.",
                        "next" => "abcend",
                        "tag" => "Safety",
                        "score_weight" => "High",
                        "score_level" => "Good"
                    ],
                    [
                        "text" => "Shingles can be unpredictable and potentially debilitating. The vaccine is a proactive measure to prevent this pain and disruption.",
                        "next" => "abcend",
                        "tag" => "Safety",
                        "score_weight" => "High",
                        "score_level" => "Medium"
                    ]
                ]
            ],
            [
                "id" => "abcend",
                "speaker" => "patient",
                "message" => "I get your point, doctor. I think I need Shingrix.",
                "responses" => []
            ]
        ]
    ],
    "scoring_rules" => [
        "weights" => [
            "High" => 3,
            "Medium" => 2,
            "Low" => 1
        ],
        "levels" => [
            "Good" => 3,
            "Medium" => 2,
            "Low" => 1,
            "Bad" => 0
        ],
        "tag_mapping" => [
            "Greeting" => [
                "description" => "Initial rapport building and patient engagement",
                "link" => "https://example.com/training/greeting"
            ],
            "Burden-Risk" => [
                "description" => "Communicating susceptibility and risk factors",
                "link" => "https://example.com/training/risk-communication"
            ],
            "Burden-Symptoms & Comp" => [
                "description" => "Explaining symptoms and complications",
                "link" => "https://example.com/training/symptoms-complications"
            ],
            "Burden-Impact on quality of life" => [
                "description" => "Discussing daily-life impacts of shingles",
                "link" => "https://example.com/training/quality-of-life"
            ],
            "Education-Engagement" => [
                "description" => "Encouraging proactive health decisions",
                "link" => "https://example.com/training/patient-education"
            ],
            "Safety" => [
                "description" => "Addressing vaccine safety and reassurance",
                "link" => "https://example.com/training/safety-communication"
            ]
        ]
    ]
];

try {
    // Find existing SAAD scenario
    $stmt = $pdo->prepare("SELECT id FROM scenarios WHERE title LIKE '%SAAD%' OR title LIKE '%Saad%' LIMIT 1");
    $stmt->execute();
    $existingScenario = $stmt->fetch();
    
    if ($existingScenario) {
        // Update existing scenario
        $stmt = $pdo->prepare("
            UPDATE scenarios 
            SET title = ?, description = ?, scenario_data = ?, scoring_rules = ?, updated_at = NOW()
            WHERE id = ?
        ");
        
        $result = $stmt->execute([
            $newScenarioData['title'],
            $newScenarioData['description'],
            json_encode($newScenarioData['scenario_data']),
            json_encode($newScenarioData['scoring_rules']),
            $existingScenario['id']
        ]);
        
        if ($result) {
            echo "✅ Successfully updated SAAD scenario (ID: {$existingScenario['id']})\n";
            echo "📊 Scenario now includes:\n";
            echo "   - " . count($newScenarioData['scenario_data']['steps']) . " conversation steps\n";
            echo "   - " . count($newScenarioData['scoring_rules']['tag_mapping']) . " clickable tag categories\n";
            echo "   - Enhanced scoring system with detailed feedback\n";
        } else {
            echo "❌ Failed to update scenario\n";
        }
    } else {
        // Create new scenario
        $stmt = $pdo->prepare("
            INSERT INTO scenarios (title, description, scenario_data, scoring_rules, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'active', NOW(), NOW())
        ");
        
        $result = $stmt->execute([
            $newScenarioData['title'],
            $newScenarioData['description'],
            json_encode($newScenarioData['scenario_data']),
            json_encode($newScenarioData['scoring_rules'])
        ]);
        
        if ($result) {
            $newId = $pdo->lastInsertId();
            echo "✅ Successfully created new SAAD scenario (ID: $newId)\n";
            echo "📊 Scenario includes:\n";
            echo "   - " . count($newScenarioData['scenario_data']['steps']) . " conversation steps\n";
            echo "   - " . count($newScenarioData['scoring_rules']['tag_mapping']) . " clickable tag categories\n";
            echo "   - Enhanced scoring system with detailed feedback\n";
        } else {
            echo "❌ Failed to create scenario\n";
        }
    }
    
    // Verify the scenario was saved correctly
    $stmt = $pdo->prepare("SELECT * FROM scenarios WHERE title = ?");
    $stmt->execute([$newScenarioData['title']]);
    $savedScenario = $stmt->fetch();
    
    if ($savedScenario) {
        $scenarioData = json_decode($savedScenario['scenario_data'], true);
        $scoringRules = json_decode($savedScenario['scoring_rules'], true);
        
        echo "\n📋 Verification:\n";
        echo "   - Title: {$savedScenario['title']}\n";
        echo "   - Steps: " . count($scenarioData['steps']) . "\n";
        echo "   - Tags with links: " . count($scoringRules['tag_mapping']) . "\n";
        echo "   - Status: {$savedScenario['status']}\n";
        
        echo "\n🏷️ Available tags with links:\n";
        foreach ($scoringRules['tag_mapping'] as $tag => $info) {
            echo "   - $tag: {$info['description']}\n";
            echo "     Link: {$info['link']}\n";
        }
    }
    
} catch (PDOException $e) {
    echo "❌ Database error: " . $e->getMessage() . "\n";
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}

echo "\n🎯 Next steps:\n";
echo "1. The scenario is now updated in the database\n";
echo "2. The chat interface will show clickable tag links in scoring results\n";
echo "3. Users can click on tag names to access training resources\n";
echo "4. Test the scenario at: http://localhost:8000/frontend/chat.html\n";
?>