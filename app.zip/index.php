<?php
// Main index file - redirect to frontend
header('Location: frontend/index.html');
exit();
?>