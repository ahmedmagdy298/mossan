# Shing Chat - Medical Training Assistant

A sophisticated AI-powered medical training platform for healthcare professionals to practice clinical communication skills.

## 🚀 Quick Start

1. **Database Setup**: Import `database/schema.sql` into your MySQL database
2. **Configuration**: Copy `backend/config.local.php.example` to `backend/config.local.php` and configure your database credentials
3. **Start Local Server**: Use the development server (see Local Development below)
4. **Admin Access**: Visit `http://localhost:8000/admin/login.php` (default: admin/admin123)
5. **Training**: Visit `http://localhost:8000/frontend/index.html` to start training

## 💻 Local Development

### ⚠️ Important: CORS Error Fix

**Problem**: If you open `chat.html` directly in your browser (using `file://` protocol), you'll encounter this error:
```
Access to fetch at 'file:///.../backend/api.php' from origin 'null' has been blocked by CORS policy
```

**Why**: Browsers block cross-origin requests from `file://` protocol for security reasons. The application needs to be served over HTTP/HTTPS.

**Solution**: Use PHP's built-in development server:

#### Windows:
```bash
start-server.bat
```

#### Mac/Linux:
```bash
chmod +x start-server.sh
./start-server.sh
```

#### Manual Start (Any OS):
```bash
php -S localhost:8000
```

Then access the application at:
- **Frontend**: http://localhost:8000/frontend/index.html
- **Admin**: http://localhost:8000/admin/login.php
- **Chat**: http://localhost:8000/frontend/chat.html

**Alternative**: If you don't have PHP installed, you can use:
- Python: `python -m http.server 8000`
- Node.js: `npx http-server -p 8000`
- Or any local web server (XAMPP, WAMP, MAMP, etc.)

## 📁 Project Structure

```
software/
├── admin/                          # Admin Dashboard
│   ├── api/
│   │   ├── scenarios.php          # Scenario CRUD API
│   │   └── tag-details.php        # Tag analytics API
│   ├── index.php                  # Admin dashboard
│   ├── login.php                  # Admin login
│   └── logout.php                 # Admin logout
├── backend/                        # Backend System
│   ├── api.php                    # Main API router
│   ├── config.php                 # Database configuration
│   ├── config.local.php.example   # Local config template
│   ├── functions.php              # Core functions
│   └── session.php                # Session management
├── database/
│   └── schema.sql                 # Database schema
├── frontend/                       # Frontend Application
│   ├── css/
│   │   ├── admin.css              # Admin dashboard styles
│   │   ├── chat.css               # Chat interface styles
│   │   ├── enhanced-modal.css     # Modal styles
│   │   └── main.css               # Landing page styles
│   ├── js/
│   │   ├── admin.js               # Admin dashboard logic
│   │   ├── admin-navigation.js    # Admin navigation
│   │   ├── admin-scenarios.js     # Scenario management
│   │   ├── chat.js                # Chat interface logic
│   │   ├── main.js                # Landing page logic
│   │   └── scenario-editor-enhanced.js # Visual scenario editor
│   ├── chat.html                  # Training interface
│   └── index.html                 # Landing page
├── .gitignore                      # Git ignore rules
├── .htaccess                       # Apache configuration
├── index.php                      # Main entry point
├── FINAL-COMPLETION-SUMMARY.md     # Project completion status
└── README.md                       # This file
```

## 🔧 Features

### For Healthcare Professionals
- **AI-Powered Scenarios**: Realistic patient interactions
- **Real-Time Scoring**: Instant feedback on communication skills
- **Progress Tracking**: Detailed analytics and performance insights
- **Mobile Responsive**: Practice anywhere, anytime

### For Administrators
- **Scenario Management**: Create and edit training scenarios
- **Visual Editor**: User-friendly scenario creation (no JSON required)
- **Analytics Dashboard**: Comprehensive performance tracking
- **User Management**: Monitor training sessions and progress

## 🛡️ Security Features

- **Secure Authentication**: Password hashing with PHP's password_hash()
- **SQL Injection Protection**: All queries use prepared statements
- **XSS Prevention**: All outputs properly escaped
- **Session Security**: Secure session management with timeout
- **CORS Protection**: Controlled cross-origin requests
- **Input Validation**: Comprehensive data validation

## 🔧 Configuration

### Database Configuration
Create `backend/config.local.php`:
```php
<?php
// Local database configuration
$host = 'localhost';
$dbname = 'your_database_name';
$username = 'your_username';
$password = 'your_password';
?>
```

### Environment Variables (Alternative)
Set these environment variables:
- `DB_HOST`: Database host
- `DB_NAME`: Database name
- `DB_USER`: Database username
- `DB_PASS`: Database password

## 📊 API Endpoints

### Public Endpoints
- `GET /backend/api.php?endpoint=scenarios` - Get all scenarios
- `POST /backend/api.php?endpoint=sessions` - Create training session

### Admin Endpoints (Authentication Required)
- `GET /admin/api/scenarios.php` - Get scenarios
- `POST /admin/api/scenarios.php` - Create scenario
- `PUT /admin/api/scenarios.php?id={id}` - Update scenario
- `DELETE /admin/api/scenarios.php?id={id}` - Delete scenario

## 🚀 Deployment

### Requirements
- PHP 7.4+ with PDO MySQL extension
- MySQL 5.7+ or MariaDB 10.2+
- Apache/Nginx web server
- SSL certificate (recommended)

### Production Checklist
- [ ] Set `APP_ENV=production` environment variable
- [ ] Configure proper database credentials
- [ ] Set up SSL certificate
- [ ] Configure proper file permissions
- [ ] Set up automated backups
- [ ] Change default admin password

## 📈 Performance

- **Database**: Optimized queries with proper indexing
- **Frontend**: Minified CSS/JS, optimized images
- **Caching**: Browser caching with proper headers
- **Security**: Rate limiting on API endpoints

## 🔍 Monitoring

- **Error Logging**: Comprehensive error logging
- **Admin Audit**: All admin actions logged
- **Performance Tracking**: Session duration and completion rates
- **Analytics**: Detailed training performance metrics

## 📞 Support

For technical support or questions about the Shing Chat platform, please refer to the documentation or contact your system administrator.

---

**Version**: 1.0.0  
**Status**: Production Ready  
**Last Updated**: $(date)