// Main Landing Page JavaScript
class LandingPage {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.initAnimations();
        this.handleScrollEffects();
    }

    bindEvents() {
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Mobile menu toggle (if needed)
        this.initMobileMenu();

        // Header scroll effect
        window.addEventListener('scroll', () => {
            this.handleHeaderScroll();
        });

        // Intersection Observer for animations
        this.initScrollAnimations();
    }

    initMobileMenu() {
        // Add mobile menu functionality if needed
        const header = document.querySelector('.landing-header');
        const navMenu = document.querySelector('.nav-menu');
        
        // Create mobile menu button
        const mobileMenuBtn = document.createElement('button');
        mobileMenuBtn.className = 'mobile-menu-btn';
        mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
        mobileMenuBtn.style.display = 'none';
        
        header.querySelector('.header-content').appendChild(mobileMenuBtn);
        
        mobileMenuBtn.addEventListener('click', () => {
            navMenu.classList.toggle('mobile-open');
            const icon = mobileMenuBtn.querySelector('i');
            icon.className = navMenu.classList.contains('mobile-open') ? 'fas fa-times' : 'fas fa-bars';
        });

        // Show/hide mobile menu button based on screen size
        const checkScreenSize = () => {
            if (window.innerWidth <= 768) {
                mobileMenuBtn.style.display = 'block';
            } else {
                mobileMenuBtn.style.display = 'none';
                navMenu.classList.remove('mobile-open');
            }
        };

        window.addEventListener('resize', checkScreenSize);
        checkScreenSize();
    }

    handleHeaderScroll() {
        const header = document.querySelector('.landing-header');
        const scrolled = window.scrollY > 50;
        
        if (scrolled) {
            header.style.background = 'rgba(255, 255, 255, 0.98)';
            header.style.boxShadow = '0 4px 6px -1px rgb(0 0 0 / 0.1)';
        } else {
            header.style.background = 'rgba(255, 255, 255, 0.95)';
            header.style.boxShadow = 'none';
        }
    }

    initAnimations() {
        // Animate hero stats on load
        this.animateCounters();
        
        // Animate score bars in demo section
        this.animateScoreBars();
        
        // Add stagger animation to feature cards
        this.staggerFeatureCards();
    }

    animateCounters() {
        const counters = document.querySelectorAll('.stat-number');
        
        counters.forEach(counter => {
            const target = counter.textContent;
            const isPercentage = target.includes('%');
            const numericValue = parseInt(target.replace(/\D/g, ''));
            
            let current = 0;
            const increment = numericValue / 50; // 50 steps
            const timer = setInterval(() => {
                current += increment;
                if (current >= numericValue) {
                    current = numericValue;
                    clearInterval(timer);
                }
                
                counter.textContent = Math.floor(current) + (isPercentage ? '%' : target.includes('+') ? '+' : '');
            }, 40);
        });
    }

    animateScoreBars() {
        const scoreFills = document.querySelectorAll('.score-fill');
        
        // Animate score bars when they come into view
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const fill = entry.target;
                    const width = fill.style.width;
                    fill.style.width = '0%';
                    
                    setTimeout(() => {
                        fill.style.width = width;
                    }, 500);
                    
                    observer.unobserve(fill);
                }
            });
        });
        
        scoreFills.forEach(fill => observer.observe(fill));
    }

    staggerFeatureCards() {
        const featureCards = document.querySelectorAll('.feature-card');
        
        featureCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'all 0.6s ease';
            
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }

    initScrollAnimations() {
        const animateElements = document.querySelectorAll('.feature-card, .demo-content, .about-content');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });
        
        animateElements.forEach(el => observer.observe(el));
    }

    handleScrollEffects() {
        // Parallax effect for hero section
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const heroSection = document.querySelector('.hero-section');
            const chatPreview = document.querySelector('.chat-preview');
            
            if (heroSection && chatPreview) {
                const rate = scrolled * -0.5;
                chatPreview.style.transform = `translateY(${rate}px)`;
            }
        });
    }

    // Utility methods
    static smoothScrollTo(element, duration = 1000) {
        const targetPosition = element.offsetTop - 80; // Account for fixed header
        const startPosition = window.pageYOffset;
        const distance = targetPosition - startPosition;
        let startTime = null;

        function animation(currentTime) {
            if (startTime === null) startTime = currentTime;
            const timeElapsed = currentTime - startTime;
            const run = LandingPage.easeInOutQuad(timeElapsed, startPosition, distance, duration);
            window.scrollTo(0, run);
            if (timeElapsed < duration) requestAnimationFrame(animation);
        }

        requestAnimationFrame(animation);
    }

    static easeInOutQuad(t, b, c, d) {
        t /= d / 2;
        if (t < 1) return c / 2 * t * t + b;
        t--;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }

    // Demo functionality
    static startDemo() {
        // Redirect to chat interface
        window.location.href = 'chat.html';
    }

    static showFeatureDetails(featureName) {
        // Show detailed information about a feature
        console.log(`Showing details for: ${featureName}`);
        // This could open a modal or navigate to a detailed page
    }
}

// Chat Preview Animation
class ChatPreviewAnimation {
    constructor() {
        this.messages = [
            {
                type: 'bot',
                text: 'Good morning! I\'m here to help you practice clinical communication skills.',
                delay: 1000
            },
            {
                type: 'user',
                text: 'I\'d like to practice a patient consultation scenario.',
                delay: 2000
            },
            {
                type: 'bot',
                text: 'Perfect! Let\'s start with the SAAD scenario. You\'ll be counseling Mr. Saad about shingles vaccination.',
                delay: 3000
            }
        ];
        
        this.currentMessage = 0;
        this.init();
    }

    init() {
        const chatMessages = document.querySelector('.chat-messages');
        if (!chatMessages) return;

        // Clear existing messages
        chatMessages.innerHTML = '';
        
        // Start animation cycle
        this.animateMessages();
        
        // Restart animation every 10 seconds
        setInterval(() => {
            this.restartAnimation();
        }, 10000);
    }

    animateMessages() {
        this.messages.forEach((message, index) => {
            setTimeout(() => {
                this.addMessage(message);
            }, message.delay);
        });
    }

    addMessage(message) {
        const chatMessages = document.querySelector('.chat-messages');
        if (!chatMessages) return;

        const messageElement = document.createElement('div');
        messageElement.className = `message ${message.type}`;
        messageElement.innerHTML = `
            <div class="message-bubble">
                ${message.text}
            </div>
        `;

        messageElement.style.opacity = '0';
        messageElement.style.transform = 'translateY(20px)';
        chatMessages.appendChild(messageElement);

        // Animate in
        setTimeout(() => {
            messageElement.style.transition = 'all 0.3s ease';
            messageElement.style.opacity = '1';
            messageElement.style.transform = 'translateY(0)';
        }, 100);

        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    restartAnimation() {
        const chatMessages = document.querySelector('.chat-messages');
        if (!chatMessages) return;

        // Fade out all messages
        const messages = chatMessages.querySelectorAll('.message');
        messages.forEach((message, index) => {
            setTimeout(() => {
                message.style.opacity = '0';
                message.style.transform = 'translateY(-20px)';
            }, index * 100);
        });

        // Clear and restart after fade out
        setTimeout(() => {
            chatMessages.innerHTML = '';
            this.animateMessages();
        }, messages.length * 100 + 500);
    }
}

// Performance Analytics Display
class PerformanceDisplay {
    constructor() {
        this.init();
    }

    init() {
        // Animate performance metrics when they come into view
        this.animateMetrics();
    }

    animateMetrics() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.startMetricAnimation(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        });

        const metrics = document.querySelectorAll('.stat-number, .score-value');
        metrics.forEach(metric => observer.observe(metric));
    }

    startMetricAnimation(element) {
        const finalValue = element.textContent;
        const isPercentage = finalValue.includes('%');
        const numericValue = parseInt(finalValue.replace(/\D/g, ''));
        
        let currentValue = 0;
        const increment = numericValue / 60; // 60 frames for smooth animation
        
        const animate = () => {
            currentValue += increment;
            if (currentValue >= numericValue) {
                currentValue = numericValue;
            }
            
            element.textContent = Math.floor(currentValue) + (isPercentage ? '%' : '');
            
            if (currentValue < numericValue) {
                requestAnimationFrame(animate);
            }
        };
        
        requestAnimationFrame(animate);
    }
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LandingPage();
    new ChatPreviewAnimation();
    new PerformanceDisplay();
});

// Add CSS for mobile menu and animations
const additionalStyles = `
    @media (max-width: 768px) {
        .mobile-menu-btn {
            display: block !important;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--gray-700);
            cursor: pointer;
            padding: 0.5rem;
        }
        
        .nav-menu {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--white);
            border-top: 1px solid var(--gray-200);
            flex-direction: column;
            padding: 1rem;
            transform: translateY(-100%);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .nav-menu.mobile-open {
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }
        
        .admin-link {
            margin-top: 1rem;
            justify-content: center;
        }
    }
    
    .animate-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);