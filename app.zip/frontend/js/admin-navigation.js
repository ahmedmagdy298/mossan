// Admin Dashboard Navigation System
class AdminNavigation {
    constructor() {
        this.currentSection = 'dashboard';
        this.init();
    }

    init() {
        console.log('Initializing Admin Navigation...');
        this.bindNavigationEvents();
        this.handleInitialLoad();
    }

    bindNavigationEvents() {
        // Bind navigation items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault(); // Prevent default hash navigation
                const section = item.dataset.section;
                if (section) {
                    this.switchSection(section);
                }
            });
        });

        // Handle browser back/forward buttons
        window.addEventListener('popstate', (e) => {
            const section = e.state?.section || this.getSectionFromHash();
            if (section) {
                this.switchSection(section, false); // Don't push to history
            }
        });
    }

    handleInitialLoad() {
        // Check if there's a hash in the URL
        const section = this.getSectionFromHash();
        if (section && section !== 'dashboard') {
            this.switchSection(section, false); // Don't push to history on initial load
        } else {
            // Set initial state
            history.replaceState({ section: 'dashboard' }, '', '#dashboard');
        }
    }

    getSectionFromHash() {
        const hash = window.location.hash.replace('#', '');
        // Clean up any duplicate hashes
        const cleanHash = hash.split('#')[0];
        return cleanHash || 'dashboard';
    }

    switchSection(section, pushToHistory = true) {
        console.log('Switching to section:', section);

        // Update navigation active state
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        
        const activeNavItem = document.querySelector(`[data-section="${section}"]`);
        if (activeNavItem) {
            activeNavItem.classList.add('active');
        }

        // Update content sections
        document.querySelectorAll('.content-section').forEach(contentSection => {
            contentSection.classList.remove('active');
        });
        
        const activeSection = document.getElementById(`${section}-section`);
        if (activeSection) {
            activeSection.classList.add('active');
        }

        // Update URL and browser history
        if (pushToHistory) {
            const newUrl = `#${section}`;
            history.pushState({ section: section }, '', newUrl);
        }

        this.currentSection = section;

        // Load section-specific data
        this.loadSectionData(section);
    }

    loadSectionData(section) {
        console.log('Loading data for section:', section);
        
        switch (section) {
            case 'dashboard':
                this.loadDashboardData();
                break;
            case 'scenarios':
                this.loadScenariosData();
                break;
            case 'analytics':
                this.loadAnalyticsData();
                break;
            case 'settings':
                this.loadSettingsData();
                break;
            case 'documentation':
                this.loadDocumentationData();
                break;
        }
    }

    loadDashboardData() {
        console.log('Dashboard data already loaded by PHP');
        // Dashboard data is already loaded by PHP, no additional loading needed
    }

    loadScenariosData() {
        console.log('Scenarios data already loaded by PHP');
        // Scenarios are already loaded by PHP, just ensure event binding
        if (window.scenarioEditor) {
            window.scenarioEditor.bindEvents();
        }
    }

    loadAnalyticsData() {
        console.log('Analytics data already loaded by PHP');
        // Analytics data is already loaded by PHP
    }

    async loadSettingsData() {
        const content = document.getElementById('settings-content');
        if (!content) return;

        // Load existing settings from API
        let currentSettings = {
            primary_color: '#059669',
            secondary_color: '#0891b2',
            logo_text: 'Shing Chat Admin',
            logo_icon: 'fas fa-shield-virus',
            app_name: 'Shing Chat Admin',
            session_timeout: 3600,
            max_sessions_per_user: 100,
            enable_analytics: true,
            enable_tracking: true
        };

        try {
            const currentPath = window.location.pathname;
            let apiPath;
            
            if (currentPath.includes('/admin/')) {
                apiPath = '../backend/api.php';
            } else {
                apiPath = 'backend/api.php';
            }

            const response = await fetch(apiPath + '?endpoint=settings');
            if (response.ok) {
                const serverSettings = await response.json();
                currentSettings = { ...currentSettings, ...serverSettings };
                console.log('Loaded settings from server:', currentSettings);
            } else {
                console.log('Using default settings');
            }
        } catch (error) {
            console.error('Error loading settings:', error);
            console.log('Using default settings');
        }

        // Always load settings content
        content.innerHTML = `
            <div class="settings-panel">
                <div class="settings-section">
                    <h3><i class="fas fa-palette"></i> Appearance Settings</h3>
                    <div class="settings-grid">
                        <div class="setting-item">
                            <label>Primary Color</label>
                            <div class="color-input-group">
                                <input type="color" id="primaryColor" value="${currentSettings.primary_color}" class="color-input">
                                <input type="text" value="${currentSettings.primary_color}" class="form-input color-text" readonly>
                            </div>
                        </div>
                        <div class="setting-item">
                            <label>Secondary Color</label>
                            <div class="color-input-group">
                                <input type="color" id="secondaryColor" value="${currentSettings.secondary_color}" class="color-input">
                                <input type="text" value="${currentSettings.secondary_color}" class="form-input color-text" readonly>
                            </div>
                        </div>
                        <div class="setting-item">
                            <label>Logo Text</label>
                            <input type="text" id="logoText" value="${currentSettings.logo_text}" class="form-input">
                        </div>
                        <div class="setting-item">
                            <label>Logo Icon (FontAwesome class)</label>
                            <input type="text" id="logoIcon" value="${currentSettings.logo_icon}" class="form-input" placeholder="fas fa-shield-virus">
                        </div>
                        <div class="setting-item">
                            <label>Application Name</label>
                            <input type="text" id="appName" value="${currentSettings.app_name}" class="form-input">
                        </div>
                    </div>
                    <div class="settings-preview">
                        <h4>Preview</h4>
                        <div class="logo-preview" id="logoPreview">
                            <i class="fas fa-shield-virus" style="color: #059669"></i>
                            <span style="color: #059669">Shing Chat Admin</span>
                        </div>
                    </div>
                    <div class="settings-actions">
                        <button class="btn btn-primary" onclick="saveSettings()">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                        <button class="btn btn-secondary" onclick="resetSettings()">
                            <i class="fas fa-undo"></i> Reset to Defaults
                        </button>
                        <button class="btn btn-secondary" onclick="previewSettings()">
                            <i class="fas fa-eye"></i> Preview Changes
                        </button>
                    </div>
                </div>

                <div class="settings-section">
                    <h3><i class="fas fa-cog"></i> System Configuration</h3>
                    <div class="settings-grid">
                        <div class="setting-item">
                            <label>Session Timeout (seconds)</label>
                            <input type="number" id="sessionTimeout" value="3600" class="form-input">
                        </div>
                        <div class="setting-item">
                            <label>Max Sessions Per User</label>
                            <input type="number" id="maxSessions" value="100" class="form-input">
                        </div>
                        <div class="setting-item">
                            <label>Enable Analytics</label>
                            <select id="enableAnalytics" class="form-input">
                                <option value="true" selected>Enabled</option>
                                <option value="false">Disabled</option>
                            </select>
                        </div>
                        <div class="setting-item">
                            <label>Enable User Tracking</label>
                            <select id="enableTracking" class="form-input">
                                <option value="true" selected>Enabled</option>
                                <option value="false">Disabled</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="settings-section">
                    <h3><i class="fas fa-database"></i> Database Management</h3>
                    <div class="database-actions">
                        <button class="btn btn-secondary" onclick="backupDatabase()">
                            <i class="fas fa-database"></i> Backup Database
                        </button>
                        <button class="btn btn-warning" onclick="cleanOldSessions()">
                            <i class="fas fa-broom"></i> Clean Old Sessions
                        </button>
                        <button class="btn btn-danger" onclick="resetAllData()">
                            <i class="fas fa-trash"></i> Reset All Data
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Bind color picker events
        this.bindSettingsEvents();
    }

    bindSettingsEvents() {
        // Color picker events
        const primaryColor = document.getElementById('primaryColor');
        const secondaryColor = document.getElementById('secondaryColor');
        const logoText = document.getElementById('logoText');
        const logoIcon = document.getElementById('logoIcon');
        const appName = document.getElementById('appName');

        if (primaryColor) {
            primaryColor.addEventListener('change', (e) => {
                const colorText = e.target.parentElement.querySelector('.color-text');
                colorText.value = e.target.value;
                this.updatePreview();
            });
        }

        if (secondaryColor) {
            secondaryColor.addEventListener('change', (e) => {
                const colorText = e.target.parentElement.querySelector('.color-text');
                colorText.value = e.target.value;
                this.updatePreview();
            });
        }

        if (logoText) {
            logoText.addEventListener('input', () => {
                this.updatePreview();
            });
        }

        if (logoIcon) {
            logoIcon.addEventListener('input', () => {
                this.updatePreview();
            });
        }
    }

    updatePreview() {
        const primaryColor = document.getElementById('primaryColor')?.value || '#059669';
        const logoText = document.getElementById('logoText')?.value || 'Shing Chat Admin';
        const logoIcon = document.getElementById('logoIcon')?.value || 'fas fa-shield-virus';
        
        const preview = document.getElementById('logoPreview');
        if (preview) {
            preview.innerHTML = `
                <i class="${logoIcon}" style="color: ${primaryColor}"></i>
                <span style="color: ${primaryColor}">${logoText}</span>
            `;
        }
    }

    loadDocumentationData() {
        const content = document.getElementById('documentation-content');
        if (!content) return;

        // Always load documentation content
        content.innerHTML = `
            <div class="documentation-panel">
                <div class="doc-section">
                    <h3><i class="fas fa-book"></i> User Guide</h3>
                    <div class="doc-content">
                        <h4>Getting Started</h4>
                        <p>Welcome to Shing Chat Admin Dashboard. This system allows you to manage chat scenarios, monitor analytics, and configure system settings.</p>
                        
                        <h4>Dashboard Overview</h4>
                        <ul>
                            <li><strong>Dashboard:</strong> View overall system statistics and performance metrics</li>
                            <li><strong>Scenarios:</strong> Create and manage chat scenarios for training</li>
                            <li><strong>Analytics:</strong> Detailed performance analysis and reporting</li>
                            <li><strong>Settings:</strong> Configure system appearance and behavior</li>
                            <li><strong>Documentation:</strong> Complete user guides and troubleshooting</li>
                        </ul>

                        <h4>Managing Scenarios</h4>
                        <p>Scenarios are the core training modules. You can:</p>
                        <ul>
                            <li>Create new scenarios with custom workflows</li>
                            <li>Edit existing scenarios and their response options</li>
                            <li>Configure scoring rules and feedback</li>
                            <li>Set tag links for additional resources</li>
                            <li>Monitor scenario performance and analytics</li>
                        </ul>

                        <h4>Scenario Editor Features</h4>
                        <p>The enhanced scenario editor includes:</p>
                        <ul>
                            <li><strong>Basic Info Tab:</strong> Title, description, and status</li>
                            <li><strong>Scenario Data Tab:</strong> Complete conversation flow with steps and responses</li>
                            <li><strong>Scoring Rules Tab:</strong> Tag mapping with external links</li>
                            <li><strong>Preview Tab:</strong> Real-time preview of scenario structure</li>
                        </ul>
                    </div>
                </div>

                <div class="doc-section">
                    <h3><i class="fas fa-cog"></i> System Configuration</h3>
                    <div class="doc-content">
                        <h4>Appearance Settings</h4>
                        <p>Customize the look and feel of your system:</p>
                        <ul>
                            <li><strong>Primary Color:</strong> Main theme color used throughout the interface</li>
                            <li><strong>Secondary Color:</strong> Accent color for highlights and secondary elements</li>
                            <li><strong>Logo Text:</strong> Text displayed in the application header</li>
                            <li><strong>Logo Icon:</strong> FontAwesome icon class for the logo</li>
                        </ul>

                        <h4>System Settings</h4>
                        <ul>
                            <li><strong>Session Timeout:</strong> How long user sessions remain active</li>
                            <li><strong>Max Sessions:</strong> Maximum number of sessions per user</li>
                            <li><strong>Analytics:</strong> Enable or disable analytics tracking</li>
                            <li><strong>User Tracking:</strong> Enable anonymous user tracking</li>
                        </ul>

                        <h4>Database Management</h4>
                        <ul>
                            <li><strong>Backup Database:</strong> Create database backups</li>
                            <li><strong>Clean Old Sessions:</strong> Remove outdated session data</li>
                            <li><strong>Reset All Data:</strong> Complete system reset (use with caution)</li>
                        </ul>
                    </div>
                </div>

                <div class="doc-section">
                    <h3><i class="fas fa-chart-bar"></i> Analytics & Reporting</h3>
                    <div class="doc-content">
                        <h4>Dashboard Metrics</h4>
                        <p>The dashboard provides key performance indicators:</p>
                        <ul>
                            <li><strong>Total Sessions:</strong> Number of completed training sessions</li>
                            <li><strong>Average Score:</strong> Overall performance across all scenarios</li>
                            <li><strong>Average Duration:</strong> Time spent per training session</li>
                            <li><strong>Completion Rate:</strong> Percentage of sessions completed successfully</li>
                        </ul>

                        <h4>Tag Performance Analysis</h4>
                        <p>Detailed breakdown of performance by clinical communication categories:</p>
                        <ul>
                            <li><strong>Burden - Risk:</strong> Risk communication effectiveness</li>
                            <li><strong>Burden - Symptoms:</strong> Symptom explanation clarity</li>
                            <li><strong>Education - Engagement:</strong> Patient education quality</li>
                            <li><strong>Adherence - Ready to Act:</strong> Treatment adherence promotion</li>
                        </ul>
                    </div>
                </div>

                <div class="doc-section">
                    <h3><i class="fas fa-question-circle"></i> Troubleshooting</h3>
                    <div class="doc-content">
                        <h4>Common Issues</h4>
                        <ul>
                            <li><strong>Settings not saving:</strong> Check database connection and permissions</li>
                            <li><strong>Analytics not updating:</strong> Ensure sessions are completing properly</li>
                            <li><strong>Scenarios not loading:</strong> Verify scenario data format and database integrity</li>
                            <li><strong>Edit button not working:</strong> Check browser console for JavaScript errors</li>
                            <li><strong>Navigation issues:</strong> Clear browser cache and refresh</li>
                        </ul>

                        <h4>Database Issues</h4>
                        <ul>
                            <li><strong>Connection errors:</strong> Verify database credentials in config.php</li>
                            <li><strong>Missing tables:</strong> Run the database schema installation</li>
                            <li><strong>Performance issues:</strong> Check database indexes and optimization</li>
                        </ul>

                        <h4>Browser Compatibility</h4>
                        <ul>
                            <li><strong>Supported browsers:</strong> Chrome 80+, Firefox 75+, Safari 13+, Edge 80+</li>
                            <li><strong>JavaScript required:</strong> Ensure JavaScript is enabled</li>
                            <li><strong>Cookies required:</strong> Enable cookies for session management</li>
                        </ul>
                    </div>
                </div>

                <div class="doc-section">
                    <h3><i class="fas fa-download"></i> Resources & Downloads</h3>
                    <div class="doc-content">
                        <h4>Documentation Files</h4>
                        <div class="download-links">
                            <button class="btn btn-primary" onclick="downloadUserGuide()">
                                <i class="fas fa-file-pdf"></i> User Guide PDF
                            </button>
                            <button class="btn btn-secondary" onclick="downloadAPIDoc()">
                                <i class="fas fa-code"></i> API Documentation
                            </button>
                            <button class="btn btn-info" onclick="downloadSampleData()">
                                <i class="fas fa-database"></i> Sample Scenario Data
                            </button>
                        </div>

                        <h4>External Resources</h4>
                        <ul>
                            <li><a href="https://www.cdc.gov/shingles/" target="_blank">CDC Shingles Information</a></li>
                            <li><a href="https://www.cdc.gov/vaccines/" target="_blank">CDC Vaccination Guidelines</a></li>
                            <li><a href="https://fontawesome.com/icons" target="_blank">FontAwesome Icons</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        `;
    }
}

// Global functions for backward compatibility
function refreshData() {
    console.log('Refreshing data...');
    location.reload();
}

function generateReport() {
    alert('Report generation feature coming soon');
}

function exportSessions() {
    alert('Session export feature coming soon');
}

function downloadDocs() {
    alert('Documentation download feature coming soon');
}

function updateChart() {
    console.log('Chart update requested');
}

function viewSession(id) {
    alert(`View session ${id} - Feature coming soon`);
}

function deleteSession(id) {
    if (confirm(`Are you sure you want to delete session ${id}?`)) {
        alert(`Delete session ${id} - Feature coming soon`);
    }
}

function openScenarioModal() {
    alert('Create new scenario feature coming soon');
}

async function saveSettings() {
    // Collect all settings from the form
    const settings = {
        primary_color: document.getElementById('primaryColor')?.value || '#059669',
        secondary_color: document.getElementById('secondaryColor')?.value || '#0891b2',
        logo_text: document.getElementById('logoText')?.value || 'Shing Chat Admin',
        logo_icon: document.getElementById('logoIcon')?.value || 'fas fa-shield-virus',
        app_name: document.getElementById('appName')?.value || 'Shing Chat Admin',
        session_timeout: parseInt(document.getElementById('sessionTimeout')?.value) || 3600,
        max_sessions_per_user: parseInt(document.getElementById('maxSessions')?.value) || 100,
        enable_analytics: document.getElementById('enableAnalytics')?.value === 'true',
        enable_tracking: document.getElementById('enableTracking')?.value === 'true'
    };

    console.log('Saving settings:', settings);

    try {
        // Determine the correct API path
        const currentPath = window.location.pathname;
        let apiPath;
        
        if (currentPath.includes('/admin/')) {
            apiPath = '../backend/api.php';
        } else {
            apiPath = 'backend/api.php';
        }

        const response = await fetch(apiPath + '?endpoint=settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(settings)
        });

        console.log('API response status:', response.status);

        if (response.ok) {
            const result = await response.json();
            console.log('Save result:', result);
            
            if (result.success) {
                // Apply settings immediately
                applySettingsToInterface(settings);
                alert('Settings saved successfully!');
            } else {
                alert('Failed to save settings: ' + (result.error || 'Unknown error'));
            }
        } else {
            const errorText = await response.text();
            console.error('API error:', response.status, errorText);
            alert('Failed to save settings. Server error: ' + response.status);
        }
    } catch (error) {
        console.error('Error saving settings:', error);
        alert('Error saving settings: ' + error.message);
    }
}

function applySettingsToInterface(settings) {
    // Apply color scheme
    document.documentElement.style.setProperty('--primary', settings.primary_color);
    document.documentElement.style.setProperty('--secondary', settings.secondary_color);
    
    // Update logo in sidebar
    const logoElements = document.querySelectorAll('.logo i');
    logoElements.forEach(el => {
        el.className = settings.logo_icon;
    });
    
    const logoTexts = document.querySelectorAll('.logo span');
    logoTexts.forEach(el => {
        el.textContent = settings.logo_text;
    });

    // Store settings in localStorage for persistence
    localStorage.setItem('adminSettings', JSON.stringify(settings));
}

function resetSettings() {
    if (confirm('Are you sure you want to reset all settings?')) {
        // Reset form values to defaults
        document.getElementById('primaryColor').value = '#059669';
        document.getElementById('secondaryColor').value = '#0891b2';
        document.getElementById('logoText').value = 'Shing Chat Admin';
        document.getElementById('logoIcon').value = 'fas fa-shield-virus';
        document.getElementById('appName').value = 'Shing Chat Admin';
        document.getElementById('sessionTimeout').value = '3600';
        document.getElementById('maxSessions').value = '100';
        document.getElementById('enableAnalytics').value = 'true';
        document.getElementById('enableTracking').value = 'true';
        
        // Update color text inputs
        document.querySelector('#primaryColor + .color-text').value = '#059669';
        document.querySelector('#secondaryColor + .color-text').value = '#0891b2';
        
        // Update preview
        if (adminNavigation) {
            adminNavigation.updatePreview();
        }
        
        alert('Settings reset to defaults');
    }
}

function previewSettings() {
    const primaryColor = document.getElementById('primaryColor').value;
    const secondaryColor = document.getElementById('secondaryColor').value;
    const logoText = document.getElementById('logoText').value;
    const logoIcon = document.getElementById('logoIcon').value;
    
    // Apply preview styles
    document.documentElement.style.setProperty('--primary', primaryColor);
    document.documentElement.style.setProperty('--secondary', secondaryColor);
    
    // Update logo in sidebar
    const logoElements = document.querySelectorAll('.logo i');
    logoElements.forEach(el => {
        el.className = logoIcon;
    });
    
    const logoTexts = document.querySelectorAll('.logo span');
    logoTexts.forEach(el => {
        el.textContent = logoText;
    });
    
    alert('Preview applied! Save to make changes permanent.');
}

function backupDatabase() {
    alert('Database backup functionality will be available in a future update.');
}

function cleanOldSessions() {
    if (confirm('Are you sure you want to clean old sessions? This action cannot be undone.')) {
        alert('Old sessions cleanup functionality will be available in a future update.');
    }
}

function resetAllData() {
    if (confirm('Are you sure you want to reset ALL data? This will delete everything and cannot be undone!')) {
        if (confirm('This is your final warning. All data will be permanently deleted. Continue?')) {
            alert('Reset all data functionality will be available in a future update.');
        }
    }
}

function downloadUserGuide() {
    alert('User guide download will be available soon.');
}

function downloadAPIDoc() {
    alert('API documentation download will be available soon.');
}

function downloadSampleData() {
    alert('Sample data download will be available soon.');
}

// Initialize navigation when DOM is ready
let adminNavigation;
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing Admin Navigation...');
    adminNavigation = new AdminNavigation();
});