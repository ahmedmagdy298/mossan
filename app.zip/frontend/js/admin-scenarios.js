/**
 * Admin Scenarios Management JavaScript - Software Version
 * Handles scenario CRUD operations and UI updates
 */

class ScenarioManager {
    constructor() {
        this.apiBase = '../admin/api/scenarios.php';
        this.currentScenario = null;
        this.init();
    }

    init() {
        this.loadScenarios();
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Save scenario button
        document.addEventListener('click', (e) => {
            if (e.target.matches('.save-scenario-btn')) {
                this.saveScenario();
            }
            
            if (e.target.matches('.edit-scenario-btn')) {
                const scenarioId = e.target.dataset.scenarioId;
                this.editScenario(scenarioId);
            }
            
            if (e.target.matches('.delete-scenario-btn')) {
                const scenarioId = e.target.dataset.scenarioId;
                this.deleteScenario(scenarioId);
            }
            
            if (e.target.matches('.new-scenario-btn')) {
                this.newScenario();
            }
        });

        // Form submission
        document.addEventListener('submit', (e) => {
            if (e.target.matches('#scenario-form')) {
                e.preventDefault();
                this.saveScenario();
            }
        });
    }

    async loadScenarios() {
        try {
            const response = await fetch(this.apiBase);
            const result = await response.json();
            
            if (result.success) {
                this.renderScenarios(result.data);
            } else {
                this.showError('Failed to load scenarios: ' + result.message);
            }
        } catch (error) {
            console.error('Load scenarios error:', error);
            this.showError('Failed to load scenarios');
        }
    }

    renderScenarios(scenarios) {
        const container = document.getElementById('scenarios-container');
        if (!container) return;

        container.innerHTML = scenarios.map(scenario => `
            <div class="scenario-card" data-scenario-id="${scenario.id}">
                <div class="scenario-header">
                    <h3>${this.escapeHtml(scenario.title)}</h3>
                    <div class="scenario-actions">
                        <button class="btn-icon enhanced-edit-btn" data-scenario-id="${scenario.id}" title="Enhanced Editor">
                            <i class="fas fa-magic"></i>
                        </button>
                        <button class="btn-icon edit-scenario-btn" data-scenario-id="${scenario.id}" title="JSON Editor">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-icon delete-scenario-btn" data-scenario-id="${scenario.id}" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <p class="scenario-description">${this.escapeHtml(scenario.description)}</p>
                <div class="scenario-stats">
                    <div class="stat">
                        <i class="fas fa-play"></i>
                        <span>${scenario.total_sessions} sessions</span>
                    </div>
                    <div class="stat">
                        <i class="fas fa-star"></i>
                        <span>${scenario.avg_score}% avg</span>
                    </div>
                    <div class="stat">
                        <i class="fas fa-clock"></i>
                        <span>${scenario.avg_duration}s avg</span>
                    </div>
                </div>
                <div class="scenario-status">
                    <span class="status-badge ${scenario.status}">
                        ${this.capitalize(scenario.status)}
                    </span>
                </div>
            </div>
        `).join('');
    }

    async editScenario(scenarioId) {
        try {
            const response = await fetch(`${this.apiBase}?id=${scenarioId}`);
            const result = await response.json();
            
            if (result.success) {
                this.currentScenario = result.data;
                this.showScenarioModal(result.data);
            } else {
                this.showError('Failed to load scenario: ' + result.message);
            }
        } catch (error) {
            console.error('Edit scenario error:', error);
            this.showError('Failed to load scenario');
        }
    }

    newScenario() {
        this.currentScenario = null;
        this.showScenarioModal({
            title: '',
            description: '',
            status: 'active',
            scenario_data: {
                steps: []
            },
            scoring_rules: {
                weights: {
                    'High': 3,
                    'Medium': 2,
                    'Low': 1
                },
                levels: {
                    'Good': 3,
                    'Medium': 2,
                    'Low': 1,
                    'Bad': 0
                }
            }
        });
    }

    showScenarioModal(scenario) {
        const modal = document.getElementById('scenario-modal');
        if (!modal) {
            this.createScenarioModal();
            return this.showScenarioModal(scenario);
        }

        // Populate form fields
        document.getElementById('scenario-title').value = scenario.title || '';
        document.getElementById('scenario-description').value = scenario.description || '';
        document.getElementById('scenario-status').value = scenario.status || 'active';
        
        // Populate scenario data (JSON editor)
        const scenarioDataTextarea = document.getElementById('scenario-data');
        if (scenarioDataTextarea) {
            scenarioDataTextarea.value = JSON.stringify(scenario.scenario_data || {}, null, 2);
        }

        // Populate scoring rules
        const scoringRulesTextarea = document.getElementById('scoring-rules');
        if (scoringRulesTextarea) {
            scoringRulesTextarea.value = JSON.stringify(scenario.scoring_rules || {}, null, 2);
        }

        modal.style.display = 'block';
    }

    createScenarioModal() {
        const modalHtml = `
            <div id="scenario-modal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>${this.currentScenario ? 'Edit Scenario' : 'New Scenario'}</h2>
                        <span class="close" onclick="this.closest('.modal').style.display='none'">&times;</span>
                    </div>
                    <form id="scenario-form">
                        <div class="form-group">
                            <label for="scenario-title">Title</label>
                            <input type="text" id="scenario-title" name="title" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="scenario-description">Description</label>
                            <textarea id="scenario-description" name="description" rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="scenario-status">Status</label>
                            <select id="scenario-status" name="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="scenario-data">Scenario Data (JSON)</label>
                            <textarea id="scenario-data" name="scenario_data" rows="10" placeholder="Enter scenario steps and responses in JSON format"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="scoring-rules">Scoring Rules (JSON)</label>
                            <textarea id="scoring-rules" name="scoring_rules" rows="5" placeholder="Enter scoring weights and levels in JSON format"></textarea>
                        </div>
                        
                        <div class="form-actions">
                            <button type="button" class="btn btn-secondary" onclick="this.closest('.modal').style.display='none'">Cancel</button>
                            <button type="submit" class="btn btn-primary save-scenario-btn">Save Scenario</button>
                        </div>
                    </form>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }

    async saveScenario() {
        const form = document.getElementById('scenario-form');
        const formData = new FormData(form);
        
        try {
            // Validate JSON fields
            const scenarioData = JSON.parse(formData.get('scenario_data') || '{}');
            const scoringRules = JSON.parse(formData.get('scoring_rules') || '{}');
            
            const data = {
                title: formData.get('title'),
                description: formData.get('description'),
                status: formData.get('status'),
                scenario_data: scenarioData,
                scoring_rules: scoringRules
            };

            const url = this.currentScenario 
                ? `${this.apiBase}?id=${this.currentScenario.id}`
                : this.apiBase;
            
            const method = this.currentScenario ? 'PUT' : 'POST';

            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                this.showSuccess(result.message);
                document.getElementById('scenario-modal').style.display = 'none';
                this.loadScenarios(); // Reload scenarios
                
                // Clear frontend cache to ensure updates are visible
                this.clearFrontendCache();
            } else {
                this.showError('Failed to save scenario: ' + result.message);
            }

        } catch (error) {
            console.error('Save scenario error:', error);
            if (error instanceof SyntaxError) {
                this.showError('Invalid JSON format in scenario data or scoring rules');
            } else {
                this.showError('Failed to save scenario');
            }
        }
    }

    async deleteScenario(scenarioId) {
        if (!confirm('Are you sure you want to delete this scenario?')) {
            return;
        }

        try {
            const response = await fetch(`${this.apiBase}?id=${scenarioId}`, {
                method: 'DELETE'
            });

            const result = await response.json();

            if (result.success) {
                this.showSuccess(result.message);
                this.loadScenarios(); // Reload scenarios
                this.clearFrontendCache();
            } else {
                this.showError('Failed to delete scenario: ' + result.message);
            }

        } catch (error) {
            console.error('Delete scenario error:', error);
            this.showError('Failed to delete scenario');
        }
    }

    clearFrontendCache() {
        // Clear localStorage cache
        localStorage.removeItem('scenarios_cache');
        localStorage.removeItem('scenario_data');
        
        // Clear sessionStorage cache
        sessionStorage.removeItem('scenarios_cache');
        sessionStorage.removeItem('scenario_data');
        
        // Notify other tabs/windows about the update
        if (window.BroadcastChannel) {
            const channel = new BroadcastChannel('scenario_updates');
            channel.postMessage({ type: 'scenarios_updated' });
        }
        
        console.log('Frontend cache cleared');
    }

    showSuccess(message) {
        this.showToast(message, 'success');
    }

    showError(message) {
        this.showToast(message, 'error');
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}"></i>
                <span>${message}</span>
            </div>
        `;

        document.body.appendChild(toast);

        // Show toast
        setTimeout(() => toast.classList.add('show'), 100);

        // Hide toast
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => document.body.removeChild(toast), 300);
        }, 3000);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('scenarios-container')) {
        window.scenarioManager = new ScenarioManager();
    }
});

// CSS for modal and toast (add to your CSS file)
const additionalCSS = `
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.modal-content {
    background-color: #fefefe;
    margin: 5% auto;
    padding: 0;
    border-radius: 10px;
    width: 90%;
    max-width: 800px;
    max-height: 90vh;
    overflow-y: auto;
}

.modal-header {
    padding: 20px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    margin: 0;
    color: #333;
}

.close {
    color: #aaa;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover {
    color: #000;
}

.form-group {
    margin-bottom: 20px;
    padding: 0 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
    color: #333;
}

.form-group input,
.form-group textarea,
.form-group select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
}

.form-group textarea {
    resize: vertical;
    font-family: monospace;
}

.form-actions {
    padding: 20px;
    border-top: 1px solid #eee;
    text-align: right;
}

.form-actions .btn {
    margin-left: 10px;
}

.toast {
    position: fixed;
    top: 20px;
    right: 20px;
    background: white;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    padding: 15px 20px;
    z-index: 1001;
    transform: translateX(100%);
    transition: transform 0.3s ease;
}

.toast.show {
    transform: translateX(0);
}

.toast-success {
    border-left: 4px solid #10b981;
}

.toast-error {
    border-left: 4px solid #ef4444;
}

.toast-content {
    display: flex;
    align-items: center;
    gap: 10px;
}

.toast-success .fas {
    color: #10b981;
}

.toast-error .fas {
    color: #ef4444;
}
`;

// Inject CSS
const style = document.createElement('style');
style.textContent = additionalCSS;
document.head.appendChild(style);