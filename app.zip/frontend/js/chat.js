// Chat Interface JavaScript - Database-driven scenarios

// Check if running on file:// protocol (CORS will fail)
(function () {
    if (window.location.protocol === 'file:') {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', showCorsError);
        } else {
            showCorsError();
        }

        function showCorsError() {
            const overlay = document.createElement('div');
            overlay.id = 'cors-error-overlay';
            overlay.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.95); z-index: 99999; display: flex; align-items: center; justify-content: center; padding: 20px; font-family: Arial, sans-serif;';
            overlay.innerHTML = `
                <div style="background: white; padding: 40px; border-radius: 10px; max-width: 600px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
                    <div style="text-align: center; color: #dc2626; font-size: 3rem; margin-bottom: 20px;">
                        ⚠️
                    </div>
                    <h2 style="color: #1f2937; margin-bottom: 20px; text-align: center; font-size: 1.5rem;">CORS Error: File Protocol Detected</h2>
                    <p style="color: #4b5563; line-height: 1.6; margin-bottom: 20px;">
                        You're opening this file directly using the <code style="background: #f3f4f6; padding: 2px 6px; border-radius: 3px; font-family: monospace;">file://</code> protocol. 
                        Browsers block API requests from this protocol for security reasons.
                    </p>
                    <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin-bottom: 20px; border-radius: 5px;">
                        <strong style="color: #92400e;">Solution:</strong> You need to run a local web server.
                    </div>
                    <div style="background: #f3f4f6; padding: 20px; border-radius: 5px; margin-bottom: 20px;">
                        <strong style="display: block; margin-bottom: 10px; color: #1f2937;">Quick Start:</strong>
                        <ol style="margin: 0; padding-left: 20px; color: #4b5563; line-height: 2;">
                            <li>Open a terminal/command prompt in the project folder</li>
                            <li>Run: <code style="background: #e5e7eb; padding: 2px 6px; border-radius: 3px; font-family: monospace;">php -S localhost:8000</code></li>
                            <li>Or double-click <code style="background: #e5e7eb; padding: 2px 6px; border-radius: 3px; font-family: monospace;">start-server.bat</code> (Windows)</li>
                            <li>Then visit: <code style="background: #e5e7eb; padding: 2px 6px; border-radius: 3px; font-family: monospace;">http://localhost:8000/frontend/chat.html</code></li>
                        </ol>
                    </div>
                    <div style="text-align: center;">
                        <button onclick="location.reload()" style="background: #059669; color: white; padding: 12px 24px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; font-weight: bold;">
                            🔄 Reload After Starting Server
                        </button>
                    </div>
                    <p style="color: #6b7280; font-size: 0.9em; margin-top: 20px; text-align: center;">
                        See README.md for more details and alternative server options.
                    </p>
                </div>
            `;
            document.body.appendChild(overlay);
            throw new Error('Application cannot run on file:// protocol. Please use a web server.');
        }
    }
})();

// API Configuration
const API_CONFIG = {
    BASE_URL: '../backend/api.php',
    SCENARIOS_API: '../backend/api.php?endpoint=scenarios',
    SESSIONS_API: '../backend/api.php?endpoint=sessions'
};

// Global variables
let currentScenario = null;
let selectedRole = null;
let currentStep = null;
let isChatting = false;
let startTime = null;

// Score tracking
const scoreData = {
    selectedResponses: [],
    maxPossibleScore: 0,
    good: 0,
    medium: 0,
    bad: 0
};

// Default tag mapping for contextual tags
const defaultTagMapping = {
    'High_Good': { tag: 'Excellent Communication', link: '#' },
    'High_Medium': { tag: 'Good Communication', link: '#' },
    'High_Low': { tag: 'Needs Improvement', link: '#' },
    'High_Bad': { tag: 'Poor Communication', link: '#' },
    'Medium_Good': { tag: 'Effective Interaction', link: '#' },
    'Medium_Medium': { tag: 'Adequate Interaction', link: '#' },
    'Medium_Low': { tag: 'Below Average', link: '#' },
    'Medium_Bad': { tag: 'Ineffective', link: '#' },
    'Low_Good': { tag: 'Supportive', link: '#' },
    'Low_Medium': { tag: 'Basic', link: '#' },
    'Low_Low': { tag: 'Minimal', link: '#' },
    'Low_Bad': { tag: 'Inadequate', link: '#' }
};

// Initialize the application
document.addEventListener('DOMContentLoaded', async function () {
    console.log('🚀 Initializing Shing Chat...');
    await loadScenariosInWelcome();
    bindEvents();
    loadAndApplySettings();
    console.log('✅ Shing Chat initialized with database scenarios');
});

// Load and apply settings from admin dashboard
function loadAndApplySettings() {
    fetch('../backend/api.php?get_settings=1')
        .then(response => response.json())
        .then(settings => {
            // Apply theme colors
            if (settings.primary_color) {
                document.documentElement.style.setProperty('--primary', settings.primary_color);
                document.documentElement.style.setProperty('--primary-dark', adjustColor(settings.primary_color, -20));
                document.documentElement.style.setProperty('--primary-light', adjustColor(settings.primary_color, 20));
            }

            if (settings.secondary_color) {
                document.documentElement.style.setProperty('--secondary', settings.secondary_color);
            }

            // Apply logo text and icon
            document.querySelectorAll('.bot-avatar i, .logo i').forEach(el => {
                if (settings.logo_icon) {
                    el.className = settings.logo_icon;
                }
            });

            document.querySelectorAll('.bot-name, .logo span').forEach(el => {
                if (settings.logo_text) {
                    el.textContent = settings.logo_text;
                }
            });

            // Update page title
            if (settings.logo_text) {
                document.title = settings.logo_text + ' - Clinical Communication Training';
            }
        })
        .catch(error => {
            console.log('Settings not available, using defaults');
        });
}

// Helper function to adjust color brightness
function adjustColor(color, amount) {
    const usePound = color[0] === '#';
    const col = usePound ? color.slice(1) : color;
    const num = parseInt(col, 16);
    let r = (num >> 16) + amount;
    let g = (num >> 8 & 0x00FF) + amount;
    let b = (num & 0x0000FF) + amount;
    r = r > 255 ? 255 : r < 0 ? 0 : r;
    g = g > 255 ? 255 : g < 0 ? 0 : g;
    b = b > 255 ? 255 : b < 0 ? 0 : b;
    return (usePound ? '#' : '') + (r << 16 | g << 8 | b).toString(16).padStart(6, '0');
}

function bindEvents() {
    // Escape key to close modal
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeScoreModal();
        }
    });
}

async function loadScenariosInWelcome() {
    const scenarioSelector = document.getElementById('scenario-selector');
    if (!scenarioSelector) return;

    scenarioSelector.innerHTML = '<div class="loading">Loading scenarios...</div>';

    try {
        // Load scenarios from admin database via API
        console.log('📡 Loading scenarios from admin database...');

        // Add cache-busting parameter and force fresh data
        const timestamp = new Date().getTime();
        const apiUrl = `${API_CONFIG.SCENARIOS_API}&t=${timestamp}`;
        console.log('🔗 API URL:', apiUrl);

        const response = await fetch(apiUrl, {
            cache: 'no-cache',
            headers: {
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache'
            }
        });

        if (!response.ok) {
            console.error('❌ API Response Error:', response.status, response.statusText);
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        // Get response as text first to handle PHP warnings
        const responseText = await response.text();
        console.log('📦 Raw API Response:', responseText);

        // Extract JSON from response (ignore PHP warnings)
        let data;
        try {
            // Try to parse as JSON directly first
            data = JSON.parse(responseText);
        } catch (e) {
            // If that fails, try to extract JSON from the response
            const jsonMatch = responseText.match(/\{"success".*\}$/);
            if (jsonMatch) {
                console.log('🔧 Extracted JSON from response with warnings');
                data = JSON.parse(jsonMatch[0]);
            } else {
                console.error('❌ Could not extract valid JSON from response');
                throw new Error('Invalid JSON response from API');
            }
        }

        console.log('📦 Parsed API Response:', data);

        if (data.success && data.data) {
            const scenarios = data.data;
            console.log('📊 Available scenarios:', scenarios.length);

            if (scenarios.length === 0) {
                throw new Error('No scenarios found in database. Please create scenarios in the admin panel.');
            }

            console.log('✅ Successfully loaded admin scenarios');

            scenarioSelector.innerHTML = '';

            scenarios.forEach((scenario, index) => {
                // Parse scenario data if it's a JSON string
                let scenarioData;
                try {
                    scenarioData = typeof scenario.scenario_data === 'string'
                        ? JSON.parse(scenario.scenario_data)
                        : scenario.scenario_data;

                    // Validate scenario data structure
                    if (!scenarioData || typeof scenarioData !== 'object') {
                        console.error('Invalid scenario data structure for scenario:', scenario.id);
                        return;
                    }

                    // Ensure steps exist and is an array
                    if (!scenarioData.steps || !Array.isArray(scenarioData.steps)) {
                        console.error('Scenario missing steps array for scenario:', scenario.id, scenarioData);
                        return;
                    }

                    if (scenarioData.steps.length === 0) {
                        console.error('Scenario has empty steps array for scenario:', scenario.id);
                        return;
                    }

                } catch (e) {
                    console.error('Error parsing scenario data for scenario:', scenario.id, e);
                    return;
                }

                // Parse scoring rules
                let scoringRules;
                try {
                    scoringRules = typeof scenario.scoring_rules === 'string'
                        ? JSON.parse(scenario.scoring_rules)
                        : scenario.scoring_rules;
                } catch (e) {
                    console.error('Error parsing scoring rules for scenario:', scenario.id, e);
                    scoringRules = {
                        weights: { High: 3, Medium: 2, Low: 1 },
                        levels: { Good: 3, Medium: 2, Low: 1, Bad: 0 }
                    };
                }

                const card = document.createElement('div');
                card.className = 'scenario-card';
                card.dataset.scenarioId = scenario.id;
                card.dataset.scenarioRole = `scenario_${scenario.id}`;
                card.onclick = (event) => selectScenario(`scenario_${scenario.id}`, {
                    [`scenario_${scenario.id}`]: {
                        id: scenario.id,
                        scenario_title: scenario.title,
                        description: scenario.description,
                        steps: scenarioData.steps,
                        scoring_rules: scoringRules
                    }
                }, event.target);

                card.innerHTML = `
                    <div class="scenario-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <div class="scenario-title">${scenario.title}</div>
                    <div class="scenario-desc">${scenario.description}</div>
                `;

                scenarioSelector.appendChild(card);
            });

            // Store admin scenarios globally for use in chat
            const adminScenarios = {};
            scenarios.forEach(scenario => {
                let scenarioData;
                try {
                    scenarioData = typeof scenario.scenario_data === 'string'
                        ? JSON.parse(scenario.scenario_data)
                        : scenario.scenario_data;

                    // Validate scenario data structure
                    if (!scenarioData || typeof scenarioData !== 'object') {
                        console.error('Invalid scenario data structure for scenario:', scenario.id);
                        return;
                    }

                    // Ensure steps exist and is an array
                    if (!scenarioData.steps || !Array.isArray(scenarioData.steps)) {
                        console.error('Scenario missing steps array for scenario:', scenario.id);
                        return;
                    }

                } catch (e) {
                    console.error('Error parsing scenario data for scenario:', scenario.id, e);
                    return;
                }

                // Parse scoring rules
                let scoringRules;
                try {
                    scoringRules = typeof scenario.scoring_rules === 'string'
                        ? JSON.parse(scenario.scoring_rules)
                        : scenario.scoring_rules;
                } catch (e) {
                    console.error('Error parsing scoring rules for scenario:', scenario.id, e);
                    scoringRules = {
                        weights: { High: 3, Medium: 2, Low: 1 },
                        levels: { Good: 3, Medium: 2, Low: 1, Bad: 0 }
                    };
                }

                adminScenarios[`scenario_${scenario.id}`] = {
                    id: scenario.id,
                    scenario_title: scenario.title,
                    description: scenario.description,
                    steps: scenarioData.steps,
                    scoring_rules: scoringRules
                };
            });

            window.adminScenarios = adminScenarios;

            // Check if we actually have valid scenarios after parsing
            const validScenarioCount = Object.keys(adminScenarios).length;
            if (validScenarioCount === 0) {
                throw new Error('No valid scenarios found. Scenarios may be missing step data or have invalid JSON structure.');
            }

            console.log(`✅ Successfully loaded ${validScenarioCount} valid scenarios`);

        } else {
            console.error('❌ No scenarios in API response:', data);
            throw new Error(data.message || 'No scenarios returned from API');
        }

    } catch (error) {
        console.error('❌ Failed to load scenarios from admin:', error);

        // Check if it's a CORS/network error
        const isCorsError = error.message.includes('Failed to fetch') ||
            error.message.includes('CORS') ||
            error.message.includes('ERR_FAILED') ||
            error.message.includes('network');

        // Show error message instead of fallback
        scenarioSelector.innerHTML = `
            <div class="error-message" style="background: #fef2f2; color: #dc2626; padding: 20px; border-radius: 10px; text-align: center; margin: 20px 0;">
                <i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 10px;"></i>
                <h3>Unable to Load Scenarios</h3>
                ${isCorsError ? `
                    <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 15px 0; text-align: left; border-radius: 5px;">
                        <strong style="color: #92400e;">CORS/Network Error Detected:</strong>
                        <p style="margin: 10px 0 0 0; color: #78350f;">This error usually means you're opening the file directly (file:// protocol). 
                        You need to run a local web server. See the README.md file for instructions.</p>
                        <p style="margin: 10px 0 0 0; color: #78350f;"><strong>Quick fix:</strong> Run <code style="background: #fbbf24; padding: 2px 6px; border-radius: 3px;">php -S localhost:8000</code> in your project folder, then visit <code style="background: #fbbf24; padding: 2px 6px; border-radius: 3px;">http://localhost:8000/frontend/chat.html</code></p>
                    </div>
                ` : ''}
                <p>Could not connect to the database to load scenarios.</p>
                <p><strong>Error:</strong> ${error.message}</p>
                <div style="margin-top: 15px;">
                    <button onclick="refreshScenarios()" class="btn btn-primary" style="background: #059669; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">
                        <i class="fas fa-sync-alt"></i> Try Again
                    </button>
                </div>
                <p style="margin-top: 10px; font-size: 0.9em; opacity: 0.8;">
                    Make sure the database is configured and scenarios are created in the admin panel.
                </p>
            </div>
        `;
    }
}

function selectScenario(role, scenarioSource = null, clickedElement = null) {
    // Remove previous selection
    document.querySelectorAll('.scenario-card').forEach(card => {
        card.classList.remove('selected');
    });

    // Add selection to clicked card
    if (clickedElement) {
        clickedElement.closest('.scenario-card').classList.add('selected');
    } else {
        // Alternative: find the card by data attribute or role
        const cards = document.querySelectorAll('.scenario-card');
        cards.forEach(card => {
            if (card.dataset.scenarioRole === role) {
                card.classList.add('selected');
            }
        });
    }

    selectedRole = role;
    currentScenario = scenarioSource ? scenarioSource[role] : (window.adminScenarios ? window.adminScenarios[role] : null);

    if (currentScenario) {
        // Ensure scenario has an ID for analytics
        if (currentScenario.id) {
            if (typeof currentScenario.id === 'string' && !isNaN(currentScenario.id)) {
                currentScenario.id = parseInt(currentScenario.id);
                console.log('✅ Converted scenario ID to integer:', currentScenario.id);
            } else {
                console.log('✅ Valid scenario ID:', currentScenario.id);
            }
        } else {
            console.warn('⚠️ Scenario missing ID, analytics will not work');
            currentScenario.id = null;
        }
    }

    console.log('🎯 Selected scenario:', role, 'ID:', currentScenario?.id, 'from', scenarioSource ? 'admin' : 'default');

    // Update start button
    const startBtn = document.querySelector('.start-btn');
    if (startBtn) {
        startBtn.innerHTML = `
            Start ${currentScenario ? currentScenario.scenario_title : 'Training'}
            <i class="fas fa-arrow-right"></i>
        `;
        // Enable the button when a scenario is selected
        startBtn.disabled = false;
    }
}

function startChat() {
    if (!currentScenario) {
        alert('Please select a scenario first.');
        return;
    }

    // Ensure fallback scenarios convert their steps to array format
    if (currentScenario.steps && !Array.isArray(currentScenario.steps)) {
        console.log('🔄 Converting scenario steps from object to array format');
        currentScenario.steps = Object.values(currentScenario.steps || {});
    }

    // Hide welcome screen
    document.querySelector('.welcome-screen').style.display = 'none';
    document.querySelector('.messages-area').style.display = 'flex';
    document.querySelector('.response-container').style.display = 'block';

    // Initialize chat
    isChatting = true;
    startTime = Date.now();
    currentStep = null;

    // Reset score data
    scoreData.selectedResponses = [];
    scoreData.good = 0;
    scoreData.medium = 0;
    scoreData.bad = 0;

    // Calculate maximum possible score
    calculateMaxPossibleScore();

    // Start with first step
    const firstStep = currentScenario.steps.find(step => step.id === 'greeting') || currentScenario.steps[0];
    if (firstStep) {
        currentStep = firstStep.id;
        displayBotMessage(firstStep.message);
        displayResponseOptions(firstStep.responses);
    }
}

function calculateMaxPossibleScore() {
    let maxScore = 0;

    currentScenario.steps.forEach(step => {
        if (step.responses) {
            let stepMaxScore = 0;
            step.responses.forEach(response => {
                if (response.score_weight && response.score_level) {
                    const weight = currentScenario.scoring_rules?.weights?.[response.score_weight];
                    const level = currentScenario.scoring_rules?.levels?.[response.score_level];
                    if (weight !== undefined && level !== undefined) {
                        stepMaxScore = Math.max(stepMaxScore, weight * level);
                    }
                }
            });
            maxScore += stepMaxScore;
        }
    });

    scoreData.maxPossibleScore = maxScore;
    console.log('Maximum possible score:', maxScore);
}

function displayBotMessage(message) {
    const messagesArea = document.querySelector('.messages-area');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot';

    messageDiv.innerHTML = `
        <div class="message-avatar bot-message-avatar">
            <i class="fas fa-shield-virus"></i>
        </div>
        <div class="message-content">
            <div class="message-bubble">
                <div class="message-text">${message}</div>
                <div class="message-time">${new Date().toLocaleTimeString()}</div>
            </div>
        </div>
    `;

    messagesArea.appendChild(messageDiv);

    // Auto-scroll with delay for animation
    setTimeout(() => {
        messagesArea.scrollTop = messagesArea.scrollHeight;
    }, 1500);
}

function displayResponseOptions(responses) {
    const responseContainer = document.querySelector('.response-options');
    responseContainer.innerHTML = '';

    responses.forEach((response, index) => {
        const button = document.createElement('button');
        button.className = 'response-btn';
        button.textContent = response.text;
        button.onclick = () => selectResponse(response, index);
        responseContainer.appendChild(button);
    });

    // Show response container with delay
    setTimeout(() => {
        document.querySelector('.response-container').style.display = 'block';
    }, 2000);
}

function selectResponse(response, index) {
    // Track the response
    trackResponse(response);

    // Display user message
    displayUserMessage(response.text);

    // Hide response options temporarily
    document.querySelector('.response-container').style.display = 'none';

    // Process next step
    setTimeout(() => {
        processNextStep(response.next);
    }, 1000);
}

function displayUserMessage(message) {
    const messagesArea = document.querySelector('.messages-area');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user';

    messageDiv.innerHTML = `
        <div class="message-avatar user-message-avatar">
            <i class="fas fa-user"></i>
        </div>
        <div class="message-content">
            <div class="message-bubble">
                <div class="message-text">${message}</div>
                <div class="message-time">${new Date().toLocaleTimeString()}</div>
            </div>
        </div>
    `;

    messagesArea.appendChild(messageDiv);
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

function trackResponse(response) {
    scoreData.selectedResponses.push(response);

    // Update score counters
    if (response.score_level === 'Good') {
        scoreData.good++;
    } else if (response.score_level === 'Medium') {
        scoreData.medium++;
    } else {
        scoreData.bad++;
    }

    // Create tag mapping entry if it doesn't exist
    const tagKey = `${response.score_weight}_${response.score_level}`;
    if (!defaultTagMapping[tagKey]) {
        defaultTagMapping[tagKey] = {
            tag: response.tag || 'Communication',
            link: '#'
        };
    }
}

function processNextStep(nextStepId) {
    if (nextStepId === 'end' || !nextStepId) {
        // End of scenario
        endChat();
        return;
    }

    const nextStep = currentScenario.steps.find(step => step.id === nextStepId);
    if (nextStep) {
        currentStep = nextStep.id;
        displayBotMessage(nextStep.message);
        displayResponseOptions(nextStep.responses);
    } else {
        console.error('Next step not found:', nextStepId);
        endChat();
    }
}

function endChat() {
    isChatting = false;
    const endTime = Date.now();
    const duration = Math.round((endTime - startTime) / 1000);

    // Calculate final score
    let totalScore = 0;
    scoreData.selectedResponses.forEach(response => {
        const weight = currentScenario.scoring_rules?.weights?.[response.score_weight] || 1;
        const level = currentScenario.scoring_rules?.levels?.[response.score_level] || 0;
        totalScore += weight * level;
    });

    const finalScore = scoreData.maxPossibleScore > 0
        ? Math.round((totalScore / scoreData.maxPossibleScore) * 100)
        : 0;

    console.log('🎯 Chat completed:', {
        duration: duration + 's',
        finalScore: finalScore + '%',
        responses: scoreData.selectedResponses.length
    });

    // Show score modal
    showScoreModal(finalScore, duration);

    // Prepare session data for saving
    const sessionData = {
        responses: scoreData.selectedResponses,
        tags: [...new Set(scoreData.selectedResponses.map(r => r.tag))],
        score_breakdown: {
            good: scoreData.good,
            medium: scoreData.medium,
            bad: scoreData.bad,
            max_possible: scoreData.maxPossibleScore
        }
    };

    // Save to database
    console.log('💾 Saving session to database...');
    saveSessionToDatabase(sessionData, finalScore, duration);
}

// Enhanced session saving with comprehensive error handling
function saveSessionToDatabase(sessionData, score, time) {
    console.log('🔍 Starting session save process...');
    console.log('Current scenario:', currentScenario);

    if (!currentScenario) {
        console.error('❌ No current scenario selected');
        showToast('Cannot save session: no scenario selected', 'error');
        return;
    }

    // Validate scenario ID
    const scenarioId = parseInt(currentScenario.id);
    if (!Number.isInteger(scenarioId) || scenarioId <= 0) {
        console.error('❌ Invalid scenario ID:', currentScenario.id, 'parsed as:', scenarioId);
        showToast('Cannot save session: invalid scenario ID', 'error');
        return;
    }

    const payload = {
        scenario_id: scenarioId,
        user_id: generateUserId(),
        session_data: sessionData,
        final_score: parseFloat(score),
        duration: parseInt(time),
        status: 'completed'
    };

    console.log('📤 Session payload:', payload);

    // Use stable API URLs with relative paths
    const apiEndpoints = [
        API_CONFIG.SESSIONS_API
    ];

    console.log('🔗 API Endpoints:', apiEndpoints);

    let attemptCount = 0;
    const maxAttempts = apiEndpoints.length * 2; // Allow retries

    async function trySaveSession(endpointIndex = 0) {
        attemptCount++;

        if (attemptCount > maxAttempts) {
            console.error('❌ Maximum save attempts exceeded');
            showToast('Failed to save session data after multiple attempts', 'error');
            return;
        }

        if (endpointIndex >= apiEndpoints.length) {
            // Retry from first endpoint if we haven't exceeded max attempts
            console.log('🔄 Retrying from first endpoint...');
            setTimeout(() => trySaveSession(0), 2000);
            return;
        }

        const endpoint = apiEndpoints[endpointIndex];
        console.log(`🚀 Attempt ${attemptCount}: Trying endpoint ${endpointIndex + 1}/${apiEndpoints.length}: ${endpoint}`);

        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout

            const response = await fetch(endpoint, {
                signal: controller.signal,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(payload)
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            console.log('📥 Save response:', result);

            if (result.success) {
                console.log('✅ Session saved successfully');
                showToast('Training session saved successfully!', 'success');
                return;
            } else {
                throw new Error(result.message || result.error || 'Unknown error from server');
            }

        } catch (error) {
            console.error(`❌ Endpoint ${endpointIndex + 1} failed:`, error.message);

            if (error.name === 'AbortError') {
                console.error('Request timed out');
            } else if (error.message.includes('Failed to fetch')) {
                console.error('Network connectivity issue');
            }

            // Try next endpoint after a short delay
            setTimeout(() => trySaveSession(endpointIndex + 1), 1000);
        }
    }

    // Start the save attempt
    trySaveSession();
}

function generateUserId() {
    // Generate a simple user ID for anonymous tracking
    let userId = localStorage.getItem('shing_user_id');
    if (!userId) {
        userId = 'user_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
        localStorage.setItem('shing_user_id', userId);
    }
    return userId;
}

function showScoreModal(score, duration) {
    const modal = document.getElementById('score-modal');
    if (!modal) return;

    // Update modal content
    document.querySelector('.score-value').textContent = score + '%';
    document.querySelector('.score-message').textContent = getScoreMessage(score);

    // Update stats
    const stats = modal.querySelectorAll('.stat-value');
    if (stats.length >= 3) {
        stats[0].textContent = scoreData.good;
        stats[1].textContent = scoreData.medium;
        stats[2].textContent = scoreData.bad;
    }

    // Generate clickable tag breakdown
    generateTagBreakdown();

    // Show modal
    modal.classList.add('active');
}

function generateTagBreakdown() {
    const tagBreakdownList = document.getElementById('tag-breakdown-list');
    if (!tagBreakdownList) return;

    // Count responses by tag
    const tagCounts = {};
    const tagScores = {};

    scoreData.selectedResponses.forEach(response => {
        const tag = response.tag || 'Unknown';

        if (!tagCounts[tag]) {
            tagCounts[tag] = { good: 0, medium: 0, bad: 0, total: 0 };
            tagScores[tag] = { totalPoints: 0, maxPoints: 0 };
        }

        tagCounts[tag].total++;

        // Count by score level
        if (response.score_level === 'Good') {
            tagCounts[tag].good++;
        } else if (response.score_level === 'Medium') {
            tagCounts[tag].medium++;
        } else {
            tagCounts[tag].bad++;
        }

        // Calculate points for this response
        const weight = currentScenario.scoring_rules?.weights?.[response.score_weight] || 1;
        const level = currentScenario.scoring_rules?.levels?.[response.score_level] || 0;
        const points = weight * level;
        const maxPoints = weight * (currentScenario.scoring_rules?.levels?.Good || 3);

        tagScores[tag].totalPoints += points;
        tagScores[tag].maxPoints += maxPoints;
    });

    // Generate HTML for tag breakdown
    let tagBreakdownHTML = '';

    Object.keys(tagCounts).forEach(tag => {
        const counts = tagCounts[tag];
        const scores = tagScores[tag];
        const percentage = scores.maxPoints > 0 ? Math.round((scores.totalPoints / scores.maxPoints) * 100) : 0;

        // Get tag info from scenario scoring rules
        const tagMapping = currentScenario.scoring_rules?.tag_mapping || {};
        const tagInfo = tagMapping[tag] || { description: 'Communication skill', link: '#' };

        // Determine performance class
        let performanceClass = 'poor';
        if (percentage >= 80) performanceClass = 'excellent';
        else if (percentage >= 60) performanceClass = 'good';
        else if (percentage >= 40) performanceClass = 'fair';

        tagBreakdownHTML += `
            <div class="tag-breakdown-item ${performanceClass}">
                <div class="tag-header">
                    <div class="tag-info">
                        <h4 class="tag-name">
                            ${tagInfo.link && tagInfo.link !== '#' ?
                `<a href="${tagInfo.link}" target="_blank" class="tag-link">
                                    <i class="fas fa-external-link-alt"></i>
                                    ${tag}
                                </a>` :
                tag
            }
                        </h4>
                        <p class="tag-description">${tagInfo.description}</p>
                    </div>
                    <div class="tag-score">
                        <span class="tag-percentage">${percentage}%</span>
                        <span class="tag-responses">${counts.total} responses</span>
                    </div>
                </div>
                <div class="tag-breakdown-bars">
                    <div class="breakdown-bar">
                        <div class="bar-segment good" style="width: ${(counts.good / counts.total) * 100}%" title="Good: ${counts.good}"></div>
                        <div class="bar-segment medium" style="width: ${(counts.medium / counts.total) * 100}%" title="Medium: ${counts.medium}"></div>
                        <div class="bar-segment bad" style="width: ${(counts.bad / counts.total) * 100}%" title="Bad: ${counts.bad}"></div>
                    </div>
                    <div class="breakdown-legend">
                        <span class="legend-item good">Good: ${counts.good}</span>
                        <span class="legend-item medium">Medium: ${counts.medium}</span>
                        <span class="legend-item bad">Bad: ${counts.bad}</span>
                    </div>
                </div>
            </div>
        `;
    });

    if (tagBreakdownHTML) {
        tagBreakdownList.innerHTML = tagBreakdownHTML;
        document.getElementById('tag-breakdown-section').style.display = 'block';
    } else {
        document.getElementById('tag-breakdown-section').style.display = 'none';
    }
}

function getScoreMessage(score) {
    if (score >= 90) return 'Outstanding performance! You demonstrated excellent clinical communication skills.';
    if (score >= 80) return 'Great job! Your communication was effective and professional.';
    if (score >= 70) return 'Good work! There are some areas for improvement in your communication approach.';
    if (score >= 60) return 'Fair performance. Consider reviewing communication techniques for better patient interaction.';
    return 'This scenario highlighted areas where your communication skills can be strengthened.';
}

function closeScoreModal() {
    const modal = document.getElementById('score-modal');
    if (modal) {
        modal.classList.remove('active');
    }
}

function resetChat() {
    // Reset all variables
    currentScenario = null;
    selectedRole = null;
    currentStep = null;
    isChatting = false;
    startTime = null;

    // Reset score data
    scoreData.selectedResponses = [];
    scoreData.good = 0;
    scoreData.medium = 0;
    scoreData.bad = 0;
    scoreData.maxPossibleScore = 0;

    // Reset start button
    const startBtn = document.querySelector('.start-btn');
    if (startBtn) {
        startBtn.disabled = true;
        startBtn.innerHTML = `
            Select a scenario to begin
            <i class="fas fa-arrow-right"></i>
        `;
    }

    // Clear messages
    document.querySelector('.messages-area').innerHTML = '';
    document.querySelector('.response-options').innerHTML = '';

    // Show welcome screen
    document.querySelector('.welcome-screen').style.display = 'flex';
    document.querySelector('.messages-area').style.display = 'none';
    document.querySelector('.response-container').style.display = 'none';

    // Reload scenarios in welcome screen
    loadScenariosInWelcome();

    // Restore selected scenario if any
    if (selectedRole) {
        setTimeout(() => {
            const card = document.querySelector(`[data-scenario-role="${selectedRole}"]`);
            if (card) {
                card.classList.add('selected');
            }
        }, 500);
    }
}

// Function to manually refresh scenarios from admin
async function refreshScenarios() {
    console.log('🔄 Manually refreshing scenarios...');

    // Show loading indicator
    const refreshBtn = document.querySelector('[onclick="refreshScenarios()"]');
    if (refreshBtn) {
        const icon = refreshBtn.querySelector('i');
        icon.className = 'fas fa-spinner fa-spin';
        refreshBtn.disabled = true;
    }

    try {
        // Check if we're on the right page
        const scenarioSelector = document.getElementById('scenario-selector');
        if (!scenarioSelector) {
            console.log('ℹ️ No scenario selector found - might be on wrong page');
            showToast('Refresh only works on scenario selection page', 'warning');
            return;
        }

        await loadScenariosInWelcome();

        // Check if scenarios were actually loaded successfully
        // Wait a bit for the UI to update, then check if there are scenario cards
        setTimeout(() => {
            const scenarioCards = document.querySelectorAll('.scenario-card');
            const errorMessage = scenarioSelector.querySelector('.error-message');

            if (errorMessage) {
                // Error message is showing, don't show success
                console.log('⚠️ Scenarios failed to load - error message displayed');
            } else if (scenarioCards.length > 0) {
                // Success - scenarios are displayed
                showToast('Scenarios refreshed successfully!', 'success');
            } else {
                // No scenarios found
                showToast('No scenarios available', 'warning');
            }
        }, 500);

    } catch (error) {
        console.error('❌ Failed to refresh scenarios:', error);
        showToast('Failed to refresh scenarios: ' + error.message, 'error');
    } finally {
        // Restore button
        if (refreshBtn) {
            const icon = refreshBtn.querySelector('i');
            icon.className = 'fas fa-sync-alt';
            refreshBtn.disabled = false;
        }
    }
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        padding: 15px 20px;
        border-radius: 5px;
        z-index: 1000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
    `;
    toast.textContent = message;

    document.body.appendChild(toast);

    // Show toast
    setTimeout(() => {
        toast.style.transform = 'translateX(0)';
    }, 100);

    // Hide toast
    setTimeout(() => {
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (document.body.contains(toast)) {
                document.body.removeChild(toast);
            }
        }, 300);
    }, 3000);
}

function retryChat() {
    // Close the score modal first
    closeScoreModal();

    // Reset the chat but keep the selected scenario
    const savedScenario = currentScenario;
    const savedRole = selectedRole;

    // Reset chat state
    resetChat();

    // Restore the selected scenario
    if (savedScenario && savedRole) {
        setTimeout(() => {
            currentScenario = savedScenario;
            selectedRole = savedRole;

            // Re-select the scenario card
            const card = document.querySelector(`[data-scenario-role="${savedRole}"]`);
            if (card) {
                card.classList.add('selected');
            }

            // Enable and update the start button
            const startBtn = document.querySelector('.start-btn');
            if (startBtn) {
                startBtn.disabled = false;
                startBtn.innerHTML = `
                    Start ${currentScenario.scenario_title}
                    <i class="fas fa-arrow-right"></i>
                `;
            }
        }, 500);
    }
}

function showInfo() {
    alert('Shing Chat - Medical Training Assistant\n\nPractice your clinical communication skills with AI-powered scenarios. Get instant feedback and track your progress.');
}