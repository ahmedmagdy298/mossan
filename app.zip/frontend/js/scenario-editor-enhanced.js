/**
 * Enhanced Scenario Editor with Visual Interface
 * Replaces JSON editing with user-friendly forms
 */

class EnhancedScenarioEditor {
    constructor() {
        this.currentScenario = null;
        this.currentSteps = [];
        this.tagLinks = {
            'Greeting': 'https://example.com/greeting-guide',
            'Burden-Risk': 'https://example.com/risk-communication',
            'Burden-Symptoms': 'https://example.com/symptoms-guide',
            'Solution': 'https://example.com/solution-presentation',
            'Safety': 'https://example.com/safety-concerns'
        };
        this.init();
    }

    init() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        document.addEventListener('click', (e) => {
            if (e.target.matches('.enhanced-edit-btn')) {
                const scenarioId = e.target.dataset.scenarioId;
                this.openEnhancedEditor(scenarioId);
            }
            
            if (e.target.matches('.add-step-btn')) {
                this.addStep();
            }
            
            if (e.target.matches('.remove-step-btn')) {
                const stepIndex = parseInt(e.target.dataset.stepIndex);
                this.removeStep(stepIndex);
            }
            
            if (e.target.matches('.add-response-btn')) {
                const stepIndex = parseInt(e.target.dataset.stepIndex);
                this.addResponse(stepIndex);
            }
            
            if (e.target.matches('.remove-response-btn')) {
                const stepIndex = parseInt(e.target.dataset.stepIndex);
                const responseIndex = parseInt(e.target.dataset.responseIndex);
                this.removeResponse(stepIndex, responseIndex);
            }
        });
    }

    async openEnhancedEditor(scenarioId) {
        try {
            const response = await fetch(`../admin/api/scenarios.php?id=${scenarioId}`);
            const result = await response.json();
            
            if (result.success) {
                this.currentScenario = result.data;
                this.currentSteps = result.data.scenario_data?.steps || [];
                this.showEnhancedModal();
            } else {
                this.showError('Failed to load scenario: ' + result.message);
            }
        } catch (error) {
            console.error('Load scenario error:', error);
            this.showError('Failed to load scenario');
        }
    } 
   showEnhancedModal() {
        const modal = this.createEnhancedModal();
        document.body.appendChild(modal);
        
        // Populate basic info
        document.getElementById('enhanced-title').value = this.currentScenario.title || '';
        document.getElementById('enhanced-description').value = this.currentScenario.description || '';
        document.getElementById('enhanced-status').value = this.currentScenario.status || 'active';
        
        // Render steps
        this.renderSteps();
        
        modal.style.display = 'block';
    }

    createEnhancedModal() {
        const modalHtml = `
            <div id="enhanced-scenario-modal" class="enhanced-modal">
                <div class="enhanced-modal-content">
                    <div class="enhanced-modal-header">
                        <h2>Enhanced Scenario Editor</h2>
                        <span class="enhanced-close" onclick="this.closest('.enhanced-modal').remove()">&times;</span>
                    </div>
                    
                    <div class="enhanced-modal-body">
                        <!-- Basic Info -->
                        <div class="enhanced-section">
                            <h3>Basic Information</h3>
                            <div class="enhanced-form-row">
                                <div class="enhanced-form-group">
                                    <label for="enhanced-title">Title</label>
                                    <input type="text" id="enhanced-title" required>
                                </div>
                                <div class="enhanced-form-group">
                                    <label for="enhanced-status">Status</label>
                                    <select id="enhanced-status">
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div class="enhanced-form-group">
                                <label for="enhanced-description">Description</label>
                                <textarea id="enhanced-description" rows="3"></textarea>
                            </div>
                        </div>

                        <!-- Steps Section -->
                        <div class="enhanced-section">
                            <div class="enhanced-section-header">
                                <h3>Scenario Steps</h3>
                                <button type="button" class="btn btn-primary add-step-btn">
                                    <i class="fas fa-plus"></i> Add Step
                                </button>
                            </div>
                            <div id="steps-container"></div>
                        </div>
                    </div>
                    
                    <div class="enhanced-modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="this.closest('.enhanced-modal').remove()">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="enhancedScenarioEditor.saveEnhancedScenario()">Save Scenario</button>
                    </div>
                </div>
            </div>
        `;

        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = modalHtml;
        return tempDiv.firstElementChild;
    }

    renderSteps() {
        const container = document.getElementById('steps-container');
        container.innerHTML = '';

        this.currentSteps.forEach((step, stepIndex) => {
            const stepHtml = this.createStepHtml(step, stepIndex);
            container.appendChild(stepHtml);
        });
    }    
createStepHtml(step, stepIndex) {
        const stepDiv = document.createElement('div');
        stepDiv.className = 'enhanced-step-card';
        stepDiv.innerHTML = `
            <div class="enhanced-step-header">
                <h4>Step ${stepIndex + 1}</h4>
                <button type="button" class="btn-icon danger remove-step-btn" data-step-index="${stepIndex}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            
            <div class="enhanced-form-row">
                <div class="enhanced-form-group">
                    <label>Step ID</label>
                    <input type="text" class="step-id" value="${step.id || ''}" placeholder="e.g., greeting">
                </div>
                <div class="enhanced-form-group">
                    <label>Speaker</label>
                    <select class="step-speaker">
                        <option value="bot" ${step.speaker === 'bot' ? 'selected' : ''}>Bot</option>
                        <option value="patient" ${step.speaker === 'patient' ? 'selected' : ''}>Patient</option>
                    </select>
                </div>
            </div>
            
            <div class="enhanced-form-group">
                <label>Message</label>
                <textarea class="step-message" rows="2" placeholder="Enter the message for this step">${step.message || ''}</textarea>
            </div>
            
            <div class="enhanced-responses-section">
                <div class="enhanced-responses-header">
                    <h5>Response Options</h5>
                    <button type="button" class="btn btn-sm btn-primary add-response-btn" data-step-index="${stepIndex}">
                        <i class="fas fa-plus"></i> Add Response
                    </button>
                </div>
                <div class="responses-container" data-step-index="${stepIndex}">
                    ${this.renderResponses(step.responses || [], stepIndex)}
                </div>
            </div>
        `;
        
        return stepDiv;
    }

    renderResponses(responses, stepIndex) {
        return responses.map((response, responseIndex) => `
            <div class="enhanced-response-card">
                <div class="enhanced-response-header">
                    <span>Response ${responseIndex + 1}</span>
                    <button type="button" class="btn-icon danger remove-response-btn" 
                            data-step-index="${stepIndex}" data-response-index="${responseIndex}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                
                <div class="enhanced-form-group">
                    <label>Response Text</label>
                    <textarea class="response-text" rows="2" placeholder="Enter response option">${response.text || ''}</textarea>
                </div>
                
                <div class="enhanced-form-row">
                    <div class="enhanced-form-group">
                        <label>Next Step</label>
                        <input type="text" class="response-next" value="${response.next || ''}" placeholder="e.g., a1">
                    </div>
                    <div class="enhanced-form-group">
                        <label>Tag</label>
                        <select class="response-tag">
                            <option value="">Select Tag</option>
                            <option value="Greeting" ${response.tag === 'Greeting' ? 'selected' : ''}>Greeting</option>
                            <option value="Burden-Risk" ${response.tag === 'Burden-Risk' ? 'selected' : ''}>Burden-Risk</option>
                            <option value="Burden-Symptoms" ${response.tag === 'Burden-Symptoms' ? 'selected' : ''}>Burden-Symptoms</option>
                            <option value="Solution" ${response.tag === 'Solution' ? 'selected' : ''}>Solution</option>
                            <option value="Safety" ${response.tag === 'Safety' ? 'selected' : ''}>Safety</option>
                        </select>
                    </div>
                </div>
                
                <div class="enhanced-form-row">
                    <div class="enhanced-form-group">
                        <label>Score Weight</label>
                        <select class="response-weight">
                            <option value="High" ${response.score_weight === 'High' ? 'selected' : ''}>High (3 points)</option>
                            <option value="Medium" ${response.score_weight === 'Medium' ? 'selected' : ''}>Medium (2 points)</option>
                            <option value="Low" ${response.score_weight === 'Low' ? 'selected' : ''}>Low (1 point)</option>
                        </select>
                    </div>
                    <div class="enhanced-form-group">
                        <label>Score Level</label>
                        <select class="response-level">
                            <option value="Good" ${response.score_level === 'Good' ? 'selected' : ''}>Good (3 points)</option>
                            <option value="Medium" ${response.score_level === 'Medium' ? 'selected' : ''}>Medium (2 points)</option>
                            <option value="Low" ${response.score_level === 'Low' ? 'selected' : ''}>Low (1 point)</option>
                            <option value="Bad" ${response.score_level === 'Bad' ? 'selected' : ''}>Bad (0 points)</option>
                        </select>
                    </div>
                </div>
                
                <div class="enhanced-form-group">
                    <label>Feedback</label>
                    <textarea class="response-feedback" rows="2" placeholder="Feedback for this response">${response.feedback || ''}</textarea>
                </div>
                
                <div class="enhanced-form-group">
                    <label>Tag Link</label>
                    <input type="url" class="response-tag-link" value="${response.tag_link || ''}" placeholder="https://example.com/guide">
                </div>
            </div>
        `).join('');
    }  
  addStep() {
        const newStep = {
            id: `step_${Date.now()}`,
            speaker: 'bot',
            message: '',
            responses: []
        };
        
        this.currentSteps.push(newStep);
        this.renderSteps();
    }

    removeStep(stepIndex) {
        if (confirm('Are you sure you want to remove this step?')) {
            this.currentSteps.splice(stepIndex, 1);
            this.renderSteps();
        }
    }

    addResponse(stepIndex) {
        if (!this.currentSteps[stepIndex].responses) {
            this.currentSteps[stepIndex].responses = [];
        }
        
        const newResponse = {
            text: '',
            next: '',
            tag: '',
            score_weight: 'Medium',
            score_level: 'Medium',
            feedback: '',
            tag_link: ''
        };
        
        this.currentSteps[stepIndex].responses.push(newResponse);
        this.renderSteps();
    }

    removeResponse(stepIndex, responseIndex) {
        if (confirm('Are you sure you want to remove this response?')) {
            this.currentSteps[stepIndex].responses.splice(responseIndex, 1);
            this.renderSteps();
        }
    }

    async saveEnhancedScenario() {
        try {
            // Collect form data
            const title = document.getElementById('enhanced-title').value;
            const description = document.getElementById('enhanced-description').value;
            const status = document.getElementById('enhanced-status').value;
            
            if (!title.trim()) {
                this.showError('Title is required');
                return;
            }
            
            // Collect steps data
            const steps = this.collectStepsData();
            
            const scenarioData = {
                steps: steps
            };
            
            const scoringRules = {
                weights: {
                    'High': 3,
                    'Medium': 2,
                    'Low': 1
                },
                levels: {
                    'Good': 3,
                    'Medium': 2,
                    'Low': 1,
                    'Bad': 0
                },
                tag_mapping: {
                    'Greeting': 'Initial patient interaction and rapport building',
                    'Burden-Risk': 'Communicating disease risks and susceptibility',
                    'Burden-Symptoms': 'Describing disease symptoms and complications',
                    'Solution': 'Presenting treatment or prevention options',
                    'Safety': 'Addressing safety concerns and side effects'
                }
            };
            
            const data = {
                title: title,
                description: description,
                status: status,
                scenario_data: scenarioData,
                scoring_rules: scoringRules
            };

            const url = `../admin/api/scenarios.php?id=${this.currentScenario.id}`;
            const response = await fetch(url, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                this.showSuccess('Scenario updated successfully!');
                document.getElementById('enhanced-scenario-modal').remove();
                
                // Reload scenarios if scenario manager exists
                if (window.scenarioManager) {
                    window.scenarioManager.loadScenarios();
                }
            } else {
                this.showError('Failed to save scenario: ' + result.message);
            }

        } catch (error) {
            console.error('Save scenario error:', error);
            this.showError('Failed to save scenario: ' + error.message);
        }
    } 
   collectStepsData() {
        const stepCards = document.querySelectorAll('.enhanced-step-card');
        const steps = [];
        
        stepCards.forEach((stepCard, stepIndex) => {
            const stepId = stepCard.querySelector('.step-id').value;
            const speaker = stepCard.querySelector('.step-speaker').value;
            const message = stepCard.querySelector('.step-message').value;
            
            const responses = [];
            const responseCards = stepCard.querySelectorAll('.enhanced-response-card');
            
            responseCards.forEach(responseCard => {
                const response = {
                    text: responseCard.querySelector('.response-text').value,
                    next: responseCard.querySelector('.response-next').value,
                    tag: responseCard.querySelector('.response-tag').value,
                    score_weight: responseCard.querySelector('.response-weight').value,
                    score_level: responseCard.querySelector('.response-level').value,
                    feedback: responseCard.querySelector('.response-feedback').value,
                    tag_link: responseCard.querySelector('.response-tag-link').value
                };
                
                if (response.text.trim()) {
                    responses.push(response);
                }
            });
            
            if (stepId && message.trim()) {
                steps.push({
                    id: stepId,
                    speaker: speaker,
                    message: message,
                    responses: responses
                });
            }
        });
        
        return steps;
    }

    showSuccess(message) {
        this.showToast(message, 'success');
    }

    showError(message) {
        this.showToast(message, 'error');
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `enhanced-toast enhanced-toast-${type}`;
        toast.innerHTML = `
            <div class="enhanced-toast-content">
                <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}"></i>
                <span>${message}</span>
            </div>
        `;

        document.body.appendChild(toast);

        setTimeout(() => toast.classList.add('show'), 100);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => document.body.removeChild(toast), 300);
        }, 3000);
    }
}

// Initialize the enhanced scenario editor
const enhancedScenarioEditor = new EnhancedScenarioEditor();

// Make it globally available
window.enhancedScenarioEditor = enhancedScenarioEditor;