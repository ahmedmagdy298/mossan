/**
 * Admin Dashboard JavaScript - Software Version
 * Handles general admin functionality and navigation
 */

document.addEventListener('DOMContentLoaded', function() {
    initializeAdmin();
});

function initializeAdmin() {
    console.log('🚀 Initializing admin dashboard...');
    
    try {
        setupNavigation();
        console.log('✅ Navigation setup completed');
    } catch (error) {
        console.error('❌ Navigation setup failed:', error);
    }
    
    try {
        setupCharts();
        console.log('✅ Charts setup completed');
    } catch (error) {
        console.error('❌ Charts setup failed:', error);
    }
    
    try {
        setupEventListeners();
        console.log('✅ Event listeners setup completed');
    } catch (error) {
        console.error('❌ Event listeners setup failed:', error);
    }
    
    console.log('🎉 Admin dashboard initialization complete');
}

function setupNavigation() {
    console.log('🧭 Setting up admin navigation...');
    
    const navItems = document.querySelectorAll('.nav-item');
    const sections = document.querySelectorAll('.content-section');
    
    console.log('Found navigation items:', navItems.length);
    console.log('Found content sections:', sections.length);
    
    if (navItems.length === 0) {
        console.error('❌ No navigation items found! Check if .nav-item elements exist.');
        return;
    }
    
    if (sections.length === 0) {
        console.error('❌ No content sections found! Check if .content-section elements exist.');
        return;
    }

    navItems.forEach((item, index) => {
        const sectionName = item.dataset.section;
        console.log(`Setting up nav item ${index}: ${sectionName}`);
        
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetSection = this.dataset.section;
            console.log('🎯 Navigating to section:', targetSection);
            
            if (!targetSection) {
                console.error('❌ No data-section attribute found on clicked item');
                return;
            }
            
            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            console.log('✅ Updated active nav item');
            
            // Show target section
            let sectionFound = false;
            sections.forEach(section => {
                section.classList.remove('active');
                if (section.id === targetSection + '-section') {
                    section.classList.add('active');
                    sectionFound = true;
                    console.log('✅ Activated section:', section.id);
                }
            });
            
            if (!sectionFound) {
                console.error('❌ Target section not found:', targetSection + '-section');
            }
            
            // Special handling for scenarios section to load data
            if (targetSection === 'scenarios' && window.scenarioManager) {
                console.log('🔄 Loading scenarios data...');
                window.scenarioManager.loadScenarios();
            }
        });
    });
    
    console.log('✅ Navigation setup complete');
}

function setupCharts() {
    // Sessions Chart
    const sessionsCtx = document.getElementById('sessionsChart');
    if (sessionsCtx) {
        new Chart(sessionsCtx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Sessions',
                    data: [12, 19, 3, 5, 2, 3, 9],
                    borderColor: '#059669',
                    backgroundColor: 'rgba(5, 150, 105, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // Scores Chart
    const scoresCtx = document.getElementById('scoresChart');
    if (scoresCtx) {
        new Chart(scoresCtx, {
            type: 'doughnut',
            data: {
                labels: ['Excellent (80-100%)', 'Good (60-79%)', 'Fair (40-59%)', 'Poor (0-39%)'],
                datasets: [{
                    data: [45, 30, 20, 5],
                    backgroundColor: [
                        '#10b981',
                        '#059669',
                        '#f59e0b',
                        '#ef4444'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
}

function setupEventListeners() {
    // Refresh data button
    const refreshBtn = document.querySelector('[onclick="refreshData()"]');
    if (refreshBtn) {
        refreshBtn.onclick = refreshData;
    }

    // Export buttons
    const exportSessionsBtn = document.querySelector('[onclick="exportSessions()"]');
    if (exportSessionsBtn) {
        exportSessionsBtn.onclick = exportSessions;
    }

    // View session buttons
    document.addEventListener('click', function(e) {
        if (e.target.matches('[onclick^="viewSession"]')) {
            const sessionId = e.target.getAttribute('onclick').match(/\d+/)[0];
            viewSession(sessionId);
        }
        
        if (e.target.matches('[onclick^="deleteSession"]')) {
            const sessionId = e.target.getAttribute('onclick').match(/\d+/)[0];
            deleteSession(sessionId);
        }
    });
}

function refreshData() {
    showToast('Refreshing data...', 'info');
    
    // Reload the page to get fresh data
    setTimeout(() => {
        window.location.reload();
    }, 1000);
}

function exportSessions() {
    showToast('Preparing export...', 'info');
    
    // Create a simple CSV export
    const table = document.querySelector('.data-table tbody');
    if (!table) return;
    
    const rows = Array.from(table.querySelectorAll('tr'));
    const csvContent = [
        ['Date', 'User', 'Scenario', 'Score', 'Duration', 'Status'].join(','),
        ...rows.map(row => {
            const cells = Array.from(row.querySelectorAll('td'));
            return cells.slice(0, 6).map(cell => {
                const text = cell.textContent.trim();
                return text.includes(',') ? `"${text}"` : text;
            }).join(',');
        })
    ].join('\n');
    
    downloadCSV(csvContent, 'sessions-export.csv');
}

function viewSession(sessionId) {
    showToast(`Viewing session ${sessionId}`, 'info');
    // Implement session detail view
}

function deleteSession(sessionId) {
    if (confirm('Are you sure you want to delete this session?')) {
        showToast(`Deleting session ${sessionId}`, 'info');
        // Implement session deletion
    }
}

function updateChart() {
    const timeRange = document.getElementById('timeRange').value;
    showToast(`Updating chart for last ${timeRange} days`, 'info');
    // Implement chart update based on time range
}

function generateReport() {
    showToast('Generating PDF report...', 'info');
    // Implement PDF report generation
}

function exportUsers() {
    showToast('Exporting user data...', 'info');
    // Implement user export
}

function downloadDocs() {
    showToast('Preparing documentation download...', 'info');
    // Implement documentation download
}

function downloadCSV(content, filename) {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}"></i>
            <span>${message}</span>
        </div>
    `;

    document.body.appendChild(toast);

    // Show toast
    setTimeout(() => toast.classList.add('show'), 100);

    // Hide toast
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(toast)) {
                document.body.removeChild(toast);
            }
        }, 300);
    }, 3000);
}
// 
Tag Performance Functions
function showTagDetails(tagName, event) {
    event.preventDefault();
    
    console.log('Showing details for tag:', tagName);
    
    // Create and show modal with tag details
    showTagModal(tagName);
}

function showTagModal(tagName) {
    // Create modal HTML
    const modalHTML = `
        <div class="modal-overlay" id="tag-modal-overlay">
            <div class="modal-container tag-modal">
                <div class="modal-header">
                    <h3 class="modal-title">
                        <i class="fas fa-tag"></i>
                        Tag Analysis: ${escapeHtml(tagName)}
                    </h3>
                    <button class="modal-close" onclick="closeTagModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="loading-spinner">
                        <i class="fas fa-spinner fa-spin"></i>
                        <p>Loading tag analysis...</p>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add modal to page
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Load tag data
    loadTagDetails(tagName);
}

function loadTagDetails(tagName) {
    // Simulate API call to get detailed tag information
    fetch(`api/tag-details.php?tag=${encodeURIComponent(tagName)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayTagDetails(tagName, data.details);
            } else {
                displayTagError(data.error || 'Failed to load tag details');
            }
        })
        .catch(error => {
            console.error('Error loading tag details:', error);
            displayTagError('Network error occurred while loading tag details');
        });
}

function displayTagDetails(tagName, details) {
    const modalBody = document.querySelector('#tag-modal-overlay .modal-body');
    
    const detailsHTML = `
        <div class="tag-details">
            <div class="tag-overview">
                <div class="tag-overview-card">
                    <div class="tag-overview-header">
                        <h4>${escapeHtml(tagName)}</h4>
                        <div class="tag-performance-badge ${getPerformanceClass(details.performance)}">
                            ${details.performance}% Performance
                        </div>
                    </div>
                    <div class="tag-stats-row">
                        <div class="tag-stat-item good">
                            <div class="stat-value">${details.good || 0}</div>
                            <div class="stat-label">Good Responses</div>
                        </div>
                        <div class="tag-stat-item medium">
                            <div class="stat-value">${details.medium || 0}</div>
                            <div class="stat-label">Medium Responses</div>
                        </div>
                        <div class="tag-stat-item bad">
                            <div class="stat-value">${details.bad || 0}</div>
                            <div class="stat-label">Poor Responses</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="tag-insights">
                <h5>Key Insights</h5>
                <div class="insights-list">
                    <div class="insight-item">
                        <i class="fas fa-lightbulb"></i>
                        <span>This tag represents ${escapeHtml(tagName.toLowerCase())} communication skills</span>
                    </div>
                    <div class="insight-item">
                        <i class="fas fa-chart-line"></i>
                        <span>Total responses recorded: ${(details.good || 0) + (details.medium || 0) + (details.bad || 0)}</span>
                    </div>
                    <div class="insight-item">
                        <i class="fas fa-target"></i>
                        <span>Performance level: ${getPerformanceLevel(details.performance)}</span>
                    </div>
                </div>
            </div>
            
            <div class="tag-recommendations">
                <h5>Recommendations</h5>
                <div class="recommendations-list">
                    ${getRecommendations(tagName, details.performance)}
                </div>
            </div>
        </div>
    `;
    
    modalBody.innerHTML = detailsHTML;
}

function displayTagError(errorMessage) {
    const modalBody = document.querySelector('#tag-modal-overlay .modal-body');
    modalBody.innerHTML = `
        <div class="error-state">
            <i class="fas fa-exclamation-triangle"></i>
            <h4>Unable to Load Tag Details</h4>
            <p>${escapeHtml(errorMessage)}</p>
            <button class="btn btn-primary" onclick="closeTagModal()">Close</button>
        </div>
    `;
}

function closeTagModal() {
    const modal = document.getElementById('tag-modal-overlay');
    if (modal) {
        modal.remove();
    }
}

function getPerformanceClass(performance) {
    if (performance >= 80) return 'excellent';
    if (performance >= 60) return 'good';
    if (performance >= 40) return 'fair';
    return 'poor';
}

function getPerformanceLevel(performance) {
    if (performance >= 80) return 'Excellent';
    if (performance >= 60) return 'Good';
    if (performance >= 40) return 'Needs Improvement';
    return 'Requires Attention';
}

function getRecommendations(tagName, performance) {
    const recommendations = [];
    
    if (performance < 60) {
        recommendations.push(`<div class="recommendation-item"><i class="fas fa-arrow-up"></i>Focus on improving ${tagName.toLowerCase()} techniques through additional practice</div>`);
        recommendations.push(`<div class="recommendation-item"><i class="fas fa-book"></i>Review best practices for ${tagName.toLowerCase()} in clinical settings</div>`);
    } else if (performance < 80) {
        recommendations.push(`<div class="recommendation-item"><i class="fas fa-star"></i>Good progress! Continue practicing ${tagName.toLowerCase()} scenarios</div>`);
        recommendations.push(`<div class="recommendation-item"><i class="fas fa-users"></i>Consider peer review sessions to refine ${tagName.toLowerCase()} skills</div>`);
    } else {
        recommendations.push(`<div class="recommendation-item"><i class="fas fa-trophy"></i>Excellent performance in ${tagName.toLowerCase()}! Consider mentoring others</div>`);
        recommendations.push(`<div class="recommendation-item"><i class="fas fa-graduation-cap"></i>Explore advanced ${tagName.toLowerCase()} techniques and scenarios</div>`);
    }
    
    return recommendations.join('');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}