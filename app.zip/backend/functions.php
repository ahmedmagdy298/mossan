<?php
/**
 * Backend Functions for Shing Chat Admin
 */

// Get analytics data
function getAnalyticsData($days = null) {
    global $pdo;
    
    try {
        $whereClause = '';
        $params = [];
        
        if ($days !== null) {
            $days = max(0, (int)$days); // Cast to int and ensure non-negative
            $whereClause = "WHERE created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)";
            // No params needed since we're interpolating the integer directly
        }
        
        // Get total sessions
        $stmt = $pdo->prepare("SELECT COUNT(*) as total_sessions FROM chat_sessions $whereClause");
        $stmt->execute(); // No params needed since we interpolated the integer
        $totalSessions = $stmt->fetch()['total_sessions'] ?? 0;
        
        // Get average score
        $scoreWhereClause = $whereClause ? "$whereClause AND final_score > 0" : "WHERE final_score > 0";
        $stmt = $pdo->prepare("SELECT AVG(final_score) as avg_score FROM chat_sessions $scoreWhereClause");
        $stmt->execute();
        $avgScore = round($stmt->fetch()['avg_score'] ?? 0, 1);
        
        // Get average duration
        $durationWhereClause = $whereClause ? "$whereClause AND duration > 0" : "WHERE duration > 0";
        $stmt = $pdo->prepare("SELECT AVG(duration) as avg_duration FROM chat_sessions $durationWhereClause");
        $stmt->execute();
        $avgDuration = round($stmt->fetch()['avg_duration'] ?? 0);
        
        // Get completion rate
        $stmt = $pdo->prepare("SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
            FROM chat_sessions $whereClause");
        $stmt->execute();
        $completion = $stmt->fetch();
        $completionRate = $completion['total'] > 0 ? round(($completion['completed'] / $completion['total']) * 100, 1) : 0;
        
        // Calculate growth rates (mock data for now)
        return [
            'total_sessions' => $totalSessions,
            'avg_score' => $avgScore,
            'avg_duration' => $avgDuration,
            'completion_rate' => $completionRate,
            'sessions_growth' => 12,
            'score_growth' => 5,
            'duration_change' => -3,
            'completion_growth' => 8
        ];
        
    } catch (PDOException $e) {
        error_log("Analytics error: " . $e->getMessage());
        return [
            'total_sessions' => 0,
            'avg_score' => 0,
            'avg_duration' => 0,
            'completion_rate' => 0,
            'sessions_growth' => 0,
            'score_growth' => 0,
            'duration_change' => 0,
            'completion_growth' => 0
        ];
    }
}

// Get all scenarios
function getAllScenarios() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("
            SELECT 
                s.id,
                s.title,
                s.description,
                s.scenario_data,
                s.scoring_rules,
                s.status,
                s.created_at,
                s.updated_at,
                COUNT(cs.id) as total_sessions,
                AVG(cs.final_score) as avg_score,
                AVG(cs.duration) as avg_duration
            FROM scenarios s
            LEFT JOIN chat_sessions cs ON s.id = cs.scenario_id
            WHERE s.status != 'deleted'
            GROUP BY s.id, s.title, s.description, s.scenario_data, s.scoring_rules, s.status, s.created_at, s.updated_at
            ORDER BY s.created_at DESC
        ");
        
        $scenarios = [];
        while ($row = $stmt->fetch()) {
            $scenarios[] = [
                'id' => $row['id'],
                'title' => $row['title'],
                'description' => $row['description'],
                'scenario_data' => $row['scenario_data'] ?? null,
                'scoring_rules' => $row['scoring_rules'] ?? null,
                'status' => $row['status'],
                'total_sessions' => $row['total_sessions'] ?? 0,
                'avg_score' => round($row['avg_score'] ?? 0, 1),
                'avg_duration' => round($row['avg_duration'] ?? 0),
                'created_at' => $row['created_at']
            ];
        }
        
        return $scenarios;
        
    } catch (PDOException $e) {
        error_log("Scenarios error: " . $e->getMessage());
        return [];
    }
}

// Get recent sessions
function getRecentSessions($limit = 10) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT 
                cs.*,
                s.title as scenario_name
            FROM chat_sessions cs
            LEFT JOIN scenarios s ON cs.scenario_id = s.id
            ORDER BY cs.created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        
        $sessions = [];
        while ($row = $stmt->fetch()) {
            $sessions[] = [
                'id' => $row['id'],
                'user_id' => $row['user_id'],
                'scenario_name' => $row['scenario_name'] ?? 'Unknown',
                'final_score' => round($row['final_score'], 1),
                'duration' => $row['duration'],
                'status' => $row['status'],
                'created_at' => $row['created_at']
            ];
        }
        
        return $sessions;
        
    } catch (PDOException $e) {
        error_log("Recent sessions error: " . $e->getMessage());
        return [];
    }
}

// Get score badge class
function getScoreBadgeClass($score) {
    if ($score >= 80) return 'excellent';
    if ($score >= 60) return 'good';
    if ($score >= 40) return 'fair';
    return 'poor';
}

// Get scenario by ID
function getScenarioById($id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM scenarios WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Get scenario error: " . $e->getMessage());
        return null;
    }
}

// Update scenario
function updateScenario($id, $data) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            UPDATE scenarios 
            SET title = ?, description = ?, scenario_data = ?, scoring_rules = ?, status = ?, updated_at = NOW()
            WHERE id = ?
        ");
        
        return $stmt->execute([
            $data['title'],
            $data['description'],
            json_encode($data['scenario_data']),
            json_encode($data['scoring_rules']),
            $data['status'],
            $id
        ]);
        
    } catch (PDOException $e) {
        error_log("Update scenario error: " . $e->getMessage());
        return false;
    }
}

// Create new scenario
function createScenario($data) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO scenarios (title, description, scenario_data, scoring_rules, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, NOW(), NOW())
        ");
        
        if ($stmt->execute([
            $data['title'],
            $data['description'],
            json_encode($data['scenario_data']),
            json_encode($data['scoring_rules']),
            $data['status'] ?? 'active'
        ])) {
            return $pdo->lastInsertId();
        }
        
        return false;
        
    } catch (PDOException $e) {
        error_log("Create scenario error: " . $e->getMessage());
        return false;
    }
}

// Delete scenario
function deleteScenario($id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("UPDATE scenarios SET status = 'deleted' WHERE id = ?");
        return $stmt->execute([$id]);
    } catch (PDOException $e) {
        error_log("Delete scenario error: " . $e->getMessage());
        return false;
    }
}

// Check if admin user exists
function checkAdminUser() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM admin_users WHERE status = 'active'");
        $result = $stmt->fetch();
        return $result['count'] > 0;
    } catch (PDOException $e) {
        error_log("Check admin user error: " . $e->getMessage());
        return false;
    }
}

// Create default admin user - ONLY for initial setup
function createDefaultAdmin($username = null, $password = null) {
    global $pdo;
    
    // SECURITY: Only create if no admin users exist
    try {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM admin_users WHERE status = 'active'");
        $result = $stmt->fetch();
        if ($result['count'] > 0) {
            error_log("Admin users already exist - skipping default admin creation");
            return false;
        }
        
        // Use provided credentials or generate secure defaults
        $adminUsername = $username ?: 'admin_' . bin2hex(random_bytes(4));
        $adminPassword = $password ?: bin2hex(random_bytes(16));
        
        $hashedPassword = password_hash($adminPassword, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
            INSERT INTO admin_users (username, password, role, status, created_at, updated_at)
            VALUES (?, ?, 'admin', 'active', NOW(), NOW())
        ");
        
        if ($stmt->execute([$adminUsername, $hashedPassword])) {
            error_log("Default admin created - Username: $adminUsername, Password: $adminPassword");
            return ['username' => $adminUsername, 'password' => $adminPassword];
        }
        
        return false;
    } catch (PDOException $e) {
        error_log("Create admin error: " . $e->getMessage());
        return false;
    }
}

// Alias for getScenarioById for API compatibility
function getScenario($id) {
    return getScenarioById($id);
}

// Get chat session by ID
function getChatSession($id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT cs.*, s.title AS scenario_name
            FROM chat_sessions cs
            LEFT JOIN scenarios s ON s.id = cs.scenario_id
            WHERE cs.id = ?
        ");
        $stmt->execute([$id]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Get chat session error: " . $e->getMessage());
        return null;
    }
}

/**
 * Enhanced session data validation with deep schema checking
 */
function validateSessionData($data) {
    $errors = [];
    
    // Required fields validation
    if (!isset($data["scenario_id"]) || !is_numeric($data["scenario_id"]) || $data["scenario_id"] <= 0) {
        $errors[] = "scenario_id must be a positive integer";
    }
    
    if (!isset($data["final_score"]) || !is_numeric($data["final_score"]) || $data["final_score"] < 0 || $data["final_score"] > 100) {
        $errors[] = "final_score must be between 0 and 100";
    }
    
    // Optional fields validation
    if (isset($data["duration"]) && (!is_numeric($data["duration"]) || $data["duration"] < 0 || $data["duration"] > 7200)) {
        $errors[] = "duration must be between 0 and 7200 seconds";
    }
    
    if (isset($data["status"]) && !in_array($data["status"], ["completed", "abandoned", "timeout"])) {
        $errors[] = "status must be completed, abandoned, or timeout";
    }
    
    // Session data structure validation
    if (isset($data["session_data"])) {
        if (!is_array($data["session_data"])) {
            $errors[] = "session_data must be an array";
        } else {
            $sessionData = $data["session_data"];
            
            if (isset($sessionData["responses"]) && !is_array($sessionData["responses"])) {
                $errors[] = "session_data.responses must be an array";
            }
            
            if (isset($sessionData["tags"]) && !is_array($sessionData["tags"])) {
                $errors[] = "session_data.tags must be an array";
            }
            
            if (isset($sessionData["score_breakdown"])) {
                if (!is_array($sessionData["score_breakdown"])) {
                    $errors[] = "session_data.score_breakdown must be an array";
                } else {
                    $breakdown = $sessionData["score_breakdown"];
                    $requiredKeys = ["good", "medium", "bad", "max_possible"];
                    foreach ($requiredKeys as $key) {
                        if (isset($breakdown[$key]) && (!is_numeric($breakdown[$key]) || $breakdown[$key] < 0)) {
                            $errors[] = "session_data.score_breakdown.$key must be a non-negative number";
                        }
                    }
                }
            }
        }
    }
    
    return $errors;
}

// Create chat session
function createChatSession(array $data) {
    global $pdo;
    
    // Validate input data
    $validationErrors = validateSessionData($data);
    if (!empty($validationErrors)) {
        error_log("Session validation failed: " . implode(", ", $validationErrors));
        return false;
    }
    
    // Ensure PDO connection exists
    if (!$pdo) {
        error_log("PDO connection not available in createChatSession");
        require_once __DIR__ . '/config.php';
        if (!$pdo) {
            error_log("Failed to establish PDO connection");
            return false;
        }
    }
    
    try {
        error_log("Creating chat session with data: " . json_encode($data));
        
        // Validate and sanitize scenario_id as integer
        $scenarioId = isset($data['scenario_id']) ? (int)$data['scenario_id'] : null;
        
        if ($scenarioId === null || $scenarioId <= 0) {
            error_log("Invalid scenario_id provided: " . var_export($data['scenario_id'], true));
            return false;
        }
        
        // Validate other numeric fields
        $finalScore = isset($data['final_score']) ? (float)$data['final_score'] : 0.0;
        $duration = isset($data['duration']) ? (int)$data['duration'] : 0;
        
        error_log("Validated data - Scenario ID: $scenarioId, Score: $finalScore, Duration: $duration");
        
        // Check if scenario exists
        $checkStmt = $pdo->prepare("SELECT id FROM scenarios WHERE id = ? AND status = 'active'");
        $checkStmt->execute([$scenarioId]);
        if (!$checkStmt->fetch()) {
            error_log("Scenario ID $scenarioId not found or not active");
            return false;
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO chat_sessions (scenario_id, user_id, session_data, final_score, duration, status)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $result = $stmt->execute([
            $scenarioId,
            $data['user_id'] ?? null,
            json_encode($data['session_data'] ?? []),
            $finalScore,
            $duration,
            $data['status'] ?? 'completed'
        ]);
        
        if ($result) {
            $insertId = $pdo->lastInsertId();
            error_log("Chat session created successfully with ID: $insertId");
            return $insertId; // Return the ID instead of just true
        } else {
            error_log("Chat session creation failed - execute returned false");
            $errorInfo = $stmt->errorInfo();
            error_log("SQL Error Info: " . json_encode($errorInfo));
            return false;
        }
        
    } catch (PDOException $e) {
        error_log("Create chat session PDO error: " . $e->getMessage());
        error_log("SQL State: " . $e->getCode());
        error_log("Error Info: " . json_encode($e->errorInfo ?? []));
        return false;
    } catch (Exception $e) {
        error_log("Create chat session general error: " . $e->getMessage());
        error_log("Stack trace: " . $e->getTraceAsString());
        return false;
    }
}

// Delete chat session
function deleteChatSession($id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM chat_sessions WHERE id = ?");
        return $stmt->execute([$id]);
    } catch (PDOException $e) {
        error_log("Delete chat session error: " . $e->getMessage());
        return false;
    }
}

// Get all users with pagination
function getAllUsers($limit = 100, $offset = 0) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT id, username, role, status, created_at
            FROM admin_users
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->bindValue(1, (int)$limit, PDO::PARAM_INT);
        $stmt->bindValue(2, (int)$offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Get all users error: " . $e->getMessage());
        return [];
    }
}

// Export sessions to CSV
function exportSessionsToCSV(array $filters = []) {
    try {
        $sessions = getRecentSessions(500);
        $tmp = sys_get_temp_dir() . '/sessions-' . uniqid() . '.csv';
        $fh = fopen($tmp, 'w');
        
        fputcsv($fh, ['Date', 'User', 'Scenario', 'Score', 'Duration', 'Status']);
        
        foreach ($sessions as $session) {
            fputcsv($fh, [
                $session['created_at'],
                $session['user_id'],
                $session['scenario_name'],
                $session['final_score'],
                $session['duration'],
                $session['status'],
            ]);
        }
        
        fclose($fh);
        return $tmp;
    } catch (Exception $e) {
        error_log("Export sessions CSV error: " . $e->getMessage());
        return false;
    }
}

// Safe admin action logging
function logAdminAction($action, $details = '', $adminId = null) {
    global $pdo;
    
    try {
        if ($adminId === null && isset($_SESSION['admin_id'])) {
            $adminId = $_SESSION['admin_id'];
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO admin_logs (admin_id, action, details, ip_address, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        
        return $stmt->execute([
            $adminId,
            $action,
            $details,
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (PDOException $e) {
        error_log("Log admin action error: " . $e->getMessage());
        return false;
    }
}

// Get tag performance data
function getTagPerformance($days = null) {
    global $pdo;
    
    try {
        // Check if session_responses table exists
        $stmt = $pdo->query("SHOW TABLES LIKE 'session_responses'");
        if ($stmt->rowCount() == 0) {
            return []; // Table doesn't exist, return empty array
        }
        
        $whereClause = '';
        
        if ($days !== null) {
            $days = max(0, (int)$days); // Cast to int and ensure non-negative
            $whereClause = "WHERE sr.created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)";
        }
        
        $stmt = $pdo->prepare("
            SELECT 
                sr.response_tag as tag_name,
                SUM(CASE WHEN sr.score_level = 'Good' THEN 1 ELSE 0 END) as good,
                SUM(CASE WHEN sr.score_level = 'Medium' THEN 1 ELSE 0 END) as medium,
                SUM(CASE WHEN sr.score_level IN ('Low', 'Bad') THEN 1 ELSE 0 END) as bad
            FROM session_responses sr
            $whereClause
            GROUP BY sr.response_tag
            HAVING COUNT(*) > 0
            ORDER BY COUNT(*) DESC
        ");
        
        $stmt->execute(); // No params needed since we interpolated the integer
        $results = [];
        
        while ($row = $stmt->fetch()) {
            if ($row['tag_name']) {
                $results[$row['tag_name']] = [
                    'good' => (int)$row['good'],
                    'medium' => (int)$row['medium'],
                    'bad' => (int)$row['bad']
                ];
            }
        }
        
        return $results;
        
    } catch (PDOException $e) {
        error_log("Tag performance error: " . $e->getMessage());
        return [];
    }
}
?>
