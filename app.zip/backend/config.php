<?php
// Database configuration - SECURE VERSION
// NO hardcoded credentials - use environment variables or local config only
$host = $_ENV['DB_HOST'] ?? getenv('DB_HOST') ?: null;
$dbname = $_ENV['DB_NAME'] ?? getenv('DB_NAME') ?: null;
$username = $_ENV['DB_USER'] ?? getenv('DB_USER') ?: null;
$password = $_ENV['DB_PASS'] ?? getenv('DB_PASS') ?: null;

// SECURITY: Load local configuration if available (not committed to version control)
if (file_exists(__DIR__ . '/config.local.php')) {
    include __DIR__ . '/config.local.php';
}

// Validate that all credentials are set
if (!$host || !$dbname || !$username || $password === null) {
    error_log("SECURITY: Database credentials not properly configured");
    // Don't die() directly - let the API handle it gracefully
    if (!defined('API_REQUEST')) {
        die("Database configuration error. Please set environment variables or create config.local.php");
    }
}

// Define constants for compatibility
define('DB_HOST', $host);
define('DB_NAME', $dbname);
define('DB_USER', $username);
define('DB_PASS', $password);

// Global PDO instance
$pdo = null;

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    
    die("Database connection failed. Please check your configuration.");
}

// Application settings
define('APP_NAME', 'Shing Chat');
define('APP_VERSION', '1.0.0');
define('ADMIN_SESSION_TIMEOUT', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes

// Error reporting - Enable logging but disable display in production
$isProduction = ($_ENV['APP_ENV'] ?? getenv('APP_ENV')) === 'production';

if ($isProduction) {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/../logs/php_errors.log');
} else {
    // Development mode - show errors
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('log_errors', 1);
}

// SECURE CORS headers for API endpoints
function setCorsHeaders() {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    
    // Only allow same-origin requests
    if (!empty($origin) && strpos($origin, $host) !== false) {
        header("Access-Control-Allow-Origin: $origin");
    } else {
        header('Access-Control-Allow-Origin: null');
    }
    
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }
}

// JSON response helper
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}

// Sanitize input
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Validate email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Generate secure token
function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}
?>