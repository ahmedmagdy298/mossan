<?php
/**
 * Secure Backend API Router - Software Version
 * Handles API requests for scenarios, sessions, and other data with authentication
 */

// Define flag to indicate this is an API request (before loading config)
define('API_REQUEST', true);

// Suppress any output before JSON to prevent invalid JSON responses
ob_start();

session_start();

// Suppress warnings/notices that could break JSON output (but log them)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once 'config.php';
require_once 'functions.php';

// Clear any output buffer before sending JSON
ob_end_clean();

// Check database connection before processing
global $pdo;
if (!$pdo) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Database connection failed. Please check your configuration.']);
    exit;
}

// Secure CORS - Only allow same origin and specific domains
$allowedOrigins = [
    $_SERVER['HTTP_HOST'] ?? 'localhost',
    'localhost',
    '127.0.0.1'
];

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$host = $_SERVER['HTTP_HOST'] ?? '';

// Check if request is from allowed origin
$corsAllowed = false;
if (empty($origin) || strpos($origin, $host) !== false) {
    $corsAllowed = true;
} else {
    foreach ($allowedOrigins as $allowedOrigin) {
        if (strpos($origin, $allowedOrigin) !== false) {
            $corsAllowed = true;
            break;
        }
    }
}

if ($corsAllowed) {
    header('Access-Control-Allow-Origin: ' . ($origin ?: '*'));
} else {
    header('Access-Control-Allow-Origin: null');
}

header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Authentication check for all endpoints except public read-only scenarios
function requireAuthentication($endpoint, $method) {
    // Allow public read access to scenarios only
    if ($endpoint === 'scenarios' && $method === 'GET') {
        return true;
    }
    
    // Allow public session creation (POST to sessions)
    if ($endpoint === 'sessions' && $method === 'POST') {
        return validateSessionToken();
    }
    
    // All other operations require admin authentication
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit();
    }
    
    return true;
}

// Validate session token for public session creation
function validateSessionToken() {
    $token = $_SERVER['HTTP_X_SESSION_TOKEN'] ?? $_POST['session_token'] ?? '';
    
    // Basic token validation - must be 32+ characters alphanumeric
    if (strlen($token) >= 32 && ctype_alnum($token)) {
        return true;
    }
    
    // Allow requests from same origin without token
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    
    return !empty($referer) && strpos($referer, $host) !== false;
}

// Rate limiting
function checkRateLimit($endpoint) {
    $clientIP = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $rateLimitKey = "api_" . $endpoint . "_" . md5($clientIP);
    $rateLimitFile = sys_get_temp_dir() . "/" . $rateLimitKey;
    $currentTime = time();
    
    // Different limits for different endpoints
    $limits = [
        'scenarios' => 30, // 30 requests per minute
        'sessions' => 10,  // 10 requests per minute
        'users' => 5       // 5 requests per minute
    ];
    
    $limit = $limits[$endpoint] ?? 10;
    
    if (file_exists($rateLimitFile)) {
        $lastRequests = json_decode(file_get_contents($rateLimitFile), true) ?: [];
        $recentRequests = array_filter($lastRequests, function($timestamp) use ($currentTime) {
            return ($currentTime - $timestamp) < 60;
        });
        
        if (count($recentRequests) >= $limit) {
            http_response_code(429);
            echo json_encode(['error' => 'Rate limit exceeded']);
            exit();
        }
        
        $recentRequests[] = $currentTime;
    } else {
        $recentRequests = [$currentTime];
    }
    
    file_put_contents($rateLimitFile, json_encode($recentRequests));
}

$endpoint = $_GET['endpoint'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// Input validation
if (!in_array($endpoint, ['scenarios', 'sessions', 'users'])) {
    http_response_code(404);
    echo json_encode(['error' => 'Endpoint not found']);
    exit();
}

try {
    // Check authentication and rate limiting
    requireAuthentication($endpoint, $method);
    checkRateLimit($endpoint);
    
    switch ($endpoint) {
        case 'scenarios':
            handleScenariosEndpoint($method);
            break;
            
        case 'sessions':
            handleSessionsEndpoint($method);
            break;
            
        case 'users':
            handleUsersEndpoint($method);
            break;
    }
} catch (Exception $e) {
    error_log("API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}

function handleScenariosEndpoint($method) {
    switch ($method) {
        case 'GET':
            if (isset($_GET['id'])) {
                $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
                if ($id === false || $id <= 0) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Invalid scenario ID']);
                    exit;
                }
                
                $scenario = getScenarioById($id);
                if ($scenario) {
                    $scenario['scenario_data'] = json_decode($scenario['scenario_data'], true);
                    $scenario['scoring_rules'] = json_decode($scenario['scoring_rules'], true);
                    echo json_encode(['success' => true, 'data' => $scenario]);
                } else {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'error' => 'Scenario not found']);
                }
            } else {
                try {
                    $scenarios = getAllScenarios();
                    echo json_encode(['success' => true, 'data' => $scenarios], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                } catch (Exception $e) {
                    error_log("Error getting scenarios: " . $e->getMessage());
                    http_response_code(500);
                    echo json_encode(['success' => false, 'error' => 'Failed to load scenarios: ' . $e->getMessage()]);
                }
            }
            exit;
            break;
            
        case 'POST':
            // Require admin authentication for creating scenarios
            if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
                http_response_code(401);
                echo json_encode(['error' => 'Admin authentication required']);
                break;
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            if ($input && validateScenarioInput($input)) {
                $id = createScenario($input);
                if ($id) {
                    logAdminAction('create_scenario', "Created scenario ID: $id");
                    echo json_encode(['success' => true, 'id' => $id]);
                } else {
                    http_response_code(500);
                    echo json_encode(['error' => 'Failed to create scenario']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Invalid input data']);
            }
            break;
            
        case 'PUT':
            // Require admin authentication for updating scenarios
            if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
                http_response_code(401);
                echo json_encode(['error' => 'Admin authentication required']);
                break;
            }
            
            if (isset($_GET['id'])) {
                $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
                if ($id === false || $id <= 0) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Invalid scenario ID']);
                    break;
                }
                
                $input = json_decode(file_get_contents('php://input'), true);
                if ($input && validateScenarioInput($input) && updateScenario($id, $input)) {
                    logAdminAction('update_scenario', "Updated scenario ID: $id");
                    echo json_encode(['success' => true]);
                } else {
                    http_response_code(500);
                    echo json_encode(['error' => 'Failed to update scenario']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Scenario ID required']);
            }
            break;
            
        case 'DELETE':
            // Require admin authentication for deleting scenarios
            if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
                http_response_code(401);
                echo json_encode(['error' => 'Admin authentication required']);
                break;
            }
            
            if (isset($_GET['id'])) {
                $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
                if ($id === false || $id <= 0) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Invalid scenario ID']);
                    break;
                }
                
                if (deleteScenario($id)) {
                    logAdminAction('delete_scenario', "Deleted scenario ID: $id");
                    echo json_encode(['success' => true]);
                } else {
                    http_response_code(500);
                    echo json_encode(['error' => 'Failed to delete scenario']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Scenario ID required']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
            break;
    }
}

function validateScenarioInput($input) {
    if (!is_array($input)) return false;
    
    // Required fields
    if (empty($input['title']) || empty($input['description'])) {
        return false;
    }
    
    // Validate title length
    if (strlen($input['title']) > 255) {
        return false;
    }
    
    // Validate description length
    if (strlen($input['description']) > 1000) {
        return false;
    }
    
    // Validate scenario_data is array
    if (isset($input['scenario_data']) && !is_array($input['scenario_data'])) {
        return false;
    }
    
    // Validate scoring_rules is array
    if (isset($input['scoring_rules']) && !is_array($input['scoring_rules'])) {
        return false;
    }
    
    // Validate status
    if (isset($input['status']) && !in_array($input['status'], ['active', 'inactive', 'draft'])) {
        return false;
    }
    
    return true;
}

function handleSessionsEndpoint($method) {
    switch ($method) {
        case 'GET':
            if (isset($_GET['id'])) {
                $session = getChatSession($_GET['id']);
                if ($session) {
                    echo json_encode(['success' => true, 'data' => $session]);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Session not found']);
                }
            } else {
                $limit = $_GET['limit'] ?? 10;
                $sessions = getRecentSessions($limit);
                echo json_encode(['success' => true, 'data' => $sessions]);
            }
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            
            // Log the incoming data for debugging
            error_log("Session POST data: " . json_encode($input));
            
            if (!$input) {
                http_response_code(400);
                echo json_encode(['error' => 'Invalid JSON data']);
                break;
            }
            
            // Validate required fields
            if (!isset($input['scenario_id']) || !isset($input['final_score'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Missing required fields: scenario_id, final_score']);
                break;
            }
            
            $result = createChatSession($input);
            if ($result) {
                // Log successful session creation for analytics
                error_log("Session created successfully with ID: $result for scenario: " . $input['scenario_id']);
                echo json_encode([
                    'success' => true, 
                    'message' => 'Session created successfully',
                    'session_id' => $result
                ]);
            } else {
                error_log("Failed to create session for scenario: " . $input['scenario_id']);
                http_response_code(500);
                echo json_encode(['error' => 'Failed to create session - check server logs']);
            }
            break;
            
        case 'DELETE':
            if (isset($_GET['id'])) {
                if (deleteChatSession($_GET['id'])) {
                    echo json_encode(['success' => true]);
                } else {
                    http_response_code(500);
                    echo json_encode(['error' => 'Failed to delete session']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Session ID required']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
            break;
    }
}

function handleUsersEndpoint($method) {
    // Users endpoint requires admin authentication
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        http_response_code(401);
        echo json_encode(['error' => 'Admin authentication required']);
        return;
    }
    
    switch ($method) {
        case 'GET':
            $limit = filter_var($_GET['limit'] ?? 100, FILTER_VALIDATE_INT);
            $offset = filter_var($_GET['offset'] ?? 0, FILTER_VALIDATE_INT);
            
            // Validate limits
            if ($limit === false || $limit < 1 || $limit > 1000) {
                $limit = 100;
            }
            if ($offset === false || $offset < 0) {
                $offset = 0;
            }
            
            $users = getAllUsers($limit, $offset);
            logAdminAction('view_users', "Viewed users list (limit: $limit, offset: $offset)");
            echo json_encode(['success' => true, 'data' => $users]);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
            break;
    }
}
?>