<?php
// Session management helper
class SessionManager {
    
    public static function start() {
        // Only start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            // Set session configuration before starting
            ini_set('session.cookie_httponly', 1);
            ini_set('session.cookie_secure', isset($_SERVER['HTTPS']) ? 1 : 0);
            ini_set('session.use_strict_mode', 1);
            ini_set('session.cookie_samesite', 'Strict');
            ini_set('session.gc_maxlifetime', ADMIN_SESSION_TIMEOUT);
            
            session_start();
            
            // Regenerate session ID periodically for security
            if (!isset($_SESSION['last_regeneration'])) {
                $_SESSION['last_regeneration'] = time();
            } elseif (time() - $_SESSION['last_regeneration'] > 300) { // 5 minutes
                session_regenerate_id(true);
                $_SESSION['last_regeneration'] = time();
            }
        }
    }
    
    public static function destroy() {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_unset();
            session_destroy();
        }
    }
    
    public static function isActive() {
        return session_status() === PHP_SESSION_ACTIVE;
    }
    
    public static function checkTimeout() {
        if (isset($_SESSION['last_activity'])) {
            if (time() - $_SESSION['last_activity'] > ADMIN_SESSION_TIMEOUT) {
                self::destroy();
                return false;
            }
        }
        $_SESSION['last_activity'] = time();
        return true;
    }
    
    public static function isAdminLoggedIn() {
        return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
    }
    
    public static function requireAdmin() {
        if (!self::isAdminLoggedIn() || !self::checkTimeout()) {
            header('Location: login.php');
            exit();
        }
    }
}
?>