#!/bin/bash

echo "========================================"
echo "  Shing Chat - Local Development Server"
echo "========================================"
echo ""
echo "Starting PHP development server..."
echo ""
echo "The application will be available at:"
echo "  Frontend: http://localhost:8000/frontend/index.html"
echo "  Admin:    http://localhost:8000/admin/login.php"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

php -S localhost:8000

