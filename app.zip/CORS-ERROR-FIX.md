# 🔧 CORS Error Fix Guide

## Understanding the Error

When you see this error:
```
Access to fetch at 'file:///.../backend/api.php' from origin 'null' has been blocked by CORS policy
```

**What it means:**
- You're opening the HTML file directly in your browser (using `file://` protocol)
- Modern browsers **block** API requests from `file://` protocol for security reasons
- The JavaScript code cannot make HTTP requests to your PHP backend API

## Why This Happens

**Security Reason:** Browsers prevent websites from accessing local files to protect your computer. When you open a file directly (`file:///path/to/file.html`), the browser treats it as a "null" origin and blocks all network requests except to the same protocol.

## ✅ Solution: Use a Web Server

You **must** serve your files through a web server (HTTP/HTTPS protocol) instead of opening them directly.

### Option 1: PHP Built-in Server (Recommended)

**Windows:**
```bash
# Double-click start-server.bat
# OR run in command prompt:
php -S localhost:8000
```

**Mac/Linux:**
```bash
# Run in terminal:
php -S localhost:8000
```

Then visit: **http://localhost:8000/frontend/chat.html**

### Option 2: Python Server

```bash
# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
```

### Option 3: Node.js Server

```bash
# Install http-server globally (one time)
npm install -g http-server

# Run server
http-server -p 8000
```

### Option 4: XAMPP/WAMP/MAMP

If you have XAMPP, WAMP, or MAMP installed:
1. Copy your project folder to the `htdocs` (XAMPP) or `www` (WAMP/MAMP) folder
2. Start the server
3. Visit: `http://localhost/your-project-folder/frontend/chat.html`

## 🎯 Quick Test

After starting a server, you should see:
- ✅ URL in browser: `http://localhost:8000/...` (NOT `file:///...`)
- ✅ No CORS errors in browser console
- ✅ API requests work correctly

## 📝 What Changed

The application now automatically detects if you're using `file://` protocol and shows a helpful error message with instructions on how to fix it.

## Still Having Issues?

1. **Check if PHP is installed:**
   ```bash
   php -v
   ```
   If not installed, download from: https://www.php.net/downloads

2. **Check if port 8000 is available:**
   Try a different port: `php -S localhost:8080`

3. **Verify database connection:**
   Make sure your `backend/config.local.php` is configured correctly

4. **Check server logs:**
   Look for errors in the terminal where you started the server

---

**Remember:** Always use a web server for web applications! The `file://` protocol is only for static files that don't need to make API calls.

