<?php
/**
 * Scenarios API for Admin Panel - Software Version
 * Handles CRUD operations for scenarios
 */

session_start();

// Check admin authentication
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once '../../backend/config.php';
require_once '../../backend/functions.php';

// Set JSON header
header('Content-Type: application/json');

// Handle CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['id'])) {
                // Get single scenario
                $scenario = getScenarioById($_GET['id']);
                if ($scenario) {
                    // Parse JSON data
                    $scenario['scenario_data'] = json_decode($scenario['scenario_data'], true);
                    $scenario['scoring_rules'] = json_decode($scenario['scoring_rules'], true);
                    
                    echo json_encode([
                        'success' => true,
                        'data' => $scenario
                    ]);
                } else {
                    http_response_code(404);
                    echo json_encode([
                        'success' => false,
                        'message' => 'Scenario not found'
                    ]);
                }
            } else {
                // Get all scenarios
                $scenarios = getAllScenarios();
                echo json_encode([
                    'success' => true,
                    'data' => $scenarios
                ]);
            }
            break;
            
        case 'POST':
            // Create new scenario
            if (!$input) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'message' => 'Invalid input data'
                ]);
                break;
            }
            
            $required = ['title', 'description', 'scenario_data', 'scoring_rules'];
            foreach ($required as $field) {
                if (!isset($input[$field])) {
                    http_response_code(400);
                    echo json_encode([
                        'success' => false,
                        'message' => "Missing required field: $field"
                    ]);
                    exit;
                }
            }
            
            $scenarioId = createScenario($input);
            if ($scenarioId) {
                // Log admin action
                if (function_exists('logAdminAction')) {
                    logAdminAction('create_scenario', "Created scenario: " . $input['title']);
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Scenario created successfully',
                    'id' => $scenarioId
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to create scenario'
                ]);
            }
            break;
            
        case 'PUT':
            // Update scenario
            if (!isset($_GET['id']) || !$input) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'message' => 'Invalid request'
                ]);
                break;
            }
            
            $id = $_GET['id'];
            
            if (updateScenario($id, $input)) {
                // Log admin action
                if (function_exists('logAdminAction')) {
                    logAdminAction('update_scenario', "Updated scenario ID: $id");
                }
                
                // Clear any cached scenario data
                clearScenarioCache($id);
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Scenario updated successfully'
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to update scenario'
                ]);
            }
            break;
            
        case 'DELETE':
            // Delete scenario
            if (!isset($_GET['id'])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'message' => 'Scenario ID required'
                ]);
                break;
            }
            
            $id = $_GET['id'];
            
            if (deleteScenario($id)) {
                // Log admin action
                if (function_exists('logAdminAction')) {
                    logAdminAction('delete_scenario', "Deleted scenario ID: $id");
                }
                
                // Clear any cached scenario data
                clearScenarioCache($id);
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Scenario deleted successfully'
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to delete scenario'
                ]);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode([
                'success' => false,
                'message' => 'Method not allowed'
            ]);
            break;
    }
    
} catch (Exception $e) {
    error_log("Scenarios API error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Internal server error'
    ]);
}

/**
 * Real cache busting implementation with correct table name
 */
function bustScenarioCache() {
    global $pdo;
    try {
        // Update cache version in system_settings table (correct table name)
        $stmt = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $cacheVersion = time();
        $stmt->execute(["cache_version", $cacheVersion, $cacheVersion]);
        
        // Clear cached files
        $cacheDir = __DIR__ . "/../../cache/";
        if (is_dir($cacheDir)) {
            $files = glob($cacheDir . "scenarios_*.json");
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
        }
        
        // Clear opcache
        if (function_exists("opcache_reset")) {
            opcache_reset();
        }
        
        error_log("Cache busted successfully at " . date("Y-m-d H:i:s"));
    } catch (Exception $e) {
        error_log("Cache busting failed: " . $e->getMessage());
    }
}

// Helper function to clear scenario cache
function clearScenarioCache($scenarioId = null) {
    // Clear any cached files or database cache entries
    // This ensures the frontend gets updated data
    
    // Call the real cache busting function
    bustScenarioCache();
    
    error_log("Clearing scenario cache for ID: " . ($scenarioId ?? 'all'));
}
?>