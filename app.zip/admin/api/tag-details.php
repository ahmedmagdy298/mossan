<?php
/**
 * Tag Details API Endpoint
 * Provides detailed information about a specific tag's performance
 */

session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

require_once '../../backend/config.php';
require_once '../../backend/functions.php';

// Set JSON header
header('Content-Type: application/json');

try {
    // Get tag name from request
    $tagName = $_GET['tag'] ?? '';
    
    if (empty($tagName)) {
        throw new Exception('Tag name is required');
    }
    
    // Get tag performance data
    $tagPerformanceData = getTagPerformance(null); // Get all-time data
    
    if (!isset($tagPerformanceData[$tagName])) {
        throw new Exception('Tag not found or no data available');
    }
    
    $tagData = $tagPerformanceData[$tagName];
    
    // Calculate performance percentage
    $totalResponses = $tagData['good'] + $tagData['medium'] + $tagData['bad'];
    $performance = $totalResponses > 0 ? round(($tagData['good'] / $totalResponses) * 100) : 0;
    
    // Get additional insights (if available)
    $insights = getTagInsights($tagName);
    
    // Prepare response
    $response = [
        'success' => true,
        'details' => [
            'tag_name' => $tagName,
            'performance' => $performance,
            'good' => $tagData['good'],
            'medium' => $tagData['medium'],
            'bad' => $tagData['bad'],
            'total_responses' => $totalResponses,
            'insights' => $insights
        ]
    ];
    
    echo json_encode($response);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

/**
 * Get additional insights for a tag (placeholder function)
 */
function getTagInsights($tagName) {
    // This could be expanded to provide more detailed insights
    // For now, return basic information
    
    $insights = [
        'category' => 'Clinical Communication',
        'description' => "Performance analysis for {$tagName} communication skills",
        'last_updated' => date('Y-m-d H:i:s')
    ];
    
    // Add tag-specific insights based on tag name
    switch (strtolower($tagName)) {
        case 'burden-risk':
            $insights['focus_area'] = 'Risk communication and burden assessment';
            $insights['key_skills'] = ['Risk assessment', 'Patient burden evaluation', 'Clear communication'];
            break;
        case 'rapport building':
            $insights['focus_area'] = 'Building patient relationships and trust';
            $insights['key_skills'] = ['Active listening', 'Empathy', 'Trust building'];
            break;
        case 'greeting':
            $insights['focus_area'] = 'Initial patient interaction and welcome';
            $insights['key_skills'] = ['Professional greeting', 'Setting tone', 'First impressions'];
            break;
        default:
            $insights['focus_area'] = 'General clinical communication';
            $insights['key_skills'] = ['Communication', 'Patient interaction', 'Professional skills'];
    }
    
    return $insights;
}
?>