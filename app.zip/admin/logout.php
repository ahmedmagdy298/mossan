<?php
// Include config and session manager
require_once '../backend/config.php';
require_once '../backend/session.php';

// Start session
SessionManager::start();

// Log logout if admin was logged in
if (isset($_SESSION['admin_id'])) {
    
    try {
        $stmt = $pdo->prepare("INSERT INTO admin_logs (admin_id, action, details, ip_address) VALUES (?, 'logout', 'Admin logged out', ?)");
        $stmt->execute([$_SESSION['admin_id'], $_SERVER['REMOTE_ADDR']]);
    } catch (PDOException $e) {
        error_log("Logout logging error: " . $e->getMessage());
    }
}

// Clear all session data
SessionManager::destroy();

// Redirect to login page
header('Location: login.php');
exit();
?>