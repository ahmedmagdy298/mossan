<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once '../backend/config.php';
require_once '../backend/functions.php';

// Get analytics data
$analytics = getAnalyticsData();
$scenarios = getAllScenarios();
$recentSessions = getRecentSessions(10);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Shing Chat</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../frontend/css/admin.css">
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-shield-virus"></i>
                    <span>Shing Chat Admin</span>
                </div>
            </div>
            
            <nav class="sidebar-nav">
                <a href="#dashboard" class="nav-item active" data-section="dashboard">
                    <i class="fas fa-chart-line"></i>
                    <span>Dashboard</span>
                </a>
                <a href="#scenarios" class="nav-item" data-section="scenarios">
                    <i class="fas fa-comments"></i>
                    <span>Scenarios</span>
                </a>
                <a href="#analytics" class="nav-item" data-section="analytics">
                    <i class="fas fa-chart-bar"></i>
                    <span>Analytics</span>
                </a>

                <a href="#settings" class="nav-item" data-section="settings">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
                <a href="#documentation" class="nav-item" data-section="documentation">
                    <i class="fas fa-book"></i>
                    <span>Documentation</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <div class="user-info">
                    <i class="fas fa-user-circle"></i>
                    <span><?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Dashboard Section -->
            <section id="dashboard-section" class="content-section active">
                <div class="section-header">
                    <h1>Dashboard Overview</h1>
                    <div class="header-actions">
                        <button class="btn btn-primary" onclick="refreshData()">
                            <i class="fas fa-sync-alt"></i>
                            Refresh
                        </button>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon primary">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo $analytics['total_sessions']; ?></h3>
                            <p>Total Sessions</p>
                            <span class="stat-change positive">+<?php echo $analytics['sessions_growth']; ?>%</span>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon success">
                            <i class="fas fa-trophy"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo $analytics['avg_score']; ?>%</h3>
                            <p>Average Score</p>
                            <span class="stat-change positive">+<?php echo $analytics['score_growth']; ?>%</span>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon warning">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo $analytics['avg_duration']; ?>s</h3>
                            <p>Avg Duration</p>
                            <span class="stat-change neutral"><?php echo $analytics['duration_change']; ?>%</span>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon danger">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo $analytics['completion_rate']; ?>%</h3>
                            <p>Completion Rate</p>
                            <span class="stat-change positive">+<?php echo $analytics['completion_growth']; ?>%</span>
                        </div>
                    </div>
                </div>

                <!-- Charts Row -->
                <div class="charts-row">
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Sessions Over Time</h3>
                            <select id="timeRange" onchange="updateChart()">
                                <option value="7">Last 7 days</option>
                                <option value="30" selected>Last 30 days</option>
                                <option value="90">Last 90 days</option>
                            </select>
                        </div>
                        <canvas id="sessionsChart"></canvas>
                    </div>
                    
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Score Distribution</h3>
                        </div>
                        <canvas id="scoresChart"></canvas>
                    </div>
                </div>

                <!-- Recent Sessions Table -->
                <div class="table-container">
                    <div class="table-header">
                        <h3>Recent Sessions</h3>
                        <button class="btn btn-secondary" onclick="exportSessions()">
                            <i class="fas fa-download"></i>
                            Export
                        </button>
                    </div>
                    <div class="table-wrapper">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>User</th>
                                    <th>Scenario</th>
                                    <th>Score</th>
                                    <th>Duration</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentSessions as $session): ?>
                                <tr>
                                    <td><?php echo date('M j, Y H:i', strtotime($session['created_at'])); ?></td>
                                    <td><?php echo htmlspecialchars($session['user_id'] ?? 'Anonymous'); ?></td>
                                    <td><?php echo htmlspecialchars($session['scenario_name']); ?></td>
                                    <td>
                                        <span class="score-badge <?php echo getScoreBadgeClass($session['final_score']); ?>">
                                            <?php echo $session['final_score']; ?>%
                                        </span>
                                    </td>
                                    <td><?php echo $session['duration']; ?>s</td>
                                    <td>
                                        <span class="status-badge <?php echo $session['status']; ?>">
                                            <?php echo ucfirst($session['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn-icon" onclick="viewSession(<?php echo $session['id']; ?>)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn-icon danger" onclick="deleteSession(<?php echo $session['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <!-- Scenarios Section -->
            <section id="scenarios-section" class="content-section">
                <div class="section-header">
                    <h1>Scenario Management</h1>
                    <div class="header-actions">
                        <button class="btn btn-primary new-scenario-btn">
                            <i class="fas fa-plus"></i>
                            New Scenario
                        </button>
                    </div>
                </div>

                <div class="scenarios-grid" id="scenarios-container">
                    <?php foreach ($scenarios as $scenario): ?>
                    <div class="scenario-card" data-scenario-id="<?php echo $scenario['id']; ?>">
                        <div class="scenario-header">
                            <h3><?php echo htmlspecialchars($scenario['title']); ?></h3>
                            <div class="scenario-actions">
                                <button class="btn-icon edit-scenario-btn" data-scenario-id="<?php echo $scenario['id']; ?>" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn-icon danger delete-scenario-btn" data-scenario-id="<?php echo $scenario['id']; ?>" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        <p class="scenario-description"><?php echo htmlspecialchars($scenario['description']); ?></p>
                        <div class="scenario-stats">
                            <div class="stat">
                                <i class="fas fa-play"></i>
                                <span><?php echo $scenario['total_sessions']; ?> sessions</span>
                            </div>
                            <div class="stat">
                                <i class="fas fa-star"></i>
                                <span><?php echo $scenario['avg_score']; ?>% avg</span>
                            </div>
                            <div class="stat">
                                <i class="fas fa-clock"></i>
                                <span><?php echo $scenario['avg_duration']; ?>s avg</span>
                            </div>
                        </div>
                        <div class="scenario-status">
                            <span class="status-badge <?php echo $scenario['status']; ?>">
                                <?php echo ucfirst($scenario['status']); ?>
                            </span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Analytics Section -->
            <section id="analytics-section" class="content-section">
                <div class="section-header">
                    <h1>Advanced Analytics</h1>
                    <div class="header-actions">
                        <button class="btn btn-primary" onclick="generateReport()">
                            <i class="fas fa-file-pdf"></i>
                            Generate Report
                        </button>
                    </div>
                </div>

                <!-- Analytics content -->
                <div id="analytics-content">
                    <?php
                    // Get analytics data
                    $analyticsData = getAnalyticsData(30);
                    $tagPerformanceData = getTagPerformance(30);
                    ?>
                    
                    <div class="analytics-overview">
                        <!-- Enhanced Stats Grid -->
                        <div class="stats-grid" style="margin-bottom: 2rem;">
                            <div class="stat-card">
                                <div class="stat-icon primary">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                                <div class="stat-content">
                                    <h3><?php echo $analyticsData['total_sessions']; ?></h3>
                                    <p>Total Sessions</p>
                                    <span class="stat-change <?php echo $analyticsData['sessions_growth'] >= 0 ? 'positive' : 'negative'; ?>">
                                        <?php echo $analyticsData['sessions_growth'] >= 0 ? '+' : ''; ?><?php echo $analyticsData['sessions_growth']; ?>%
                                    </span>
                                </div>
                            </div>
                            
                            <div class="stat-card">
                                <div class="stat-icon success">
                                    <i class="fas fa-star"></i>
                                </div>
                                <div class="stat-content">
                                    <h3><?php echo $analyticsData['avg_score']; ?>%</h3>
                                    <p>Average Score</p>
                                    <span class="stat-change <?php echo $analyticsData['score_growth'] >= 0 ? 'positive' : 'negative'; ?>">
                                        <?php echo $analyticsData['score_growth'] >= 0 ? '+' : ''; ?><?php echo $analyticsData['score_growth']; ?>%
                                    </span>
                                </div>
                            </div>
                            
                            <div class="stat-card">
                                <div class="stat-icon warning">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div class="stat-content">
                                    <h3><?php echo $analyticsData['avg_duration']; ?>s</h3>
                                    <p>Avg Duration</p>
                                    <span class="stat-change neutral"><?php echo $analyticsData['duration_change']; ?>%</span>
                                </div>
                            </div>
                            
                            <div class="stat-card">
                                <div class="stat-icon danger">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <div class="stat-content">
                                    <h3><?php echo $analyticsData['completion_rate']; ?>%</h3>
                                    <p>Completion Rate</p>
                                    <span class="stat-change positive">+<?php echo $analyticsData['completion_growth']; ?>%</span>
                                </div>
                            </div>
                        </div>

                        <!-- Tag Performance Analysis -->
                        <div class="tag-performance-section">
                            <div class="tag-performance-header-section">
                                <div class="section-header">
                                    <h3 class="section-title">
                                        <i class="fas fa-tags"></i>
                                        Tag Performance Analysis
                                    </h3>
                                    <p class="section-description">Detailed breakdown of performance by clinical communication categories</p>
                                </div>
                            </div>

                            <div class="tag-performance-grid">
                                <?php if (empty($tagPerformanceData)): ?>
                                    <div class="empty-state">
                                        <i class="fas fa-chart-bar"></i>
                                        <h3>No Tag Data Available</h3>
                                        <p>Complete some training sessions to see tag performance analysis.</p>
                                    </div>
                                <?php else: ?>
                                    <?php foreach ($tagPerformanceData as $tagName => $data): ?>
                                        <?php 
                                        $totalResponses = $data['good'] + $data['medium'] + $data['bad'];
                                        $performance = $totalResponses > 0 ? round(($data['good'] / $totalResponses) * 100) : 0;
                                        ?>
                                        <div class="tag-performance-card">
                                            <div class="tag-card-header">
                                                <div>
                                                    <h4 class="tag-card-title">
                                                        <a href="#" class="tag-link" onclick="showTagDetails('<?php echo htmlspecialchars($tagName, ENT_QUOTES); ?>', event)" title="View detailed analysis for <?php echo htmlspecialchars($tagName); ?>">
                                                            <?php echo htmlspecialchars($tagName); ?>
                                                            <i class="fas fa-external-link-alt"></i>
                                                        </a>
                                                    </h4>
                                                    <p class="tag-card-category">Clinical Communication</p>
                                                </div>
                                                <div class="tag-card-score">
                                                    <div class="tag-score-value"><?php echo $performance; ?>%</div>
                                                    <div class="tag-score-label">Performance</div>
                                                </div>
                                            </div>
                                            <div class="tag-card-progress">
                                                <div class="tag-progress-bar">
                                                    <div class="tag-progress-fill" style="width: <?php echo $performance; ?>%"></div>
                                                </div>
                                            </div>
                                            <div class="tag-card-stats">
                                                <div class="tag-stat-item good">
                                                    <div class="tag-stat-value"><?php echo $data['good']; ?></div>
                                                    <div class="tag-stat-label">Good</div>
                                                </div>
                                                <div class="tag-stat-item medium">
                                                    <div class="tag-stat-value"><?php echo $data['medium']; ?></div>
                                                    <div class="tag-stat-label">Medium</div>
                                                </div>
                                                <div class="tag-stat-item bad">
                                                    <div class="tag-stat-value"><?php echo $data['bad']; ?></div>
                                                    <div class="tag-stat-label">Bad</div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Performance Insights -->
                        <div class="performance-insights">
                            <h3><i class="fas fa-lightbulb"></i> Performance Insights</h3>
                            <div class="insights-grid">
                                <div class="insight-card">
                                    <div class="insight-icon">
                                        <i class="fas fa-trending-up"></i>
                                    </div>
                                    <div class="insight-content">
                                        <h4>Score Trend</h4>
                                        <p>Average score is <?php echo $analyticsData['avg_score']; ?>% with a <?php echo $analyticsData['score_growth']; ?>% change from last period.</p>
                                    </div>
                                </div>
                                
                                <div class="insight-card">
                                    <div class="insight-icon">
                                        <i class="fas fa-users"></i>
                                    </div>
                                    <div class="insight-content">
                                        <h4>User Engagement</h4>
                                        <p><?php echo $analyticsData['total_sessions']; ?> total sessions with <?php echo $analyticsData['completion_rate']; ?>% completion rate.</p>
                                    </div>
                                </div>
                                
                                <div class="insight-card">
                                    <div class="insight-icon">
                                        <i class="fas fa-clock"></i>
                                    </div>
                                    <div class="insight-content">
                                        <h4>Session Duration</h4>
                                        <p>Average session duration is <?php echo $analyticsData['avg_duration']; ?> seconds.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>



            <!-- Settings Section -->
            <section id="settings-section" class="content-section">
                <div class="section-header">
                    <h1>System Settings</h1>
                </div>

                <!-- Settings content will be loaded here -->
                <div id="settings-content">
                    <!-- This will be populated by JavaScript -->
                </div>
            </section>

            <!-- Documentation Section -->
            <section id="documentation-section" class="content-section">
                <div class="section-header">
                    <h1>Documentation</h1>
                    <div class="header-actions">
                        <button class="btn btn-primary" onclick="downloadDocs()">
                            <i class="fas fa-download"></i>
                            Download All
                        </button>
                    </div>
                </div>

                <!-- Documentation content will be loaded here -->
                <div id="documentation-content">
                    <!-- This will be populated by JavaScript -->
                </div>
            </section>
        </main>
    </div>

    <!-- Modals will be added here -->
    <div id="modal-container"></div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../frontend/css/enhanced-modal.css">
    <script src="../frontend/js/admin.js"></script>
    <script src="../frontend/js/admin-navigation.js"></script>
    <script src="../frontend/js/admin-scenarios.js"></script>
    <script src="../frontend/js/scenario-editor-enhanced.js"></script>
</body>
</html>